import {defineConfig,type Plugin} from 'vite';
import react from '@vitejs/plugin-react';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import {createReadStream,existsSync,mkdirSync,readdirSync,statSync,copyFileSync,readFileSync,writeFileSync} from 'node:fs';
import type {IncomingMessage,ServerResponse} from 'node:http';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';

// Keep ONE canonical media library in source. Web/APK builds get their own bundled
// copies automatically, while development serves the same local files without API.
const mediaDir=fileURLToPath(new URL('../backend/media',import.meta.url));
const quranFile=fileURLToPath(new URL('../backend/data/quran.json',import.meta.url));
const backendDir=fileURLToPath(new URL('../backend',import.meta.url));
const warshRaw=gunzipSync(readFileSync(resolve(backendDir,'data/quran-warsh-source.json.gz')));
const warshMeta=JSON.parse(readFileSync(resolve(backendDir,'data/warsh-source-info.json'),'utf8'));
if(createHash('sha256').update(warshRaw).digest('hex')!==warshMeta.sha256)throw Error('Warsh canonical checksum mismatch');
const warshRows=JSON.parse(warshRaw.toString('utf8')) as {sura_no:number;aya_no:number;aya_text_unicode:string}[];
const hafsData=JSON.parse(readFileSync(quranFile,'utf8'));
const warshBody=Buffer.from(JSON.stringify({...warshMeta,surahs:hafsData.surahs.map((s:{id:number})=>({...s,count:warshRows.filter(r=>r.sura_no===s.id).length})),verses:Object.fromEntries(warshRows.map(r=>[r.sura_no+':'+r.aya_no,r.aya_text_unicode])),basmalas:{}}));
function extraLocalAssets(req:IncomingMessage,res:ServerResponse,next:()=>void){
 const path=(req.url||'').split('?')[0];
 if(path==='/quran-warsh.json'){res.setHeader('Content-Type','application/json; charset=utf-8');res.setHeader('Content-Length',warshBody.length);res.setHeader('Cache-Control','no-cache');res.end(req.method==='HEAD'?undefined:warshBody);return}
 if(/^\/fonts\/[A-Za-z0-9_-]+\.(ttf|txt)$/.test(path)){
  const file=resolve(backendDir,'fonts',path.split('/').pop()!);if(!existsSync(file)){res.statusCode=404;res.end();return}res.setHeader('Content-Type',path.endsWith('.ttf')?'font/ttf':'text/plain; charset=utf-8');res.setHeader('Content-Length',statSync(file).size);if(req.method==='HEAD'){res.end();return}createReadStream(file).pipe(res);return
 }
 next();
}
const mediaName=/^[a-z0-9_]+\.(mp4|jpg)$/;
function localMedia(req:IncomingMessage,res:ServerResponse){
 let name:string;try{name=decodeURIComponent((req.url||'').split('?')[0]).replace(/^\/+/, '')}catch{res.statusCode=400;res.end();return}
 if(!mediaName.test(name)){res.statusCode=404;res.end();return}
 const file=resolve(mediaDir,name);if(!existsSync(file)){res.statusCode=404;res.end();return}
 const size=statSync(file).size;let start=0,end=size-1;
 res.setHeader('Content-Type',name.endsWith('.mp4')?'video/mp4':'image/jpeg');res.setHeader('Accept-Ranges','bytes');res.setHeader('Cache-Control','public, max-age=3600');
 if(req.headers.range){
  const m=/^bytes=(\d*)-(\d*)$/.exec(req.headers.range);
  if(!m||(!m[1]&&!m[2])){res.statusCode=416;res.setHeader('Content-Range','bytes */'+size);res.end();return}
  if(!m[1])start=Math.max(0,size-Number(m[2]));else{start=Number(m[1]);if(m[2])end=Math.min(size-1,Number(m[2]))}
  if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||end<start||start>=size){res.statusCode=416;res.setHeader('Content-Range','bytes */'+size);res.end();return}
  res.statusCode=206;res.setHeader('Content-Range',`bytes ${start}-${end}/${size}`);
 }
 res.setHeader('Content-Length',end-start+1);
 if(req.method==='HEAD'){res.end();return}
 createReadStream(file,{start,end}).on('error',()=>res.destroy()).pipe(res);
}
let bundledDir='';
const localSceneAssets:Plugin={name:'ayat-local-scene-assets',
 configResolved(config){bundledDir=resolve(config.root,config.build.outDir,'scenes')},
 configureServer(server){server.middlewares.use(extraLocalAssets);server.middlewares.use('/scenes',localMedia);server.middlewares.use('/quran.json',(req,res)=>{res.setHeader('Content-Type','application/json; charset=utf-8');res.setHeader('Content-Length',statSync(quranFile).size);res.setHeader('Cache-Control','no-cache');if(req.method==='HEAD'){res.end();return}createReadStream(quranFile).on('error',()=>res.destroy()).pipe(res)})},
 writeBundle(){writeFileSync(resolve(bundledDir,'../quran-warsh.json'),warshBody);mkdirSync(resolve(bundledDir,'../fonts'),{recursive:true});for(const name of readdirSync(resolve(backendDir,'fonts')).filter(n=>/^[A-Za-z0-9_-]+\.(ttf|txt)$/.test(n)))copyFileSync(resolve(backendDir,'fonts',name),resolve(bundledDir,'../fonts',name));copyFileSync(quranFile,resolve(bundledDir,'../quran.json'));mkdirSync(bundledDir,{recursive:true});for(const name of readdirSync(mediaDir))if(mediaName.test(name))copyFileSync(resolve(mediaDir,name),resolve(bundledDir,name))}
};
export default defineConfig({plugins:[react(),localSceneAssets],server:{host:'0.0.0.0',port:5173,strictPort:true,allowedHosts:true,proxy:{'/api':{target:'http://127.0.0.1:8000',changeOrigin:true}}},preview:{host:'0.0.0.0',allowedHosts:true},build:{target:'es2022'}});
