package org.ayat.reels;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.os.StatFs;
import android.provider.MediaStore;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Android 10+ MediaStore save and content-URI sharing; no broad storage permission. */
@CapacitorPlugin(name = "VideoFiles")
public class VideoFilesPlugin extends Plugin {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override
    public void load() {
        worker.execute(() -> {
            // Clean abandoned, unpublished entries belonging to this app after a crash.
            try {
                ContentResolver resolver = getContext().getContentResolver();
                String selection = MediaStore.Video.Media.RELATIVE_PATH + "=? AND "
                    + MediaStore.Video.Media.IS_PENDING + "=1 AND "
                    + MediaStore.Video.Media.DATE_ADDED + "<?";
                String[] args = {"Movies/Ayat/", String.valueOf(System.currentTimeMillis()/1000 - 3600)};
                resolver.delete(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, selection, args);
            } catch (Exception ignored) { }
        });
    }

    @PluginMethod
    public void saveVideo(PluginCall call) {
        final String address = call.getString("url", "");
        String requested = call.getString("name", "Ayat_reel.mp4");
        final String name = (requested.replaceAll("[^\\p{L}\\p{N}._-]", "_").endsWith(".mp4")
            ? requested.replaceAll("[^\\p{L}\\p{N}._-]", "_") : "Ayat_reel.mp4");
        worker.execute(() -> {
            Uri saved = null;
            HttpsURLConnection connection = null;
            ContentResolver resolver = getContext().getContentResolver();
            try {
                URL url = new URL(address);
                if (!"https".equalsIgnoreCase(url.getProtocol()) || "localhost".equalsIgnoreCase(url.getHost())
                    || "127.0.0.1".equals(url.getHost())) {
                    throw new IOException("يلزم رابط خادم HTTPS متاح من الهاتف، وليس localhost.");
                }
                connection = (HttpsURLConnection) url.openConnection();
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(45000);
                connection.setInstanceFollowRedirects(true);
                connection.connect();
                if (connection.getResponseCode() != 200) {
                    throw new IOException("تعذر تنزيل الفيديو: HTTP " + connection.getResponseCode());
                }
                long length = connection.getContentLengthLong();
                long free = new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath()).getAvailableBytes();
                if (free < Math.max(32L*1024*1024, length > 0 ? length + 24L*1024*1024 : 48L*1024*1024)) {
                    call.reject("مساحة الهاتف غير كافية. حرّر مساحة ثم أعد الحفظ.", "NO_SPACE");
                    return;
                }
                try (InputStream input = connection.getInputStream()) {
                    byte[] header = new byte[12];
                    int headerSize = 0;
                    while (headerSize < header.length) {
                        int read = input.read(header, headerSize, header.length - headerSize);
                        if (read < 0) break;
                        headerSize += read;
                    }
                    if (headerSize < 12 || !"ftyp".equals(new String(header, 4, 4, StandardCharsets.US_ASCII))) {
                        throw new IOException("الملف المستلم ليس MP4 صالحًا.");
                    }
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Video.Media.DISPLAY_NAME, name);
                    values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
                    values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Ayat");
                    values.put(MediaStore.Video.Media.IS_PENDING, 1);
                    saved = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
                    if (saved == null) throw new IOException("تعذر إنشاء ملف الفيديو في مكتبة الهاتف.");
                    long total = header.length;
                    try (OutputStream output = resolver.openOutputStream(saved, "w")) {
                        if (output == null) throw new IOException("تعذر فتح مساحة الحفظ.");
                        output.write(header);
                        byte[] buffer = new byte[65536];
                        int size; long lastProgress = 0;
                        while ((size = input.read(buffer)) != -1) {
                            if (Thread.currentThread().isInterrupted()) throw new IOException("انقطع حفظ الفيديو. أعد المحاولة.");
                            output.write(buffer, 0, size);
                            total += size;
                            if (System.currentTimeMillis() - lastProgress > 300) {
                                JSObject progress = new JSObject();
                                progress.put("bytes", total);
                                progress.put("total", length);
                                notifyListeners("saveProgress", progress);
                                lastProgress = System.currentTimeMillis();
                            }
                        }
                        output.flush();
                    }
                    if (total < 5000 || (length > 0 && total != length)) {
                        throw new IOException("انقطع التنزيل قبل اكتمال MP4. لم يُنشر ملف جزئي.");
                    }
                    ContentValues publish = new ContentValues();
                    publish.put(MediaStore.Video.Media.IS_PENDING, 0);
                    if (resolver.update(saved, publish, null, null) != 1) {
                        throw new IOException("تعذر نشر الفيديو في معرض الهاتف. أعد الحفظ.");
                    }
                    JSObject result = new JSObject();
                    result.put("uri", saved.toString());
                    result.put("name", name);
                    result.put("bytes", total);
                    call.resolve(result);
                }
            } catch (Exception error) {
                if (saved != null) {
                    try { resolver.delete(saved, null, null); } catch (Exception ignored) { }
                }
                String message = error.getMessage() == null ? "تعذر حفظ الفيديو على الهاتف." : error.getMessage();
                boolean noSpace = message.toLowerCase().contains("enospc") || message.toLowerCase().contains("no space");
                call.reject(noSpace ? "نفدت مساحة الهاتف. حرّر مساحة ثم أعد الحفظ." : message,
                    noSpace ? "NO_SPACE" : "VIDEO_SAVE_FAILED");
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    @PluginMethod
    public void copyText(PluginCall call) {
        String text = call.getString("text", "");
        if (text.trim().isEmpty() || text.length() > 18000) {
            call.reject("النص فارغ أو أكبر من حد النسخ.", "INVALID_TEXT");
            return;
        }
        if (getActivity() == null) { call.reject("واجهة الهاتف غير متاحة للنسخ الآن.", "CLIPBOARD_FAILED"); return; }
        getActivity().runOnUiThread(() -> {
            try {
                ClipboardManager clipboard = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard == null) throw new IOException("خدمة الحافظة غير متاحة.");
                clipboard.setPrimaryClip(ClipData.newPlainText("آيات — منشور للنشر", text));
                JSObject result = new JSObject();
                result.put("copied", true);
                call.resolve(result);
            } catch (Exception error) {
                call.reject("تعذر نسخ النص إلى حافظة الهاتف.", "CLIPBOARD_FAILED");
            }
        });
    }

    @PluginMethod
    public void shareVideo(PluginCall call) {
        try {
            Uri uri = Uri.parse(call.getString("uri", ""));
            if (!"content".equals(uri.getScheme())) {
                call.reject("احفظ الفيديو في الهاتف أولًا.", "INVALID_URI"); return;
            }
            try (ParcelFileDescriptor file = getContext().getContentResolver().openFileDescriptor(uri, "r")) {
                if (file == null) throw new IOException("ملف الفيديو لم يعد موجودًا على الهاتف.");
            }
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("video/mp4");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_SUBJECT, call.getString("title", "آيات — ريلز قرآني"));
            send.setClipData(ClipData.newUri(getContext().getContentResolver(), "Ayat MP4", uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().runOnUiThread(() -> {
                try {
                    getActivity().startActivity(Intent.createChooser(send, "مشاركة الريلز"));
                    call.resolve(); // Chooser opened, not a claim that another app finished sharing.
                } catch (Exception error) { call.reject("لا يوجد تطبيق متاح لمشاركة الفيديو.", "SHARE_FAILED"); }
            });
        } catch (Exception error) {
            call.reject(error.getMessage(), "SHARE_FAILED");
        }
    }

    @Override
    protected void handleOnDestroy() {
        worker.shutdownNow();
        super.handleOnDestroy();
    }
}
