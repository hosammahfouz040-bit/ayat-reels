import {ar} from './logic';
export default function AyahRangeFields({from,to,count,error,onChange,compact=false}:{from:string;to:string;count:number;error:string;onChange:(side:'from'|'to',value:string)=>void;compact?:boolean}){
 const helpId=compact?'quick-ayah-range-help':'editor-ayah-range-help';
 return <div className="ayah-range-group">
  <div className="range-fields">
   <label className="field">من الآية<input aria-label="من الآية" type="text" inputMode="numeric" pattern="[0-9٠-٩۰-۹]*" autoComplete="off" dir="ltr" value={from} aria-invalid={!!error} aria-describedby={helpId} onChange={e=>onChange('from',e.target.value)}/></label>
   <span className="range-dash">—</span>
   <label className="field">إلى الآية<input aria-label="إلى الآية" type="text" inputMode="numeric" pattern="[0-9٠-٩۰-۹]*" autoComplete="off" dir="ltr" value={to} aria-invalid={!!error} aria-describedby={helpId} onChange={e=>onChange('to',e.target.value)}/></label>
  </div>
  <p id={helpId} className={error?'ayah-range-error':'ayah-range-hint'} role={error?'alert':undefined}>{error||`السورة ${ar(count)} آية. اكتب البداية والنهاية بالأرقام العربية أو الإنجليزية.`}</p>
 </div>;
}
