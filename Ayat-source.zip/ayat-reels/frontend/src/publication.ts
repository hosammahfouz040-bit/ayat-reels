import type {Catalog,Job} from './types';

export type PublicationPlatform='all'|'tiktok'|'instagram'|'facebook'|'youtube_shorts';
export interface PublicationDraft {title:string;description:string;hashtags:string;platform:PublicationPlatform;suggestion:number;edited:boolean;revision:number;updated:number}
export interface PublicationContext {surah:number;surahName:string;readerName:string;narration:'hafs'|'warsh';numbers:number[];rangeText:string;reference:string;sceneText:string;sceneTags:string[];theme:string;trimmed:boolean}
export const publicationPlatforms:{id:PublicationPlatform;name:string;hint:string}[]=[
 {id:'all',name:'كل المنصات',hint:'العنوان أولًا، ثم الوصف والوسوم. يمكنك نسخ كل جزء بمفرده.'},
 {id:'tiktok',name:'تيك توك',hint:'اقتراح موجز ووسوم مرتبطة بالمقطع، دون وعود بالانتشار.'},
 {id:'instagram',name:'إنستغرام',hint:'العنوان افتتاحية للمنشور، ثم الوصف والوسوم المرتبطة بالريل.'},
 {id:'facebook',name:'فيسبوك',hint:'نص واضح مع دعوة هادئة للاستماع والمشاركة دون مبالغة.'},
 {id:'youtube_shorts',name:'يوتيوب شورتس',hint:'استخدم زر العنوان لحقل العنوان، والوصف والوسوم لحقل الوصف. النسخة الكاملة تجمعها بالترتيب.'},
];
const arabic=(n:number)=>String(n).replace(/\d/g,d=>'٠١٢٣٤٥٦٧٨٩'[Number(d)]);
export function verseNumberGroups(numbers:number[]){const groups:number[][]=[];for(const n of [...new Set(numbers)].sort((a,b)=>a-b)){if(groups.length&&n===groups.at(-1)!.at(-1)!+1)groups.at(-1)!.push(n);else groups.push([n])}return groups}
export function verseRangeText(numbers:number[]){return verseNumberGroups(numbers).map(g=>g.length===1?arabic(g[0]):arabic(g[0])+'–'+arabic(g.at(-1)!)).join('، ')}
function seed(value:string){let h=0;for(const c of value)h=(h*31+c.charCodeAt(0))>>>0;return h}
function limitTitle(value:string){const chars=Array.from(value);return chars.length<=100?value:chars.slice(0,99).join('').replace(/\s+\S*$/,'')+'…'}
export function hashtag(value:string){return '#'+value.normalize('NFD').replace(/[\u064B-\u065F\u0670]/g,'').replace(/[أإآٱ]/g,'ا').replace(/[^\p{L}\p{N}_\s]/gu,'').trim().replace(/\s+/g,'_').replace(/_+/g,'_')}

export function publicationContext(job:Job,catalog:Catalog):PublicationContext{
 const config=job.config;const reader=catalog.reciters.find(r=>r.id===config.reciter);const narration=config.narration||reader?.narration||'hafs';
 const cues=job.result?.timeline?.cues;
 const fromOutput=cues?.filter(c=>c.key.startsWith(config.surah+':')&&c.end>c.start).map(c=>Number(c.key.split(':')[1])).filter(n=>Number.isInteger(n)&&n>0)||[];
 const numbers=fromOutput.length?[...new Set(fromOutput)].sort((a,b)=>a-b):Array.from({length:config.to_ayah-config.from_ayah+1},(_,i)=>config.from_ayah+i);
 const surahName=catalog.surahs.find(s=>s.id===config.surah)?.name||String(config.surah);const rangeText=verseRangeText(numbers);const trimmed=config.audio_trim_start>0||config.audio_trim_end!==null;
 const outputClips=job.result?.timeline?.clips;const sceneIds=outputClips?.length?outputClips.filter(c=>c.start<job.result!.duration&&c.end>0).map(c=>c.scene_id):config.clips.map(c=>c.scene_id);
 const scenes=[...new Set(sceneIds)].map(id=>catalog.scenes.find(s=>s.id===id)).filter(s=>!!s);
 const haram=scenes.some(s=>s.kind==='real-footage'&&s.subject==='mosque'&&s.id.startsWith('haram_'));
 const mosques=scenes.some(s=>s.kind==='real-footage'&&s.subject==='mosque');
 const nature=scenes.some(s=>s.kind==='real-footage'&&s.subject!=='mosque');
 const motion=scenes.some(s=>s.kind==='original-motion-video');
 const visuals:string[]=[];const sceneTags:string[]=[];
 if(haram){visuals.push('مشاهد مصوّرة من الحرم المكي');sceneTags.push('#الحرم_المكي')}else if(mosques){visuals.push('مشاهد مصوّرة لمساجد');sceneTags.push('#مساجد')}
 if(nature){visuals.push('مشاهد من الطبيعة');sceneTags.push('#الطبيعة')}
 if(motion){visuals.push('خلفيات موشن هادئة');sceneTags.push('#خلفيات_هادئة')}
 const sceneText=visuals.length?'ترافق التلاوة '+visuals.join(' و')+'، لتبقى الآيات في قلب المشهد.':'ترافق التلاوة خلفية بصرية هادئة، لتبقى الآيات في قلب المشهد.';
 let theme='وقفة للإصغاء والتدبّر';
 // Editorial topic labels only: no generated ayah, paraphrased tafsir, or religious ruling.
 if(config.surah===112)theme='وقفة تدبّر في معاني التوحيد';
 else if(config.surah===94&&numbers.every(n=>n>=5&&n<=6))theme='وقفة مع معاني اليسر والأمل';
 else if([113,114].includes(config.surah))theme='وقفة مع آيات الاستعاذة';
 else if(config.surah===89&&numbers.every(n=>n>=(narration==='warsh'?30:27)))theme='وقفة تدبّر في ختام سورة الفجر';
 const readerName=reader?.name||'القارئ المحدد';
 const reference=(trimmed?'مقتطف من ':'')+'سورة '+surahName+' | '+(numbers.length===1?'الآية ':'الآيات ')+rangeText+' | بصوت '+readerName+(narration==='warsh'?' | ورش عن نافع، وفق ترقيم ورش':' | حفص عن عاصم');
 return {surah:config.surah,surahName,readerName,narration,numbers,rangeText,reference,sceneText,sceneTags,theme,trimmed};
}
const hooks=[
 'آيات تُطمئن قلبك وتدعو للتدبّر 🤍','وقفة تدبّر مع سورة {surah}','امنح قلبك لحظة إنصات','تلاوة تستحق أن تتأملها','كلام الله… ومساحة للتدبّر','لحظات من الإصغاء للقرآن 🤍','هدوء المشهد وجمال التلاوة','اترك للآيات مساحة في يومك','وقفة هادئة مع سورة {surah}','للقرآن وقتٌ يليق بالإنصات','تأمّل الآيات واستمع بقلبك','دقائق للتدبّر بعيدًا عن الضجيج','من سورة {surah}… تلاوة للتأمل','{theme} 🤍','لحظة قرآن في يوم مزدحم','حين تختار أن تُنصت للقرآن',
];
const openings=[
 'وسط ضجيج الحياة، امنح قلبك لحظات للإنصات إلى كلام الله الكريم.',
 'وقفة قصيرة مع القرآن، نُصغي فيها للآيات ونتأمل معانيها.',
 'دع انشغال اليوم قليلًا، وخذ لحظة للاستماع بتدبّر.',
 'ليكن في يومك وقتٌ للقرآن، تُنصت فيه بقلب حاضر.',
 'مشهد هادئ وتلاوة ندعوك للاستماع إليها بتأنٍّ.',
 'مع هذه التلاوة، نترك للآيات مساحة من الانتباه والتدبّر.',
 'لحظات نعود فيها إلى القرآن، بعيدًا عن تشتّت اليوم.',
 'استمع إلى هذا المقطع بتأنٍّ، واجعل للمعنى نصيبًا من انتباهك.',
 'للإنصات وقت، وللتدبّر أثرٌ نرجوه. هذه وقفة قصيرة مع القرآن.',
 'أغلق باب الانشغال لحظة، وافتح للآيات مساحة من يومك.',
 'دع جمال التلاوة يرافق وقفتك مع القرآن، واستمع بتدبّر.',
 'هذه دعوة هادئة للإصغاء إلى القرآن والتأمل، لا للاستعجال في المرور.',
];
const invitations=[
 'استمع بتدبّر، وشارك المقطع مع من تحب. 🤍',
 'يمكنك حفظ المقطع للعودة إليه، ومشاركته مع من يرغب في الاستماع.',
 'شارك هذه الوقفة القرآنية مع من تحب، دون تكلّف أو مبالغة.',
 'إن أحببت هذه التلاوة، احفظها لوقت من الهدوء والإنصات.',
 'دع الآيات تأخذ وقتها من الإصغاء، ثم شارك المقطع إن رغبت.',
 'وقفة للتدبّر يمكنك العودة إليها في أي وقت.',
 'استمع أولًا، وتأمل، ثم شارك المقطع مع من تختار.',
 'اجعل مشاركتك دعوة لطيفة للاستماع والتدبّر.',
];
const prayers=[
 'اللهم اجعل القرآن ربيع قلوبنا ونور صدورنا.',
 'اللهم ارزقنا حسن الاستماع والتدبّر والعمل بما نتعلّم.',
 'اللهم اجعل لنا من تلاوة القرآن نصيبًا ومن تدبّره نورًا.',
 'اللهم أعنّا على تدبّر كلامك والعمل به.',
 'اللهم ارزقنا قلبًا حاضرًا عند تلاوة القرآن.',
];
export function generatePublication(job:Job,catalog:Catalog,suggestion=0,platform:PublicationPlatform='all'):PublicationDraft{
 if(job.state!=='completed'||!job.result)throw Error('تجهيز المنشور متاح بعد اكتمال المقطع فقط.');
 const c=publicationContext(job,catalog);const n=Math.max(0,Math.floor(suggestion));const s=seed(job.id);const prefix=hooks[(s+n)%hooks.length].replace('{surah}',c.surahName).replace('{theme}',c.theme);
 const title=limitTitle(prefix+(prefix.includes(c.surahName)?'':' | سورة '+c.surahName)+' بصوت '+c.readerName);
 const intro=openings[(s+n)%openings.length];const invitation=invitations[(Math.floor(s/7)+n)%invitations.length];const prayer=prayers[(Math.floor(s/11)+n)%prayers.length];
 const description=[intro,c.reference,c.theme+'. '+c.sceneText,invitation,prayer].join('\n\n');
 const platformTag:Record<PublicationPlatform,string>={all:'#ريلز_قرآني',tiktok:'#تيك_توك',instagram:'#ريلز_قرآني',facebook:'#فيديو_قرآني',youtube_shorts:'#يوتيوب_شورتس'};
 const extra=['#تدبر_القرآن','#تلاوة_خاشعة','#آيات_قرآنية','#سكينة','#استماع_للقرآن'];
 const rotated=extra.slice(n%extra.length).concat(extra.slice(0,n%extra.length));
 const candidates=['#القرآن_الكريم',hashtag('سورة '+c.surahName),hashtag(c.readerName),platformTag[platform],...c.sceneTags,...rotated];
 const count:Record<PublicationPlatform,number>={all:9,tiktok:6,instagram:9,facebook:6,youtube_shorts:7};
 const tags=[...new Set(candidates)].slice(0,count[platform]);
 return {title,description,hashtags:tags.join(' '),platform,suggestion:n,edited:false,revision:0,updated:0};
}
export function fullPublication(p:Pick<PublicationDraft,'title'|'description'|'hashtags'>){return [p.title.trim(),p.description.trim(),p.hashtags.trim()].filter(Boolean).join('\n\n')}
export function publicationCacheKey(workspace:string,jobId:string){return 'ayat.publication.v1:'+workspace+':'+jobId}
export function cleanPublication(value:unknown):PublicationDraft|null{
 if(!value||typeof value!=='object')return null;const v=value as Partial<PublicationDraft>;
 if(typeof v.title!=='string'||typeof v.description!=='string'||typeof v.hashtags!=='string'||!publicationPlatforms.some(p=>p.id===v.platform))return null;
 if(v.title.length>140||v.description.length>4000||v.hashtags.length>1500)return null;
 return {title:v.title,description:v.description,hashtags:v.hashtags,platform:v.platform!,suggestion:Math.min(1000000,Math.max(0,Math.floor(Number(v.suggestion)||0))),edited:!!v.edited,revision:Math.max(0,Math.floor(Number(v.revision)||0)),updated:Number(v.updated)||0};
}
