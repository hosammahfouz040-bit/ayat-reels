import {useEffect,useMemo,useRef,useState} from 'react';
import {Check,Copy,CloudOff,Loader2,RotateCcw,Sparkles,AlertCircle,CheckCircle2} from 'lucide-react';
import type {Catalog,Job} from './types';
import {api,ApiError,copyPublicationText,workspace} from './api';
import {cleanPublication,fullPublication,generatePublication,publicationCacheKey,publicationContext,publicationPlatforms} from './publication';
import type {PublicationDraft,PublicationPlatform} from './publication';
import './publication.css';

type Stored={draft:PublicationDraft;dirty:boolean};
function load(key:string):Stored|null{try{const raw=JSON.parse(localStorage.getItem(key)||'null');const draft=cleanPublication(raw?.draft);return draft?{draft,dirty:!!raw.dirty}:null}catch{return null}}
const same=(a:PublicationDraft,b:PublicationDraft)=>['title','description','hashtags','platform','suggestion','edited'].every(k=>a[k as keyof PublicationDraft]===b[k as keyof PublicationDraft]);

export default function PublicationPanel({job,catalog,notify}:{job:Job;catalog:Catalog;notify:(message:string,tone?:'success'|'error')=>void}){
 const cacheKey=publicationCacheKey(workspace,job.id);const initial=useRef<Stored|null|undefined>(undefined);
 if(initial.current===undefined)initial.current=load(cacheKey);
 const [draft,setDraft]=useState<PublicationDraft>(()=>initial.current?.draft||generatePublication(job,catalog));
 const [dirty,setDirty]=useState(initial.current?.dirty??true);const [serverReady,setServerReady]=useState(false);
 const [status,setStatus]=useState<'local'|'loading'|'saving'|'saved'>('local');const [error,setError]=useState('');const [localError,setLocalError]=useState(false);
 const [conflict,setConflict]=useState<PublicationDraft|null>(null);const [undo,setUndo]=useState<PublicationDraft|null>(null);
 const [copied,setCopied]=useState('');const [manual,setManual]=useState<{name:string;text:string}|null>(null);const manualRef=useRef<HTMLTextAreaElement>(null);
 const current=useRef(draft),dirtyRef=useRef(dirty),revision=useRef(draft.revision),epoch=useRef(0),alive=useRef(true),inFlight=useRef(false),everLoaded=useRef(false);
 const context=useMemo(()=>publicationContext(job,catalog),[job.id]);const full=fullPublication(draft);const platform=publicationPlatforms.find(p=>p.id===draft.platform)!;
 function persist(value:PublicationDraft,isDirty:boolean){try{localStorage.setItem(cacheKey,JSON.stringify({draft:value,dirty:isDirty}));setLocalError(false)}catch{setLocalError(true)}}
 function change(value:PublicationDraft){epoch.current++;current.current=value;dirtyRef.current=true;setDraft(value);setDirty(true);setStatus('local');setError('');setCopied('');persist(value,true)}
 function acknowledge(value:PublicationDraft){revision.current=value.revision;current.current=value;dirtyRef.current=false;setDraft(value);setDirty(false);setStatus('saved');setError('');persist(value,false)}
 async function fetchSaved(){
  const before=epoch.current;const first=!everLoaded.current;setStatus('loading');setError('');
  try{
   const reply=await api<{publication:unknown}>('/jobs/'+job.id+'/publication');if(!alive.current)return;
   const remote=cleanPublication(reply.publication);const untouched=epoch.current===before;
   if(remote){
    if(untouched&&(!dirtyRef.current||(!initial.current&&first&&before===0))){acknowledge(remote);setConflict(null)}
    else if(remote.revision!==revision.current&&!same(remote,current.current)){setConflict(remote);setStatus('local')}
    else if(untouched&&same(remote,current.current)){acknowledge(remote)}
    else{revision.current=remote.revision;const next={...current.current,revision:remote.revision};current.current=next;setDraft(next);persist(next,true);setStatus('local')}
   }else{
    revision.current=0;const next={...current.current,revision:0};current.current=next;dirtyRef.current=true;setDraft(next);setDirty(true);persist(next,true);setStatus('local');
   }
   setServerReady(true);
  }catch(exc){if(!alive.current)return;setServerReady(false);setStatus('local');setError((exc as Error).message+' المحتوى المقترح متاح محليًا للتعديل والنسخ.')}
  finally{everLoaded.current=true}
 }
 async function sync(){
  if(!alive.current||inFlight.current||!dirtyRef.current||conflict||!serverReady)return;
  inFlight.current=true;const before=epoch.current;const body={...current.current,revision:revision.current};setStatus('saving');
  try{
   const reply=await api<{publication:unknown}>('/jobs/'+job.id+'/publication','PUT',{title:body.title,description:body.description,hashtags:body.hashtags,platform:body.platform,suggestion:body.suggestion,edited:body.edited,revision:body.revision});
   if(!alive.current)return;const saved=cleanPublication(reply.publication);if(!saved)throw Error('استجابة حفظ المنشور غير صالحة.');
   revision.current=saved.revision;
   if(epoch.current===before)acknowledge(saved);
   else{const next={...current.current,revision:saved.revision};current.current=next;setDraft(next);persist(next,true);setStatus('local')}
  }catch(exc){
   if(!alive.current)return;
   if(exc instanceof ApiError&&exc.status===409){
    try{const data=await api<{publication:unknown}>('/jobs/'+job.id+'/publication');if(alive.current){const remote=cleanPublication(data.publication);if(remote){setConflict(remote);setError('توجد نسخة أحدث محفوظة. اختر النسخة التي تريد الاحتفاظ بها.')}else{revision.current=0;const next={...current.current,revision:0};current.current=next;setDraft(next);persist(next,true)}setStatus('local')}}catch{setServerReady(false);setError('تعذر التحقق من النسخة الأحدث. تعديلاتك المحلية باقية.')}
   }else{setServerReady(false);setStatus('local');setError('تعذرت المزامنة مع الخادم. تعديلاتك باقية على هذا الجهاز ويمكن نسخها.')}
  }finally{inFlight.current=false}
 }
 useEffect(()=>{alive.current=true;persist(current.current,dirtyRef.current);void fetchSaved();return()=>{alive.current=false}},[job.id]);
 useEffect(()=>{if(!serverReady||!dirty||conflict)return;const timer=setTimeout(()=>void sync(),550);return()=>clearTimeout(timer)},[draft,dirty,serverReady,conflict]);
 useEffect(()=>{if(manual&&manualRef.current){manualRef.current.focus({preventScroll:true});manualRef.current.select();manualRef.current.setSelectionRange(0,manual.text.length)}},[manual]);
 useEffect(()=>{if(!copied)return;const timer=setTimeout(()=>setCopied(''),1800);return()=>clearTimeout(timer)},[copied]);
 function edit(field:'title'|'description'|'hashtags',value:string){change({...current.current,[field]:value,edited:true})}
 function suggest(){setUndo({...current.current});const next=generatePublication(job,catalog,(current.current.suggestion+1)%1000000,current.current.platform);change({...next,revision:revision.current});setManual(null)}
 async function copy(kind:'title'|'description'|'hashtags'|'all'){
  const names={title:'العنوان',description:'الوصف',hashtags:'الهاشتاجات',all:'المنشور كاملًا'};const text=kind==='all'?fullPublication(current.current):current.current[kind];
  const result=await copyPublicationText(text);if(!alive.current)return;
  if(result.ok){setCopied(kind);setManual(null);notify('نُسخ '+names[kind]+' إلى الحافظة.')}
  else{setCopied('');setManual({name:names[kind],text});notify(result.message||'لم يكتمل النسخ التلقائي. استخدم النص المحدد للنسخ اليدوي.','error')}
 }
 function copyButton(kind:'title'|'description'|'hashtags',label:string){return <button type="button" className="post-copy" disabled={!draft[kind].trim()} onClick={()=>void copy(kind)} aria-label={'نسخ '+label} data-testid={'copy-post-'+kind}>{copied===kind?<Check size={14}/>:<Copy size={14}/>} {copied===kind?'نُسخ':'نسخ '+label}</button>}
 return <section className="publication-panel" data-testid="publication-panel" aria-label="تجهيز المنشور للنشر">
  <div className="publication-heading"><span className="publication-icon"><Sparkles size={21}/></span><div><span className="post-eyebrow">المقطع مكتمل · الخطوة التالية</span><h3>تجهيز المنشور للنشر</h3><p>اقتراح عربي مبني على المقطع المُصدّر، منفصل تمامًا عن نص القرآن داخل الفيديو.</p></div></div>
  <div className="post-context" data-testid="publication-context">{context.reference}</div>
  <div className="post-platforms" role="group" aria-label="منصة النشر">{publicationPlatforms.map(p=><button type="button" key={p.id} aria-pressed={draft.platform===p.id} className={draft.platform===p.id?'active':''} onClick={()=>change({...current.current,platform:p.id as PublicationPlatform})} data-testid={'post-platform-'+p.id}>{p.name}</button>)}</div>
  <p className="post-platform-hint">{platform.hint} تغيير المنصة لا يمسح تعديلاتك؛ يؤثر أيضًا على الاقتراح التالي.</p>
  <div className="post-field"><div className="post-field-top"><label htmlFor={'post-title-'+job.id}>العنوان</label>{copyButton('title','العنوان')}</div><input id={'post-title-'+job.id} aria-label="عنوان المنشور" value={draft.title} maxLength={140} onChange={e=>edit('title',e.target.value)} data-testid="post-title"/><small><bdi dir="ltr">{draft.title.length} / 140</bdi> حرفًا · الاقتراحات الأصلية موجزة</small></div>
  <div className="post-field"><div className="post-field-top"><label htmlFor={'post-description-'+job.id}>الوصف</label>{copyButton('description','الوصف')}</div><textarea id={'post-description-'+job.id} aria-label="وصف المنشور" rows={7} value={draft.description} maxLength={4000} onChange={e=>edit('description',e.target.value)} data-testid="post-description"/><small><bdi dir="ltr">{draft.description.length} / 4000</bdi> حرف</small></div>
  <div className="post-field"><div className="post-field-top"><label htmlFor={'post-hashtags-'+job.id}>الهاشتاجات</label>{copyButton('hashtags','الهاشتاجات')}</div><textarea id={'post-hashtags-'+job.id} aria-label="هاشتاجات المنشور" rows={3} value={draft.hashtags} maxLength={1500} onChange={e=>edit('hashtags',e.target.value)} data-testid="post-hashtags"/><small>وسوم مرتبطة بالسورة والقارئ والمشاهد، وليست ادعاءً بأنها رائجة أو تضمن الوصول.</small></div>
  <div className="post-actions"><button type="button" className="primary post-copy-all" onClick={()=>void copy('all')} disabled={!full.trim()} data-testid="copy-post-all">{copied==='all'?<Check size={17}/>:<Copy size={17}/>} {copied==='all'?'نُسخ المنشور كاملًا':'نسخ المنشور كاملًا'}</button><button type="button" className="secondary" onClick={suggest} data-testid="post-suggest"><Sparkles size={16}/> اقتراح آخر</button></div>
  {undo&&<button type="button" className="post-undo" onClick={()=>{const previous=undo;setUndo(null);change({...previous,revision:revision.current})}} data-testid="post-undo"><RotateCcw size={14}/> تراجع لاستعادة النص السابق وتعديلاتك</button>}
  <details className="post-full-preview"><summary>معاينة المنشور كاملًا · {full.length} حرفًا</summary><textarea readOnly aria-label="المنشور كاملًا" value={full} rows={10} data-testid="post-full-preview"/></details>
  <div className={'post-save-status '+(error||localError?'has-error':'')} role="status" data-testid="post-save-status">{status==='saving'||status==='loading'?<Loader2 className="spin" size={14}/>:status==='saved'&&!dirty?<CheckCircle2 size={14}/>:<CloudOff size={14}/>}<span>{localError?'تعذر الحفظ المحلي. انسخ النص للاحتفاظ به.':status==='saved'&&!dirty?'محفوظ مع هذا المقطع':status==='saving'?'جارٍ حفظ المنشور…':'نسخة محلية على هذا الجهاز'}{draft.edited?' · عُدّل يدويًا':''}</span></div>
  {error&&<div className="post-sync-note"><p>{error}</p>{!conflict&&<button type="button" onClick={()=>void fetchSaved()} data-testid="post-retry-sync">إعادة محاولة المزامنة</button>}</div>}
  {conflict&&<div className="post-conflict" data-testid="post-conflict"><strong>توجد نسخة أحدث محفوظة</strong><p>لن نستبدل ما تكتبه تلقائيًا.</p><button type="button" onClick={()=>{acknowledge(conflict);setConflict(null);setServerReady(true)}}>استخدم النسخة المحفوظة</button><button type="button" onClick={()=>{revision.current=conflict.revision;setConflict(null);setServerReady(true);change({...current.current,revision:conflict.revision})}} data-testid="post-keep-local">احتفظ بتعديلاتي</button></div>}
  {manual&&<div className="post-manual-copy" data-testid="post-manual-copy"><strong><AlertCircle size={15}/> النسخ اليدوي — {manual.name}</strong><p>لم يسمح المتصفح بالنسخ التلقائي. النص محدد أدناه؛ اضغط مطولًا واختر «نسخ»، أو استخدم Ctrl+C.</p><textarea ref={manualRef} readOnly aria-label="النص المحدد للنسخ اليدوي" value={manual.text} rows={6}/></div>}
  <p className="post-disclaimer">اقتراحات محلية مجانية دون اشتراك أو خدمة ذكاء اصطناعي مدفوعة. راجع النص قبل النشر. لا نشر تلقائي ولا ضمان لزيادة المشاهدات.</p>
 </section>
}
