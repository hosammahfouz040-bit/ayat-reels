import {useEffect,useMemo,useRef,useState} from 'react';
import type {AudioPlan,Catalog,Config,QuranData} from './types';
import type {SceneAssetStatus} from './api';
import type {RefObject} from 'react';
import {sceneVideo,scenePoster,prepareSceneAsset} from './api';
import {clipTimeline,verseAt,ar} from './logic';
import {effectsOf,effectEnabled} from './effects';
import CompositionPreview from './CompositionPreview';
import FxSceneCanvas from './FxSceneCanvas';

export default function VideoPreview({config,plan,quran,catalog,time=0,playing=false,small=false,audioRef}:{config:Config;plan:AudioPlan|null;quran:QuranData;catalog:Catalog;time?:number;playing?:boolean;small?:boolean;audioRef?:RefObject<HTMLAudioElement|null>}){
 const videos=useRef<Record<string,HTMLVideoElement|null>>({});const holder=useRef<HTMLDivElement>(null);const [previewWidth,setPreviewWidth]=useState(300);const [visualPreview,setVisualPreview]=useState(false),[demoTime,setDemoTime]=useState(0);
 const effects=effectsOf(config);const fxKey=JSON.stringify(effects);const timeline=useMemo(()=>clipTimeline(config,plan),[config.clips,config.auto_fit,config.audio_trim_end,config.audio_trim_start,plan]);
 const total=plan?Math.max(.25,(config.audio_trim_end??plan.duration)-config.audio_trim_start):18;
 const anyFx=Object.values(effects).some(f=>effectEnabled(f))||config.clips.some(c=>['light','mist'].includes(c.transition)&&c.transition_enabled!==false&&(c.transition_intensity??1)>0);
 const canvasFx=effectEnabled(effects.camera)||effectEnabled(effects.scene)||config.clips.some(c=>['light','mist'].includes(c.transition)&&c.transition_enabled!==false&&(c.transition_intensity??1)>0);
 useEffect(()=>{if(anyFx){setDemoTime(0);setVisualPreview(true)}else{setVisualPreview(false);setDemoTime(0)}},[fxKey,JSON.stringify(config.clips.map(c=>[c.transition,c.transition_enabled,c.transition_intensity,c.transition_duration]))]);
 const previousTime=useRef(time);useEffect(()=>{if(previousTime.current!==time&&!playing)setVisualPreview(false);previousTime.current=time},[time]);
 useEffect(()=>{if(!visualPreview||playing)return;let raf=0,last=0;const start=performance.now();function step(now:number){raf=requestAnimationFrame(step);if(now-last<1000/24)return;last=now;setDemoTime(((now-start)/1000)%total)}raf=requestAnimationFrame(step);return()=>cancelAnimationFrame(raf)},[visualPreview,playing,total,fxKey]);
 const [audioClock,setAudioClock]=useState(time);const audioAnchor=useRef({time,at:performance.now()});
 useEffect(()=>{audioAnchor.current={time,at:performance.now()};setAudioClock(time)},[time]);
 useEffect(()=>{if(!playing||!anyFx)return;let id=0,last=0;function tick(now:number){id=requestAnimationFrame(tick);if(now-last<1000/24)return;last=now;setAudioClock(audioRef?.current?.currentTime??audioAnchor.current.time+Math.min(.3,(now-audioAnchor.current.at)/1000))}id=requestAnimationFrame(tick);return()=>cancelAnimationFrame(id)},[playing,anyFx,audioRef]);
 const actualTime=playing&&anyFx?audioClock:time;
 const absolute=(visualPreview&&!playing)?config.audio_trim_start+demoTime:actualTime;const position=(visualPreview&&!playing)?demoTime:plan?Math.max(0,actualTime-config.audio_trim_start):0;
 const active=timeline.filter(c=>position>=c.start-.01&&position<c.end).slice(-2);const visible=active.length?active:[timeline[timeline.length-1]];
 const current=verseAt(config,plan,quran,absolute);const style=config.text_style;const fontFamily=quran.font_family||(style.font==='amiri_quran'?'AmiriQuran':'Amiri');
 useEffect(()=>{if(!holder.current)return;const o=new ResizeObserver(e=>setPreviewWidth(e[0].contentRect.width));o.observe(holder.current);return()=>o.disconnect()},[]);
 useEffect(()=>{for(const clip of visible){const v=videos.current[clip.id];if(!v)continue;const shouldPlay=playing||visualPreview||!plan;const desired=clip.source_in+(Math.max(0,position-clip.start)%(clip.source_out-clip.source_in));if(Number.isFinite(v.duration)&&Math.abs(v.currentTime-desired)>.36)v.currentTime=desired;if(shouldPlay){void v.play().catch(()=>{})}else v.pause()}},[position,playing,visualPreview,plan,JSON.stringify(visible.map(v=>v.id))]);
 const [assets,setAssets]=useState<Record<string,SceneAssetStatus>>({}),[assetRetry,setAssetRetry]=useState(0);
 const needed=visible.filter(Boolean).map(c=>c.scene_id).filter(id=>catalog.scenes.find(s=>s.id===id)?.availability==='on-demand');const neededKey=needed.join(',');
 useEffect(()=>{let alive=true;for(const id of needed){if(assets[id]?.state==='ready')continue;setAssets(s=>({...s,[id]:{scene_id:id,state:'queued',progress:0,message:'تجهيز المشهد الإضافي على الخادم…',bundled:false}}));void prepareSceneAsset(id,value=>{if(alive)setAssets(s=>({...s,[id]:value}))}).catch(e=>{if(alive)setAssets(s=>({...s,[id]:{scene_id:id,state:'failed',progress:0,message:(e as Error).message,bundled:false}}))})}return()=>{alive=false}},[neededKey,assetRetry]);
 const missing=needed.map(id=>assets[id]).find(s=>!s||s.state!=='ready');const waiting=needed.some(id=>assets[id]?.state!=='ready');const canvasReady=canvasFx&&!waiting;
 const credits=visible.flatMap(c=>{const scene=c&&catalog.scenes.find(s=>s.id===c.scene_id);return scene&&(scene.requires_attribution||scene.attribution_requested)?[scene]:[]}).filter((s,i,all)=>all.findIndex(x=>x.source_url===s.source_url)===i);
 return <><div ref={holder} className={'video-preview '+(small?'is-small':'')} data-testid="video-preview" data-effects-preview={visualPreview&&!playing?'playing':'paused'} data-effects-time={position.toFixed(3)} style={{background:'#102e27',backgroundImage:waiting&&visible[0]?`url(${scenePoster(visible[0].scene_id)})`:undefined,backgroundSize:'cover'}}>
  {visible.map((clip,i)=>{if(!clip)return null;const prev=i>0?visible[i-1]:null;const overlap=prev?Math.max(0,Math.min(1,(position-clip.start)/Math.max(.04,prev.transition_seconds))):1;const transition=prev?.transition;return <video key={clip.id} ref={v=>{videos.current[clip.id]=v}} src={catalog.scenes.find(s=>s.id===clip.scene_id)?.availability==='on-demand'&&assets[clip.scene_id]?.state!=='ready'?undefined:sceneVideo(clip.scene_id)} poster={scenePoster(clip.scene_id)} autoPlay={!plan||visualPreview} loop muted playsInline preload="metadata" className="preview-background" style={{opacity:canvasReady?0:transition==='fade'?overlap:1,clipPath:transition==='wipeleft'?`inset(0 0 0 ${(1-overlap)*100}%)`:undefined,transform:transition==='slideup'?`translateY(${(1-overlap)*100}%)`:undefined}} onLoadedMetadata={e=>{const v=e.currentTarget;v.currentTime=clip.source_in;if(playing||visualPreview||!plan)void v.play().catch(()=>{});else v.pause()}}/>})}
  {canvasReady&&<FxSceneCanvas videos={videos} clips={timeline} visible={visible} position={position} total={total} effects={effects} seed={config.surah*101+config.from_ayah*17}/>}
  <div className="preview-vignette"/>
  <CompositionPreview config={config} catalog={catalog} family={fontFamily} current={{text:current?.text||'',start:current?.start??0,end:current?.end??18,number:current?.number}} time={absolute}/>
  {credits.length>0&&<div className="preview-visual-credits" dir="ltr" style={{fontSize:Math.max(5.5,previewWidth/540*10)}}>{credits.map(s=><span key={s.id}>{s.source_credit_title||s.name} · {s.copyright_notice||s.author} · {s.license_label||s.license.replace('CC-BY-','CC BY ')} · cropped, muted<br/>{s.source_short_url} · {s.license_url?.replace('https://','')}</span>)}</div>}
  {waiting&&<div className="preview-asset-notice" role="status">{missing?.message||'الفيديو الإضافي يحتاج اتصالًا وتنزيلًا أول مرة'}{missing?.state==='failed'&&<button onClick={()=>setAssetRetry(n=>n+1)}>إعادة تنزيل المشهد</button>}</div>}
  {!small&&<div className="preview-aspect">9:16</div>}
 </div>
  {!small&&anyFx&&<button type="button" className="fx-preview-toggle" disabled={playing} onClick={()=>{setDemoTime(0);setVisualPreview(v=>!v)}} data-testid="effects-preview-toggle">{playing?'معاينة مرتبطة بالصوت':visualPreview?'إيقاف المعاينة البصرية':'تشغيل معاينة المؤثرات'}{!playing&&<small>دون تشغيل صوت</small>}</button>}
 </>
}
