import {useEffect,useRef,useState} from 'react';
import type {RefObject} from 'react';
import type {Job} from './types';
import {api,ApiError} from './api';
import {ACTIVE_JOB_STATES,canAdoptJob,jobSnapshot,serverScope} from './jobRecovery';
export interface ExportReference {kind:'job'|'request';id:string}
export type ExportConnectionStatus='idle'|'checking'|'connected'|'offline'|'server_error'|'missing'|'invalid_server';
export interface ExportConnection {key:string;status:ExportConnectionStatus;message:string;last_confirmed:number;failures:number;retry_at:number}
const blank=(key=''):ExportConnection=>({key,status:key?'checking':'idle',message:'',last_confirmed:0,failures:0,retry_at:0});

/** Single-flight status polling: no overlapping 20-second GETs or stale response regression. */
export function useJobMonitor(reference:ExportReference|null,currentJob:RefObject<Job|null>,onJob:(job:Job)=>void,onCompleted:()=>void){
 const key=reference?reference.kind+':'+reference.id:'',scope=serverScope();const [state,setState]=useState<ExportConnection>(()=>blank(key)),[wake,setWake]=useState(0);const callbacks=useRef({onJob,onCompleted});callbacks.current={onJob,onCompleted};
 const refresh=()=>setWake(n=>n+1);
 useEffect(()=>{
  if(!reference){setState(blank());return}
  const tracked={...reference},trackedKey=key;let disposed=false;const abort=new AbortController();let delayTimer:ReturnType<typeof setTimeout>|null=null;let releaseWait:(()=>void)|null=null;let failures=0;
  const snapshot=jobSnapshot();let confirmed=snapshot?.job.id===tracked.id?snapshot.saved_at:0;
  setState({...blank(trackedKey),last_confirmed:confirmed});
  function pause(ms:number){return new Promise<void>(resolve=>{releaseWait=resolve;delayTimer=setTimeout(resolve,ms)})}
  async function loop(){
   while(!disposed){
    try{
     const path=tracked.kind==='request'?'/jobs/by-request/'+tracked.id:'/jobs/'+tracked.id;
     const next=await api<Job>(path,'GET',undefined,{signal:abort.signal,timeoutMs:7000});
     if(disposed)return;
     if(!next?.id||!next.config||!['queued','preparing','rendering','validating','completed','failed','interrupted','canceled'].includes(next.state)||(tracked.kind==='job'&&next.id!==tracked.id))throw new ApiError('استجابة حالة التصدير غير صالحة. راجع عنوان الخادم.','INVALID_RESPONSE');
     const current=currentJob.current;
     // A late old-job response cannot overwrite a retry/new export or a confirmed cancel.
     if(tracked.kind==='job'&&current&&current.id!==tracked.id)return;
     if(canAdoptJob(current,next))callbacks.current.onJob(next);
     confirmed=Date.now();failures=0;setState({key:trackedKey,status:'connected',message:'',last_confirmed:confirmed,failures:0,retry_at:0});
     if(!ACTIVE_JOB_STATES.includes(next.state)){if(next.state==='completed')callbacks.current.onCompleted();return}
     if(currentJob.current&&!ACTIVE_JOB_STATES.includes(currentJob.current.state))return;
     await pause(document.visibilityState==='hidden'?5000:1000);
    }catch(error){
     if(disposed||abort.signal.aborted)return;
     failures++;const e=error as ApiError;
     if(e.status===404&&e.code!=='INVALID_RESPONSE'){
      setState({key:trackedKey,status:'missing',message:tracked.kind==='request'?'لم يُسجّل هذا الطلب في الخادم المتصل. يمكنك إعادة إرساله من المسودة.':'الخادم متصل لكنه لا يجد سجل هذا التصدير في مساحة عملك. قد تكون المعاينة أُعيد تشغيلها أو تغيّر الخادم؛ لا يمكن تأكيد استمرار التصدير.',last_confirmed:confirmed,failures,retry_at:0});return;
     }
     const invalid=['INVALID_RESPONSE','SERVER_CONFIG'].includes(e.code)||[400,401,403].includes(e.status);
     if(invalid){setState({key:trackedKey,status:'invalid_server',message:e.message,last_confirmed:confirmed,failures,retry_at:0});return}
     const ms=Math.min(8000,1000*2**Math.min(3,failures-1));setState({key:trackedKey,status:e.status>=500?'server_error':'offline',message:e.status>=500?'الخادم ردّ بخطأ ولم نتأكد من تقدم التصدير. سنعيد فحص الحالة.':'تعذّر الوصول إلى الخادم؛ حالة التصدير غير مؤكدة. لا نعتبره مكتملًا ولا نبدأ نسخة ثانية تلقائيًا.',last_confirmed:confirmed,failures,retry_at:Date.now()+ms});await pause(ms);
    }
   }
  }
  void loop();
  return()=>{disposed=true;abort.abort();if(delayTimer)clearTimeout(delayTimer);releaseWait?.()};
 },[key,scope,wake]);
 useEffect(()=>{const online=()=>refresh(),visible=()=>{if(document.visibilityState==='visible')refresh()};addEventListener('online',online);addEventListener('pageshow',online);document.addEventListener('visibilitychange',visible);return()=>{removeEventListener('online',online);removeEventListener('pageshow',online);document.removeEventListener('visibilitychange',visible)}},[]);
 return {connection:state.key===key?state:blank(key),refreshJobStatus:refresh};
}
