import {useEffect,useRef} from 'react';
import type {MutableRefObject} from 'react';
import type {Clip} from './types';
import {cameraValues,clamp,drawAtmosphere,effectEnabled,fxEnvelope} from './effects';
import type {VisualEffects} from './effects';
export type RenderClip=Clip&{start:number;end:number;transition_seconds:number};
export default function FxSceneCanvas({videos,clips,visible,position,total,effects,seed}:{videos:MutableRefObject<Record<string,HTMLVideoElement|null>>;clips:RenderClip[];visible:RenderClip[];position:number;total:number;effects:VisualEffects;seed:number}){
 const canvas=useRef<HTMLCanvasElement>(null);const live=useRef({clips,visible,position,total,effects,seed});live.current={clips,visible,position,total,effects,seed};
 useEffect(()=>{
  const target=canvas.current;if(!target)return;target.width=540;target.height=960;const ctx=target.getContext('2d');if(!ctx)return;
  const pool=Array.from({length:5},()=>{const c=document.createElement('canvas');c.width=540;c.height=960;return c});let frame=0,last=0;
  function sceneLayer(c:RenderClip,slot:number){
   const v=videos.current[c.id];if(!v||v.readyState<2||!v.videoWidth)return null;
   const {position,effects,total,clips}=live.current;const out=pool[slot],d=out.getContext('2d')!;const w=out.width,h=out.height;d.clearRect(0,0,w,h);
   const local=Math.max(0,position-c.start);const camera=cameraValues(effects.camera,local,c.duration);const fill=Math.max(w/v.videoWidth,h/v.videoHeight),cw=w/fill,ch=h/fill;const sw=cw/camera.zoom,sh=ch/camera.zoom;
   const sx=(v.videoWidth-cw)/2+(cw-sw)*camera.x,sy=(v.videoHeight-ch)/2+(ch-sh)*camera.y;d.drawImage(v,sx,sy,sw,sh,0,0,w,h);
   const scratch=pool[2],s=scratch.getContext('2d')!,mask=pool[3],m=mask.getContext('2d')!;
   function blurred(sigma:number,alpha:number,brightness=1,edge=false){
    if(alpha<=0)return;s.clearRect(0,0,w,h);s.save();s.filter=`blur(${sigma}px) brightness(${brightness})`;s.drawImage(out,0,0);s.restore();
    if(edge){m.clearRect(0,0,w,h);const radius=Math.sqrt(w*w+h*h)*.5,g=m.createRadialGradient(w/2,h/2,0,w/2,h/2,radius);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(.24,'rgba(0,0,0,0)');g.addColorStop(1,`rgba(0,0,0,${alpha})`);m.fillStyle=g;m.fillRect(0,0,w,h);s.globalCompositeOperation='destination-in';s.drawImage(mask,0,0);s.globalCompositeOperation='source-over';d.drawImage(scratch,0,0)}
    else{d.save();d.globalAlpha=alpha;d.drawImage(scratch,0,0);d.restore()}
   }
   if(effectEnabled(effects.camera)&&effects.camera.kind==='depth')blurred(1+4*effects.camera.intensity,.65*effects.camera.intensity,1,true);
   if(effectEnabled(effects.scene)&&effects.scene.kind==='bloom')blurred(2+6*effects.scene.intensity,.3*effects.scene.intensity*fxEnvelope(position,effects.scene.duration,total),1+.08*effects.scene.intensity);
   const index=clips.findIndex(x=>x.id===c.id),prev=index>0?clips[index-1]:undefined;let mist=0;
   if(prev?.transition==='mist'&&prev.transition_seconds>0&&local<=prev.transition_seconds)mist+=.6*(prev.transition_intensity??1)*Math.sin(Math.PI*local/prev.transition_seconds);
   if(c.transition==='mist'&&c.transition_seconds>0&&local>=c.duration-c.transition_seconds)mist+=.6*(c.transition_intensity??1)*Math.sin(Math.PI*(local-(c.duration-c.transition_seconds))/c.transition_seconds);
   if(mist>0)blurred(6,clamp(mist));return out;
  }
  function draw(now:number){
   frame=requestAnimationFrame(draw);if(now-last<1000/24)return;last=now;const {visible,position,total,effects,seed}=live.current;const w=target!.width,h=target!.height;ctx!.clearRect(0,0,w,h);
   const a=visible[0],b=visible[1];if(!a)return;const first=sceneLayer(a,0);if(!first)return;
   if(!b){ctx!.drawImage(first,0,0)}else{
    const second=sceneLayer(b,1);const p=clamp((position-b.start)/Math.max(.04,a.transition_seconds));
    if(a.transition==='slideup'){ctx!.drawImage(first,0,-h*p);if(second)ctx!.drawImage(second,0,h*(1-p))}
    else{ctx!.drawImage(first,0,0);if(second){ctx!.save();if(a.transition==='wipeleft'){ctx!.beginPath();ctx!.rect(w*(1-p),0,w*p,h);ctx!.clip()}else ctx!.globalAlpha=p;ctx!.drawImage(second,0,0);ctx!.restore()}}
   }
   drawAtmosphere(ctx!,w,h,effects.scene,position,total,seed);
   for(const c of live.current.clips.slice(0,-1)){const d=c.transition_seconds,start=c.end-d;if(d>0&&position>=start&&position<=c.end){const p=clamp((position-start)/d),alpha=Math.sin(Math.PI*p)**2*(c.transition_intensity??1);if(c.transition==='light'){ctx!.fillStyle=`rgba(255,246,214,${46/255*alpha})`;ctx!.fillRect(0,0,w,h)}else if(c.transition==='mist')drawAtmosphere(ctx!,w,h,{enabled:true,kind:'fog',intensity:alpha,duration:0},Math.max(.7,position),Math.max(position+1,total),seed+7)}}
  }
  frame=requestAnimationFrame(draw);return()=>cancelAnimationFrame(frame)
 },[JSON.stringify(visible.map(c=>c.id))]);
 return <canvas ref={canvas} className="fx-scene-canvas" data-testid="scene-effects-canvas" aria-label="معاينة المؤثرات على الفيديو الفعلي" style={{position:'absolute',inset:0,width:'100%',height:'100%',pointerEvents:'none'}}/>;
}
