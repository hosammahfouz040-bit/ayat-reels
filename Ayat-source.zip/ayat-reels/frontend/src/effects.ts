import type {Config,Clip} from './types';
export type VerseFxKind='fade'|'glow'|'reveal'|'highlight'|'verse_switch';
export type SceneFxKind='fog'|'rain'|'sunrays'|'dust'|'stars'|'bloom';
export type CameraFxKind='zoom_in'|'zoom_out'|'pan'|'depth';
export interface Effect<K extends string>{enabled:boolean;kind:K;intensity:number;duration:number}
export interface VisualEffects{verse:Effect<VerseFxKind>;scene:Effect<SceneFxKind>;camera:Effect<CameraFxKind>}
export interface EffectChoice{id:string;name:string;hint?:string;existing?:boolean}
export interface EffectCatalog{verse:EffectChoice[];scene:EffectChoice[];camera:EffectChoice[];transitions:EffectChoice[];word_timing_notice:string}
export function defaultEffects():VisualEffects{return{verse:{enabled:false,kind:'fade',intensity:.45,duration:1.2},scene:{enabled:false,kind:'fog',intensity:.3,duration:0},camera:{enabled:false,kind:'zoom_in',intensity:.3,duration:0}}}
export function effectsOf(config:Config):VisualEffects{const d=defaultEffects();return{verse:{...d.verse,...config.effects?.verse},scene:{...d.scene,...config.effects?.scene},camera:{...d.camera,...config.effects?.camera}}}
export const clamp=(x:number,min=0,max=1)=>Math.max(min,Math.min(max,x));
export function smooth(x:number){x=clamp(x);return x*x*(3-2*x)}
export function randomFx(i:number,seed=0){const x=Math.sin(i*12.9898+seed*.013)*43758.5453;return x-Math.floor(x)}
export function effectEnabled(fx:Effect<string>){return fx.enabled&&fx.intensity>0}
export function fxEnvelope(t:number,duration:number,total:number){const d=duration>0?Math.min(duration,total):total;if(d<=0||t<0||t>d)return 0;const r=Math.min(.65,d*.25);return smooth(t/Math.max(.001,r))*smooth((d-t)/Math.max(.001,r))}
export function transitionSeconds(clip:Clip,limit:number){if(clip.transition==='cut'||clip.transition_enabled===false||(clip.transition_intensity??1)<=0)return 0;return Math.min(clip.transition_duration*(clip.transition_intensity??1),limit)}
export function cameraValues(fx:Effect<CameraFxKind>,t:number,total:number){
 if(!effectEnabled(fx))return{zoom:1,x:.5,y:.5};const i=fx.intensity;const d=fx.duration>0?Math.min(fx.duration,total):total;const p=smooth(t/Math.max(.01,d));
 if(fx.kind==='zoom_in')return{zoom:1+.08*i*p,x:.5,y:.5};if(fx.kind==='zoom_out')return{zoom:1+.08*i*(1-p),x:.5,y:.5};if(fx.kind==='pan')return{zoom:1+.065*i,x:p,y:.5};return{zoom:1+.04*i*p,x:.5+.12*i*Math.sin(p*Math.PI),y:.5};
}
export function verseVisual(fx:Effect<VerseFxKind>,local:number,total:number){
 if(!effectEnabled(fx))return{alpha:1,dy:0,progress:1,glow:0};const d=Math.max(.001,Math.min(fx.duration,total*(['reveal','highlight'].includes(fx.kind) ? .6 : .28)));const envelope=smooth(local/d)*smooth((total-local)/d);return{alpha:['fade','verse_switch'].includes(fx.kind)?1-fx.intensity*(1-envelope):1,dy:fx.kind==='verse_switch'?.015*fx.intensity*((1-smooth(local/d))-(1-smooth((total-local)/d))):0,progress:clamp(local/d),glow:fx.kind==='glow'?fx.intensity*(.7+.3*Math.sin(local*.7)**2)*fxEnvelope(local,fx.duration,total):0};
}
export function drawAtmosphere(ctx:CanvasRenderingContext2D,w:number,h:number,fx:Effect<SceneFxKind>,t:number,total:number,seed:number){
 if(!effectEnabled(fx)||fx.kind==='bloom')return;const intensity=fx.intensity*fxEnvelope(t,fx.duration,total);if(intensity<=0)return;const r=randomFx,scale=w/540;ctx.save();
 if(fx.kind==='fog'){
  for(let i=0;i<5;i++){const x=(r(i,seed)*1.4-.2+.13*Math.sin(t*.17+i))*w,y=(.12+.76*r(i+20,seed)+.04*Math.sin(t*.11+i))*h,rad=w*(.45+.3*r(i+40,seed));ctx.save();ctx.translate(x,y);ctx.scale(1,.6);const g=ctx.createRadialGradient(0,0,0,0,0,rad);g.addColorStop(0,`rgba(210,220,217,${(10+12*r(i+60,seed))/255*intensity})`);g.addColorStop(.55,`rgba(210,220,217,${(10+12*r(i+60,seed))/255*intensity*.7})`);g.addColorStop(1,'rgba(210,220,217,0)');ctx.fillStyle=g;ctx.fillRect(-rad,-rad,rad*2,rad*2);ctx.restore()}
 }else if(fx.kind==='rain'){
  ctx.lineWidth=Math.max(1,scale);for(let i=0;i<68;i++){const x=((r(i,seed)+.025*t)%1)*w,y=((r(i+100,seed)+t*(.2+.09*r(i+180,seed)))%1.12-.06)*h,len=(.025+.025*r(i+240,seed))*h;ctx.strokeStyle=`rgba(218,231,232,${(16+24*r(i+300,seed))/255*intensity})`;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-.009*w,y+len);ctx.stroke()}
 }else if(fx.kind==='sunrays'){
  ctx.filter=`blur(${Math.max(2,w*.009)}px)`;for(let i=0;i<6;i++){const x=(.12+i*.21+.035*Math.sin(t*.15+i))*w,spread=(.08+.025*r(i,seed))*w;ctx.fillStyle=`rgba(255,238,190,${(8+9*r(i+20,seed))/255*intensity})`;ctx.beginPath();ctx.moveTo(-.08*w,-.05*h);ctx.lineTo(x-spread,h);ctx.lineTo(x+spread,h);ctx.closePath();ctx.fill()}
 }else{
  for(let i=0;i<36;i++){const dust=fx.kind==='dust';const x=((r(i,seed)+(dust ? .009*t : 0))%1)*w;let yy=(r(i+80,seed)-(dust ? .018*t : 0))%1;if(yy<0)yy+=1;const y=yy*h,rad=(.8+1.9*r(i+180,seed))*scale,alpha=(30+50*r(i+220,seed))/255*intensity*(.4+.6*Math.sin(t*.45+i)**2),color=dust?'246,224,164':'231,240,255';ctx.fillStyle=`rgba(${color},${alpha*.2})`;ctx.beginPath();ctx.arc(x,y,rad*2,0,Math.PI*2);ctx.fill();ctx.fillStyle=`rgba(${color},${alpha})`;ctx.beginPath();ctx.arc(x,y,rad,0,Math.PI*2);ctx.fill()}
 }
 ctx.restore();
}
