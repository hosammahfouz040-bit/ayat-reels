import {defaultEffects,transitionSeconds} from './effects';
import type {Config,Clip,AudioPlan,Template,QuranData,Timing} from './types';
import {uuid,sceneSourceDuration} from './api';
export function newClip(scene_id:string):Clip{return{id:uuid(),scene_id,source_in:0,source_out:Math.min(6,sceneSourceDuration(scene_id)),duration:6,transition:'fade',transition_duration:.5}}
export function defaultConfig():Config{return{effects:defaultEffects(),title:'ريل قرآني جديد',surah:112,from_ayah:1,to_ayah:4,reciter:'alafasy',template_id:'noor',mood:'سكينة',quality:'hd',text_style:{font:'amiri_quran',size:80,color:'#F5E8C8',x:.5,y:.49,max_width:.82,line_height:1.8,alignment:'center',box_color:'#071F1A',box_opacity:.26,shadow:true,shadow_color:'#000000',shadow_blur:5},clips:['mihrab','garden','orbit'].map(newClip),auto_fit:true,audio_trim_start:0,audio_trim_end:null,timings:null,text_reviewed:false}}
export function applyTemplate(c:Config,t:Template):Config{return{...c,template_id:t.id,mood:t.mood,text_style:{...c.text_style,font:t.font,size:t.size,color:t.color,box_color:t.box_color,box_opacity:t.box_opacity,y:t.y,x:t.x??.5,max_width:t.max_width??.82,alignment:t.alignment??'center'},clips:t.scene_ids.map((id,i)=>({...newClip(id),transition:t.transition??'fade',transition_duration:t.transition_duration??.5,duration:t.durations?.[i]??6})),auto_fit:true}}
export function ar(value:number){return new Intl.NumberFormat('ar-EG',{maximumFractionDigits:0}).format(value)}
export function seconds(v:number){const n=Math.max(0,v||0);return `${String(Math.floor(n/60)).padStart(2,'0')}:${String(Math.floor(n%60)).padStart(2,'0')}`}
export function bytes(v:number){return new Intl.NumberFormat('ar-EG',{maximumFractionDigits:1}).format(v/1024/1024)+' م.ب'}
export function selectedVerses(c:Config,q:QuranData){const result=[];for(let a=c.from_ayah;a<=c.to_ayah;a++){const key=c.surah+':'+a;if(q.verses[key])result.push({key,number:a,text:q.verses[key]})}return result}
export function audioDuration(c:Config,p:AudioPlan|null){return p?Math.max(.25,(c.audio_trim_end??p.duration)-c.audio_trim_start):18}
export function clipTimeline(c:Config,p:AudioPlan|null){const duration=audioDuration(c,p);const clips=c.clips.map(x=>({...x,start:0,end:0,transition_seconds:0}));const ds=clips.slice(0,-1).map(x=>transitionSeconds(x,duration/(clips.length*3)));const sum=clips.reduce((s,x)=>s+x.duration,0);let pos=0;for(let i=0;i<clips.length;i++){const d=c.auto_fit?(duration+ds.reduce((a,b)=>a+b,0))*clips[i].duration/sum:clips[i].duration;clips[i].duration=d;clips[i].start=pos;clips[i].end=pos+d;clips[i].transition_seconds=ds[i]||0;pos+=d-(ds[i]||0)}return clips}
export function verseAt(c:Config,p:AudioPlan|null,q:QuranData,time:number){const verses=selectedVerses(c,q);if(!p)return{...verses[0],start:0,end:18};const source=p.verses.find(v=>{const timing=c.timings?.find(t=>t.key===v.key)||v;return time>=timing.start&&time<timing.end});const fallback=p.verses[time>=p.duration?p.verses.length-1:0];const v=source||fallback;const timing=c.timings?.find(t=>t.key===v.key)||v;return{...v,start:Math.max(timing.start,c.audio_trim_start),end:Math.min(timing.end,c.audio_trim_end??p.duration)}}
export function normalizeSearch(s:string){return s.normalize('NFD').replace(/[\u064B-\u065F\u0670]/g,'').replace(/[أإآٱ]/g,'ا')}

// Keep raw input editable; normalize Arabic-Indic/Persian digits only for validation.
export function normalizeDigits(value:string){return value.replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-0x660)).replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-0x6f0)).trim()}
export function parseAyahRange(fromRaw:string,toRaw:string,count:number){
 const a=normalizeDigits(fromRaw),b=normalizeDigits(toRaw);const from=Number(a),to=Number(b);
 let error='';
 if(!a||!b)error='اكتب رقم بداية الآيات ونهايتها.';
 else if(!/^\d+$/.test(a)||!/^\d+$/.test(b))error='استخدم أرقامًا صحيحة، مثل 1 و5 أو ١ و٥.';
 else if(from<1||to<1||from>count||to>count)error=`هذه السورة تحتوي على ${ar(count)} آية فقط. اختر رقمًا من 1 إلى ${count}.`;
 else if(from>to)error='رقم آية النهاية يجب أن يساوي رقم البداية أو يكون أكبر منه.';
 return {from,to,error};
}
