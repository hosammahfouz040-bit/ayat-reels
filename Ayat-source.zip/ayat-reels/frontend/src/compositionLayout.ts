import spec from '../../backend/data/composition-layout.json';
import type {Config,TextStyle} from './types';

// Same portrait spacing contract as the server. Browser glyph metrics are measured
// after local fonts load; the exported MP4 always uses the authoritative RAQM solver.
export const compositionSpec=spec;
export type Rect=[number,number,number,number];
export interface Run{text:string;x:number;y:number;ink:Rect}
export interface TextPart{text?:string;font:string;font_size:number;lines:Run[];ink_bbox:Rect;line_step:number}
export interface Composition{version:string;width:number;height:number;column_center_x:number;column_width:number;verse_center_y:number;group_bbox:Rect;verse_box:Rect;verse:TextPart;number:TextPart|null;surah:TextPart;reader:TextPart;source:TextPart;divider:{x1:number;x2:number;y:number;thickness:number};effect_bleed:number}
let context:CanvasRenderingContext2D|null=null;
const measurements=new Map<string,{ink:Rect;advance:number}>();
export function clearCompositionMeasurements(){measurements.clear()}
function metrics(text:string,family:string,size:number,weight=400){
 const key=family+'|'+weight+'|'+size+'|'+text;const old=measurements.get(key);if(old)return old;
 context??=document.createElement('canvas').getContext('2d');if(!context)throw Error('تعذر قياس تنسيق النص.');
 context.font=`${weight} ${size}px "${family}"`;context.direction='rtl';context.textAlign='center';context.textBaseline='alphabetic';
 const m=context.measureText(text);const box:Rect=[-m.actualBoundingBoxLeft,-m.actualBoundingBoxAscent,m.actualBoundingBoxRight,m.actualBoundingBoxDescent];const result={ink:box,advance:m.width};
 if(measurements.size>4096)measurements.clear();measurements.set(key,result);return result;
}
function measuredWidth(text:string,family:string,size:number,weight=400){const m=metrics(text,family,size,weight);return Math.max(m.advance,m.ink[2]-m.ink[0])}
function move(r:Rect,dx=0,dy=0):Rect{return[r[0]+dx,r[1]+dy,r[2]+dx,r[3]+dy]}
function union(rects:Rect[]):Rect{return rects.length?[Math.min(...rects.map(r=>r[0])),Math.min(...rects.map(r=>r[1])),Math.max(...rects.map(r=>r[2])),Math.max(...rects.map(r=>r[3]))]:[0,0,0,0]}
export function compositionColumn(style:TextStyle,width:number){const scale=width/1080,pad=spec.verse_padding_x*scale,safe=width*spec.safe_horizontal,cw=Math.min(width*style.max_width,width-2*(safe+pad));const x=Math.max(safe+pad+cw/2,Math.min(width-safe-pad-cw/2,width*style.x));return{x,width:cw}}
function wrap(text:string,family:string,size:number,width:number,weight=400){const lines:string[]=[];let line='';for(const word of text.split(' ')){const trial=line===''?word:line+' '+word;if(line&&measuredWidth(trial,family,size,weight)>width){lines.push(line);line=word}else line=trial}if(line)lines.push(line);return lines}
function lineGeometry(lines:string[],family:string,size:number,lineHeight:number,gap=0,weight=400){
 const boxes=lines.map(text=>metrics(text,family,size,weight).ink);const pairs=boxes.slice(0,-1).map((box,i)=>box[3]-boxes[i+1][1]+gap);const step=Math.max(size*lineHeight,...pairs,0);const runs=lines.map((text,i)=>({text,x:0,y:i*step,ink:move(boxes[i],0,i*step)}));return{runs,box:union(runs.map(r=>r.ink)),step};
}
function aligned(lines:string[],family:string,size:number,lineHeight:number,cx:number,cw:number,alignment:string,top:number,gap=0,weight=400){const data=lineGeometry(lines,family,size,lineHeight,gap,weight),dy=top-data.box[1];for(const run of data.runs){const box=metrics(run.text,family,size,weight).ink;run.x=alignment==='center'?cx-(box[0]+box[2])/2:cx+cw/2-box[2];run.y+=dy;run.ink=move(box,run.x,run.y)}return{runs:data.runs,box:union(data.runs.map(r=>r.ink)),step:data.step}}
function label(text:string,desired:number,cx:number,cw:number,alignment:string,top:number,regular=false):TextPart{let size=Math.max(6,Math.floor(desired));const minimum=Math.max(6,Math.floor(size*.78)),weight=regular?400:500;while(size>minimum&&measuredWidth(text,'Tajawal',size,weight)>cw)size--;const lines=wrap(text,'Tajawal',size,cw,weight);const data=aligned(lines,'Tajawal',size,spec.metadata_line_height,cx,cw,alignment,top,0,weight);return{text,font:'Tajawal',font_size:size,lines:data.runs,ink_bbox:data.box,line_step:data.step}}
function shift(part:TextPart,dy:number){part.ink_bbox=move(part.ink_bbox,0,dy);for(const run of part.lines){run.y+=dy;run.ink=move(run.ink,0,dy)}}

export function measureComposition(config:Config,family:string,lines:string[],size:number,width:number,height:number,surah:string,reader:string,source:string,number?:number):Composition{
 const style=config.text_style,scale=width/1080,column=compositionColumn(style,width),cx=column.x,cw=column.width;const v=aligned(lines,family,size,style.line_height,cx,cw,style.alignment,0,spec.verse_min_line_gap*scale);const verse:TextPart={font:family,font_size:size,lines:v.runs,ink_bbox:v.box,line_step:v.step};shift(verse,-(v.box[1]+v.box[3])/2);
 let marker:TextPart|null=null;let content=verse.ink_bbox;
 if(config.narration!=='warsh'&&number!==undefined){marker=label('﴿ '+String(number).replace(/[0-9]/g,n=>'٠١٢٣٤٥٦٧٨٩'[Number(n)])+' ﴾',Math.min(size*spec.number_ratio,spec.number_max_size*scale),cx,cw,'center',content[3]+spec.number_gap*scale);content=union([content,marker.ink_bbox])}
 const box:Rect=[cx-cw/2-spec.verse_padding_x*scale,content[1]-spec.verse_padding_y*scale,cx+cw/2+spec.verse_padding_x*scale,content[3]+spec.verse_padding_y*scale];
 const fx=config.effects?.verse;const motion=fx?.enabled&&fx.kind==='verse_switch'?height*.015*fx.intensity:0;const glow=fx?.enabled&&fx.kind==='glow'?width/540*12*fx.intensity:0;const bleed=Math.max(motion,glow,style.shadow?style.shadow_blur*scale:0);
 const title=label(surah,Math.min(size*spec.surah_ratio,spec.surah_max_size*scale),cx,cw,style.alignment,0);let dy=box[1]-bleed-spec.divider_verse_gap*scale-spec.divider_thickness*scale/2;shift(title,dy-spec.divider_thickness*scale/2-spec.surah_divider_gap*scale-(title.ink_bbox[3]-title.ink_bbox[1])-title.ink_bbox[1]);
 const readerPart=label(reader,Math.min(size*spec.reader_ratio,spec.reader_max_size*scale),cx,cw,style.alignment,box[3]+bleed+spec.verse_reader_gap*scale);const sourcePart=label(source,Math.min(size*spec.source_ratio,spec.source_max_size*scale),cx,cw,style.alignment,readerPart.ink_bbox[3]+spec.reader_source_gap*scale,true);
 const extent=union([title.ink_bbox,box,readerPart.ink_bbox,sourcePart.ink_bbox]);const cy=Math.max(height*spec.safe_top-extent[1],Math.min(height*spec.safe_bottom-extent[3],height*style.y));
 for(const part of [verse,title,readerPart,sourcePart,...(marker?[marker]:[])])shift(part,cy);
 const dw=Math.min(width*spec.divider_width,cw*.35),end=style.alignment==='right'?cx+cw/2:cx+dw/2;
 return{version:spec.version,width,height,column_center_x:cx,column_width:cw,verse_center_y:cy,group_bbox:move(extent,0,cy),verse_box:move(box,0,cy),verse,number:marker,surah:title,reader:readerPart,source:sourcePart,divider:{x1:end-dw,x2:end,y:dy+cy,thickness:Math.max(1,Math.round(spec.divider_thickness*scale))},effect_bleed:bleed};
}

export function previewTextPage(config:Config,family:string,current:{text:string;start:number;end:number;number?:number},time:number,width:number,height:number,surah:string,reader:string,source:string){
 const cw=compositionColumn(config.text_style,width).width;let size=Math.max(12,Math.floor(config.text_style.size*width/1080));while(size>12&&Math.max(...current.text.split(' ').map(word=>measuredWidth(word,family,size)))>cw+.01)size--;
 const lines=wrap(current.text,family,size,cw),chunks:string[][]=[];let chunk:string[]=[];
 for(const line of lines){const trial=[...chunk,line],box=lineGeometry(trial,family,size,config.text_style.line_height,spec.verse_min_line_gap*width/1080).box;if(chunk.length&&box[3]-box[1]>height*spec.verse_page_max_height+.01){chunks.push(chunk);chunk=[line]}else chunk=trial}if(chunk.length)chunks.push(chunk);
 if(!chunks.length)chunks.push(['']);const weights=chunks.map(c=>c.reduce((n,l)=>n+l.length,0)),sum=Math.max(1,weights.reduce((a,b)=>a+b,0));let start=current.start,index=0,end=current.end;
 for(let i=0;i<chunks.length;i++){end=i===chunks.length-1?current.end:start+(current.end-current.start)*weights[i]/sum;if(time<end||i===chunks.length-1){index=i;break}start=end}
 return{text:chunks[index].join('\n'),start,end,page:index+1,pages:chunks.length,layout:measureComposition(config,family,chunks[index],size,width,height,surah,reader,source,current.number)};
}

export function visualWords(layout:Composition){
 const words:{text:string;index:number;rect:Rect}[]=[];let index=0;
 for(const run of layout.verse.lines){const m=metrics(run.text,layout.verse.font,layout.verse.font_size),tokens=run.text.split(' '),space=metrics(' ',layout.verse.font,layout.verse.font_size).advance;const lengths=tokens.map(w=>metrics(w,layout.verse.font,layout.verse.font_size).advance);const ratio=m.advance/Math.max(.01,lengths.reduce((a,b)=>a+b,0)+Math.max(0,tokens.length-1)*space);let cursor=run.x+m.advance/2;
  for(let i=0;i<tokens.length;i++){const length=lengths[i]*ratio;if(tokens[i])words.push({text:tokens[i],index:index++,rect:[cursor-length,run.ink[1],cursor,run.ink[3]]});cursor-=length+space*ratio}
 }return words;
}
