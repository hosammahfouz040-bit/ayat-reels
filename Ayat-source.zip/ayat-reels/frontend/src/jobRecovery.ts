import type {Config,Job} from './types';
import {baseUrl,workspace} from './api';
export const ACTIVE_JOB_STATES=['queued','preparing','rendering','validating'];
const SNAPSHOT='ayat.activeJobSnapshot.v1',PENDING='ayat.pendingExport.v1';
export interface JobSnapshot {version:1;workspace:string;server:string;saved_at:number;job:Job}
export interface PendingExport {version:1;workspace:string;server:string;request_id:string;created:number;can_recover:boolean;kind:'new'|'retry';source_job_id?:string;body:{config:Config;project_id:string|null;one_click:boolean}}
export function serverScope(){return baseUrl()||window.location.origin}
function sameScope(value:{workspace?:string;server?:string}){return value.workspace===workspace&&value.server===serverScope()}
function read(key:string){try{return JSON.parse(localStorage.getItem(key)||'null')}catch{return null}}
export function jobSnapshot():JobSnapshot|null {const value=read(SNAPSHOT);return value?.version===1&&sameScope(value)&&value.job?.id&&value.job?.config?value:null}
export function pendingExport():PendingExport|null {const value=read(PENDING);return value?.version===1&&sameScope(value)&&value.request_id&&value.body?.config?value:null}
export function persistJob(job:Job){const data:JobSnapshot={version:1,workspace,server:serverScope(),saved_at:Date.now(),job};try{localStorage.setItem(SNAPSHOT,JSON.stringify(data));localStorage.setItem('ayat.activeJob',job.id)}catch{/* Keep working in memory; never clear projects to make room. */}}
export function persistPending(value:PendingExport){try{localStorage.setItem(PENDING,JSON.stringify(value));return true}catch{return false}}
export function clearPending(requestId?:string){const value=read(PENDING);if(!requestId||value?.request_id===requestId)localStorage.removeItem(PENDING)}
export function legacyActiveJobId(){const snapshot=read(SNAPSHOT);if(snapshot?.server&&!sameScope(snapshot))return null;const id=localStorage.getItem('ayat.activeJob');return id&&/^[0-9a-f-]{36}$/i.test(id)?id:null}
export function canAdoptJob(current:Job|null,next:Job){if(!current||current.id!==next.id)return true;if(!ACTIVE_JOB_STATES.includes(current.state)&&ACTIVE_JOB_STATES.includes(next.state))return false;return !(current.updated>next.updated)}

export function clearActiveJobReference(){localStorage.removeItem('ayat.activeJob');localStorage.removeItem(SNAPSHOT)}
