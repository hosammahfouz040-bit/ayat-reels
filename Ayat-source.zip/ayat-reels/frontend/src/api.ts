import { Capacitor,registerPlugin } from '@capacitor/core';
import type { Project,Scene } from './types';
export const native=Capacitor.isNativePlatform();
// Cross-origin parents cannot be inspected; comparing WindowProxy references is safe.
// Opening a new context is only effective if the parent explicitly permits popups to escape its sandbox.
export const embeddedBrowser=!native&&window.self!==window.top;
export function uuid(){return globalThis.crypto?.randomUUID?.()||'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>{const r=Math.random()*16|0;return(c==='x'?r:(r&3|8)).toString(16)})}
let ws=localStorage.getItem('ayat.workspace');if(!ws){ws=uuid();localStorage.setItem('ayat.workspace',ws)}
export const workspace=ws;
export function baseUrl(){return (localStorage.getItem('ayat.server')||import.meta.env.VITE_API_BASE_URL||'').replace(/\/$/,'')}
export function mediaUrl(path:string,privateFile=false){let u=baseUrl()+path;if(privateFile)u+=(u.includes('?')?'&':'?')+'workspace='+workspace;return u}
const remoteScenes=new Set<string>();
const sceneDurations=new Map<string,number>();
export function sceneSourceDuration(id:string){return sceneDurations.get(id)??6}
export function registerSceneCatalog(scenes:Scene[]){remoteScenes.clear();sceneDurations.clear();for(const scene of scenes){sceneDurations.set(scene.id,scene.duration);if(scene.availability==='on-demand')remoteScenes.add(scene.id)}}
export function remoteScene(id:string){return remoteScenes.has(id)||id.startsWith('v17_')}
export function sceneVideo(id:string){return remoteScene(id)?mediaUrl('/api/media/'+id+'.mp4'):'/scenes/'+id+'.mp4'}
export function scenePoster(id:string){return '/scenes/'+id+'.jpg'}
export class ApiError extends Error {code:string;status:number;constructor(message:string,code='NETWORK',status=0){super(message);this.code=code;this.status=status}}
export interface ApiOptions {signal?:AbortSignal;timeoutMs?:number;requestId?:string}
export async function api<T>(path:string,method='GET',body?:unknown,options:ApiOptions={}):Promise<T>{
 if(native&&!baseUrl())throw new ApiError('أضف رابط خادم آيات الآمن من الإعدادات لتشغيل التلاوة والتصدير.','SERVER_CONFIG');
 const controller=new AbortController();let timedOut=false;const timer=setTimeout(()=>{timedOut=true;controller.abort()},options.timeoutMs??(method==='GET'?20000:180000));
 const cancel=()=>controller.abort();options.signal?.addEventListener('abort',cancel,{once:true});if(options.signal?.aborted)controller.abort();
 function connectionError(){if(options.signal?.aborted)throw new DOMException('Canceled request','AbortError');return new ApiError(timedOut?'انتهت مهلة الاتصال بالخادم. المشروع محفوظ محليًا؛ لم تتأكد حالة التصدير.':'تعذر الاتصال بمحرك آيات. تحقق من توفر الخادم والاتصال.',timedOut?'TIMEOUT':'NETWORK')}
 try{
  let response:Response;
  try{response=await fetch(mediaUrl('/api'+path),{method,cache:'no-store',signal:controller.signal,headers:{'Content-Type':'application/json','X-Workspace-Id':workspace,'X-Ayat-Capabilities':'reciters-v13,warsh,publication-v1,visual-fx-v1,scene-library-v17,publisher-timing-v1',...(options.requestId?{'X-Ayat-Request-Id':options.requestId}:{})},...(body!==undefined?{body:JSON.stringify(body)}:{})})}catch{throw connectionError()}
  let raw:string;try{raw=await response.text()}catch{throw connectionError()}
  let data;try{data=JSON.parse(raw)}catch{throw new ApiError('الاستجابة ليست من واجهة خادم آيات المتوقعة. راجع عنوان الخادم.','INVALID_RESPONSE',response.status)}
  if(!response.ok)throw new ApiError(data?.error||data?.detail||'لم تكتمل العملية. أعد المحاولة.',data?.code||'REQUEST',response.status);
  return data as T;
 }finally{clearTimeout(timer);options.signal?.removeEventListener('abort',cancel)}
}

const dbPromise=new Promise<IDBDatabase>((resolve,reject)=>{const r=indexedDB.open('ayat-local-projects',1);r.onupgradeneeded=()=>r.result.createObjectStore('projects',{keyPath:'id'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});
export async function localProjects(){const db=await dbPromise;return new Promise<Project[]>((resolve,reject)=>{const r=db.transaction('projects').objectStore('projects').getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
export async function cacheProject(p:Project){const db=await dbPromise;return new Promise<void>((resolve,reject)=>{const tx=db.transaction('projects','readwrite');tx.objectStore('projects').put(p);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error)})}
export async function removeLocalProject(id:string){const db=await dbPromise;return new Promise<void>((resolve,reject)=>{const tx=db.transaction('projects','readwrite');tx.objectStore('projects').delete(id);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error)})}
interface VideoFilesPlugin {copyText(o:{text:string}):Promise<{copied:boolean}>;saveVideo(o:{url:string;name:string}):Promise<{uri:string;name:string;bytes:number}>;shareVideo(o:{uri:string;title:string}):Promise<void>}
const VideoFiles=registerPlugin<VideoFilesPlugin>('VideoFiles');
export async function downloadVideo(url:string,name:string){
 if(native){const result=await VideoFiles.saveVideo({url:mediaUrl(url,true),name});return result.uri}
 // Browser-owned streaming download: no whole-file Blob, delayed synthetic click or URL revocation.
 const a=document.createElement('a');a.href=mediaUrl(embeddedBrowser?url.replace(/\/file$/,'/open?start=1'):url,true);if(embeddedBrowser){a.target='_blank';a.rel='noopener noreferrer'}else a.download=name;document.body.appendChild(a);a.click();a.remove();return '';
}
export async function shareVideo(url:string,name:string,uri?:string){
 if(native){const saved=uri||await downloadVideo(url,name);await VideoFiles.shareVideo({uri:saved,title:'آيات — ريلز قرآني'});return}
 if(!navigator.share||!navigator.canShare)throw new Error('مشاركة الملفات غير مدعومة في هذا المتصفح. نزّل MP4 ثم شاركه من تطبيق الملفات.');
 const response=await fetch(mediaUrl(url,true));if(!response.ok)throw new Error('تعذر تحميل الفيديو للمشاركة.');
 const file=new File([await response.blob()],name,{type:'video/mp4'});
 if(!navigator.canShare({files:[file]}))throw new Error('هذا المتصفح لا يدعم مشاركة ملفات MP4. استخدم التنزيل.');
 await navigator.share({files:[file],title:'آيات — ريلز قرآني'});
}


export interface ClipboardResult {ok:boolean;method?:'native'|'clipboard'|'legacy';message?:string}
function legacyCopyText(text:string){
 const previous=document.activeElement as HTMLElement|null;const selected=window.getSelection();const ranges:Range[]=[];
 if(selected)for(let i=0;i<selected.rangeCount;i++)ranges.push(selected.getRangeAt(i).cloneRange());
 const area=document.createElement('textarea');area.value=text;area.readOnly=true;area.setAttribute('aria-hidden','true');Object.assign(area.style,{position:'fixed',left:'-10000px',top:'0',opacity:'0'});document.body.appendChild(area);
 try{area.focus({preventScroll:true});area.select();area.setSelectionRange(0,text.length);return typeof document.execCommand==='function'&&document.execCommand('copy')===true}catch{return false}
 finally{area.remove();if(selected){selected.removeAllRanges();for(const range of ranges)try{selected.addRange(range)}catch{}}try{previous?.focus({preventScroll:true})}catch{}}
}
export async function copyPublicationText(text:string):Promise<ClipboardResult>{
 if(!text.trim())return {ok:false,message:'الحقل فارغ؛ اكتب نصًا أو أنشئ اقتراحًا أولًا.'};
 if(native){try{const result=await VideoFiles.copyText({text});if(result.copied===true)return {ok:true,method:'native'}}catch{/* Older APKs may not have the native text bridge; try legitimate web copying. */}}
 // Keep the synchronous user gesture when embedded policy prevents Clipboard API.
 if(embeddedBrowser&&legacyCopyText(text))return {ok:true,method:'legacy'};
 try{if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(text);return {ok:true,method:'clipboard'}}}catch{/* Permission or parent policy may deny it; never claim success. */}
 if(!embeddedBrowser&&legacyCopyText(text))return {ok:true,method:'legacy'};
 return {ok:false,message:'لم يسمح المتصفح بالنسخ التلقائي. النص ظاهر ومحدد للنسخ اليدوي؛ اضغط مطولًا واختر «نسخ».'};
}


export interface SceneAssetStatus {scene_id:string;state:'ready'|'not_downloaded'|'queued'|'downloading'|'preparing'|'failed';progress:number;message:string;bundled:boolean;video_url?:string}
const sceneDownloads=new Map<string,Promise<SceneAssetStatus>>();
export async function prepareSceneAsset(id:string,onStatus?:(status:SceneAssetStatus)=>void):Promise<SceneAssetStatus>{
 if(!remoteScene(id))return {scene_id:id,state:'ready',progress:100,message:'مشهد محلي',bundled:true};
 let task=sceneDownloads.get(id);
 if(!task){task=(async()=>{let state=await api<SceneAssetStatus>('/scenes/'+id+'/prepare','POST');const started=Date.now();while(state.state!=='ready'){onStatus?.(state);if(state.state==='failed')throw new Error(state.message);if(Date.now()-started>20*60*1000)throw new Error('استغرق تنزيل المصدر وقتًا طويلًا. يمكنك العودة لاحقًا؛ المشروع محفوظ.');await new Promise(resolve=>setTimeout(resolve,900));state=await api<SceneAssetStatus>('/scenes/'+id+'/availability')}return state})();sceneDownloads.set(id,task);void task.finally(()=>sceneDownloads.delete(id)).catch(()=>{})}
 const state=await task;onStatus?.(state);return state;
}
