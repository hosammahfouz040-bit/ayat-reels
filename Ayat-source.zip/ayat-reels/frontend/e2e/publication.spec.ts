import {test,expect,type Page,type BrowserContext} from '@playwright/test';
import {readFileSync} from 'node:fs';
import {writeFile,mkdir,readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {homedir} from 'node:os';
import {generatePublication,publicationContext,fullPublication,publicationPlatforms,verseRangeText} from '../src/publication';
import type {Catalog,Job} from '../src/types';
const catalog=JSON.parse(readFileSync('../frontend/public/catalog.json','utf8')) as Catalog;
const retained=JSON.parse(readFileSync(process.env.AYAT_PUBLICATION_FIXTURE||'../tests/requested-readers-flow.json','utf8')).proofs;
const proof=retained.find((p:any)=>p.reciter==='mossad');
const audit=JSON.parse(readFileSync('../'+proof.canonical_file.replace(/result\.mp4$/,'audit.json'),'utf8'));
const actualJob={id:proof.job,workspace:proof.workspace,project_id:proof.project,config:audit.config,state:'completed',progress:100,stage:'completed',error:null,error_code:null,created:0,updated:0,result:audit.result} as Job;
let realProof:any=null;
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
test.afterAll(async()=>{if(realProof)await writeFile('../tests/publication-real-export-v17.json',JSON.stringify(realProof,null,2))});

// Pure metadata fixtures below do not claim to be separately exported videos.
test('اقتراحات عربية متنوعة مرتبطة بالسورة والقارئ، بلا وعود مشاهدة أو صوت/آيات مولّدة',()=>{
 const titles=new Set<string>();for(let i=0;i<16;i++){const p=generatePublication(actualJob,catalog,i);titles.add(p.title);expect(p.description).toContain('سورة الإخلاص');expect(p.description).toContain('عبدالرحمن مسعد');expect(p.hashtags).toContain('#سورة_الاخلاص');expect(p.hashtags.split(/\s+/).length).toBe(new Set(p.hashtags.split(/\s+/)).size);expect(p.title.length).toBeLessThanOrEqual(100);expect(fullPublication(p)).not.toMatch(/زيادة مضمونة|ملايين المشاهدات|علاج مضمون|ترند مضمون/)}expect(titles.size).toBe(16);
});
test('بيانات المنشور تتبع آيات الفيديو بعد القص لا مدى المشروع الأوسع',()=>{
 const j=structuredClone(actualJob);j.config.from_ayah=1;j.config.to_ayah=4;j.config.audio_trim_start=1;j.result!.timeline!.cues=[{key:'112:2',number:2,start:0,end:2},{key:'112:3',number:3,start:2,end:4}];const c=publicationContext(j,catalog);expect(c.numbers).toEqual([2,3]);expect(c.rangeText).toBe('٢–٣');expect(c.reference).toContain('مقتطف من');expect(c.reference).not.toContain('١–٤');expect(verseRangeText([3,5,6])).toBe('٣، ٥–٦');
});
test('الخلفية المصممة لا تُنسب للحرم أو لتصوير الطبيعة، والمشهد خارج الفيديو لا يُذكر',()=>{
 const j=structuredClone(actualJob);j.config.clips[0].scene_id='haram_night';j.result!.timeline!.clips=[{scene_id:'mihrab',start:0,end:2},{scene_id:'haram_night',start:20,end:30}];j.result!.duration=4;const c=publicationContext(j,catalog);expect(c.sceneText).toContain('موشن');expect(c.sceneText).not.toContain('الحرم');expect(c.sceneTags).not.toContain('#الحرم_المكي');
});
test('المشاهد المصوّرة الحقيقية تضاف بوصفها الصحيح إلى الوصف والوسوم',()=>{
 const j=structuredClone(actualJob);j.result!.duration=8;j.result!.timeline!.clips=[{scene_id:'haram_night',start:0,end:4},{scene_id:'open_sea',start:3,end:8}];const c=publicationContext(j,catalog);expect(c.sceneText).toContain('الحرم المكي');expect(c.sceneText).toContain('الطبيعة');expect(c.sceneTags).toContain('#الحرم_المكي');expect(c.sceneTags).toContain('#الطبيعة');
});
test('كل المنصات لها اقتراح ووسوم عربية مناسبة ونص كامل بالترتيب',()=>{
 for(const platform of publicationPlatforms){const p=generatePublication(actualJob,catalog,2,platform.id);expect(p.platform).toBe(platform.id);expect(p.hashtags).toContain('#القرآن_الكريم');expect(fullPublication(p)).toBe(p.title+'\n\n'+p.description+'\n\n'+p.hashtags)}
});
test('لا يتولد منشور لتصدير غير مكتمل أو لا يحتوي نتيجة',()=>{
 expect(()=>generatePublication({...actualJob,state:'rendering',result:null},catalog)).toThrow('اكتمال');
});

async function openRetained(page:Page){
 await page.addInitScript(({ws,id})=>{localStorage.setItem('ayat.workspace',ws);localStorage.setItem('ayat.activeJob',id)},{ws:proof.workspace,id:proof.job});
 await page.goto('/');await page.locator('.job-banner').click();await expect(page.getByTestId('publication-panel')).toBeVisible();
}
async function grantClipboard(context:BrowserContext){await context.grantPermissions(['clipboard-read','clipboard-write'])}
async function copied(page:Page,button:string,expected:string){await page.getByTestId(button).click();expect(await page.evaluate(()=>navigator.clipboard.readText())).toBe(expected)}
const pubPath='/api/jobs/'+proof.job+'/publication';const headers={'X-Workspace-Id':proof.workspace};

test('واجهة المنشور للمقاطع القديمة: نسخ العنوان والوصف والوسوم والنص الكامل فعليًا',async({page,context})=>{
 await grantClipboard(context);await openRetained(page);await expect(page.getByTestId('publication-context')).toContainText('سورة الإخلاص');
 const values={title:'آيات تُطمئن قلبك وتُريح روحك 🤍 | تلاوة خاشعة',description:'وسط ضجيج الحياة، امنح قلبك لحظات من السكينة.\n\nاللهم اجعل القرآن ربيع قلوبنا ونور صدورنا.',hashtags:'#القرآن_الكريم #تلاوة_خاشعة #ريلز_قرآني'};
 await page.getByTestId('post-title').fill(values.title);await page.getByTestId('post-description').fill(values.description);await page.getByTestId('post-hashtags').fill(values.hashtags);
 await copied(page,'copy-post-title',values.title);await copied(page,'copy-post-description',values.description);await copied(page,'copy-post-hashtags',values.hashtags);await copied(page,'copy-post-all',values.title+'\n\n'+values.description+'\n\n'+values.hashtags);
 await expect(page.getByTestId('post-save-status')).toContainText('محفوظ مع هذا المقطع');const saved=await(await page.request.get(pubPath,{headers})).json();expect(saved.publication.title).toBe(values.title);expect(saved.publication.edited).toBeTruthy();
});

test('التعديل محفوظ بعد إعادة الفتح، واقتراح آخر قابل للتراجع، والمنصة لا تمسح التعديلات',async({page})=>{
 await openRetained(page);const title='عنوان يدوي محفوظ '+Date.now();await page.getByTestId('post-title').fill(title);await expect(page.getByTestId('post-save-status')).toContainText('محفوظ مع هذا المقطع');
 await page.reload();await page.locator('.job-banner').click();await expect(page.getByTestId('post-title')).toHaveValue(title);
 await page.getByTestId('post-platform-youtube_shorts').click();await expect(page.getByTestId('post-title')).toHaveValue(title);await page.getByTestId('post-suggest').click();await expect(page.getByTestId('post-title')).not.toHaveValue(title);await expect(page.getByTestId('post-hashtags')).toHaveValue(/#يوتيوب_شورتس/);await page.getByTestId('post-undo').click();await expect(page.getByTestId('post-title')).toHaveValue(title);
 await expect(page.getByTestId('post-save-status')).toContainText('محفوظ مع هذا المقطع');
});

test('رفض الحافظة يظهر نسخًا يدويًا محددًا دون رسالة نجاح وهمية',async({page})=>{
 await page.addInitScript(()=>{Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async()=>{throw new DOMException('Denied','NotAllowedError')}}});document.execCommand=()=>false});
 await openRetained(page);const title=await page.getByTestId('post-title').inputValue();await page.getByTestId('copy-post-title').click();await expect(page.getByTestId('post-manual-copy')).toBeVisible();const area=page.getByLabel('النص المحدد للنسخ اليدوي');await expect(area).toHaveValue(title);expect(await area.evaluate((e:HTMLTextAreaElement)=>e.selectionStart===0&&e.selectionEnd===e.value.length)).toBeTruthy();await expect(page.getByTestId('copy-post-title')).not.toContainText('نُسخ');
});

test('الاقتراح والتعديل متاحان محليًا عند انقطاع مزامنة المنشور',async({page})=>{
 await page.route('**/api/jobs/*/publication',r=>r.abort());await openRetained(page);const manual='نص محلي دون اتصال '+Date.now();await page.getByTestId('post-title').fill(manual);await page.getByTestId('post-suggest').click();await expect(page.getByTestId('post-title')).not.toHaveValue(manual);await page.getByTestId('post-undo').click();await expect(page.getByTestId('post-title')).toHaveValue(manual);
 await page.reload();await page.locator('.job-banner').click();await expect(page.getByTestId('post-title')).toHaveValue(manual);await expect(page.getByTestId('post-retry-sync')).toBeVisible();
});

test('تعارض نسختين لا يستبدل التعديل المحلي خفية، ويمكن حسمه صراحة',async({page})=>{
 await openRetained(page);await expect(page.getByTestId('post-save-status')).toContainText('محفوظ مع هذا المقطع');const prior=await(await page.request.get(pubPath,{headers})).json();const remote={...prior.publication,title:'نسخة أخرى على الخادم'};delete remote.job_id;delete remote.workspace;delete remote.updated;
 const response=await page.request.put(pubPath,{headers,data:remote});expect(response.status()).toBe(200);const local='تعديل محلي أختار الاحتفاظ به';await page.getByTestId('post-title').fill(local);await expect(page.getByTestId('post-conflict')).toBeVisible();await expect(page.getByTestId('post-title')).toHaveValue(local);await page.getByTestId('post-keep-local').click();await expect(page.getByTestId('post-save-status')).toContainText('محفوظ مع هذا المقطع');expect((await(await page.request.get(pubPath,{headers})).json()).publication.title).toBe(local);
});

test('الاستجابة المتأخرة عند فتح المنشور لا تمسح ما بدأ المستخدم بكتابته',async({page})=>{
 let release!:()=>void;const held=new Promise<void>(r=>release=r);let first=true;
 await page.route('**/api/jobs/*/publication',async route=>{if(first&&route.request().method()==='GET'){first=false;await held;await route.continue()}else await route.continue()});
 await openRetained(page);const value='بدأت كتابة هذا قبل وصول النسخة المحفوظة';await page.getByTestId('post-title').fill(value);release();await expect(page.getByTestId('post-title')).toHaveValue(value);await expect(page.getByTestId('post-conflict')).toBeVisible();await page.getByTestId('post-keep-local').click();await expect(page.getByTestId('post-save-status')).toContainText('محفوظ مع هذا المقطع');
});

test('بعد MP4 جديد فعلي تظهر الميزة تلقائيًا وتعكس الآية والقارئ والمشهد المُصدّر',async({page,context})=>{
 await grantClipboard(context);await page.goto('/#create');await page.getByLabel('القارئ',{exact:true}).selectOption('mossad');await page.getByLabel('من الآية',{exact:true}).fill('2');await page.getByLabel('إلى الآية',{exact:true}).fill('2');
 await page.locator('.editor-tabs').getByRole('button',{name:'المشاهد',exact:true}).click();for(let i=0;i<2;i++)await page.getByRole('button',{name:'حذف',exact:true}).first().click();
 await page.locator('.editor-tabs').getByRole('button',{name:'التصدير',exact:true}).click();await page.getByRole('button',{name:/اقتصادية/}).click();await page.getByLabel('اسم المشروع',{exact:true}).fill('QA v17 publication');
 const pending=page.waitForResponse(r=>r.url().endsWith('/api/jobs')&&r.request().method()==='POST');await page.getByTestId('export-editor').click();const job=await(await pending).json();await expect(page.getByTestId('download-mp4')).toBeVisible({timeout:150000});await expect(page.getByTestId('publication-panel')).toBeVisible();await expect(page.getByTestId('publication-context')).toContainText('الآية ٢');await expect(page.getByTestId('post-description')).toHaveValue(/عبدالرحمن مسعد/);await expect(page.getByTestId('post-description')).toHaveValue(/موشن/);
 const event=page.waitForEvent('download');await page.getByTestId('download-mp4').click();const dl=await event;const folder=homedir()+'/.cache/ayat-publication-tests';await mkdir(folder,{recursive:true});const saved=folder+'/publication-real-export.mp4';await dl.saveAs(saved);expect(await dl.failure()).toBeNull();const bytes=await readFile(saved);const ws=await page.evaluate(()=>localStorage.getItem('ayat.workspace'));const audit=await(await page.request.get('/api/jobs/'+job.id+'/audit?workspace='+ws)).json();expect(audit.all_cues_match_source).toBeTruthy();expect(audit.cues).toHaveLength(1);
 const title=await page.getByTestId('post-title').inputValue();const description=await page.getByTestId('post-description').inputValue();const hashtags=await page.getByTestId('post-hashtags').inputValue();await copied(page,'copy-post-all',fullPublication({title,description,hashtags}));await expect(page.getByTestId('post-save-status')).toContainText('محفوظ مع هذا المقطع');
 realProof={version:'1.7.0',job:job.id,project:job.project_id,workspace:ws,canonical_file:'backend/runtime/exports/'+job.id+'/result.mp4',downloaded_file:saved,bytes:bytes.length,sha256:sha(bytes),quran_text_verified:true,publication_automatically_shown:true,real_clipboard_bytes_verified:true,source_sha256:audit.quran_source.sha256,audio_peak:audit.result.audio_peak,duration:audit.result.duration,publication:{title,description,hashtags},temporary_assistant_qa_only:true,physical_android_tested:false};
});
