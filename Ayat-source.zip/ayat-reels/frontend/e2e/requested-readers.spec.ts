import {test,expect,type Page} from '@playwright/test';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {homedir} from 'node:os';
const proofs:any[]=[];const qaProjects:any[]=[];
const digest=(b:Buffer)=>createHash('sha256').update(b).digest('hex');

test.afterAll(async()=>{if(proofs.length||qaProjects.length)await writeFile('../tests/requested-readers-regression-v17.json',JSON.stringify({version:'1.7.0',physical_android_tested:false,real_arena_download_issue_resolved:false,proofs,qa_only_projects:qaProjects},null,2))});

test('54 قارئًا: البحث بالاسمين وتحديد الرواية دون حذف القراء السابقين',async({page,context})=>{
 const catalog=await(await context.request.get('/api/catalog')).json();expect(catalog.reciters).toHaveLength(54);
 expect(catalog.reciters.filter((r:any)=>r.provider==='curated-surah').map((r:any)=>r.id)).toEqual(['mossad','suhaim']);
 await page.goto('/#create');const select=page.getByLabel('القارئ',{exact:true});await expect(select.locator('option')).toHaveCount(54);
 await page.getByLabel('بحث عن قارئ',{exact:true}).fill('عبد الرحمن مسعد');await page.getByRole('button',{name:'اختيار القارئ عبدالرحمن مسعد',exact:true}).click();await expect(select).toHaveValue('mossad');
 await expect(page.getByTestId('selected-narration')).toContainText('حفص');await expect(page.getByTestId('available-recitations').locator('button')).toHaveCount(catalog.reciters.find((r:any)=>r.id==='mossad').available_ranges.length);
 await page.getByLabel('بحث عن قارئ',{exact:true}).fill('عبد العزيز سحيم');await page.getByRole('button',{name:'اختيار القارئ عبدالعزيز سحيم',exact:true}).click();
 await expect(select).toHaveValue('suhaim');await expect(page.getByTestId('selected-narration')).toContainText('ورش');await expect(page.getByTestId('available-recitations').locator('button')).toHaveCount(catalog.reciters.find((r:any)=>r.id==='suhaim').available_ranges.length);
 await select.selectOption('alafasy');await expect(page.getByTestId('selected-narration')).toContainText('حفص');await expect(page.getByTestId('available-recitations')).toHaveCount(0);
});

test('رسم ورش وعدّ آياته مستقلان ويُحافظ الرجوع إلى حفص على النص الأصلي',async({page,context})=>{
 const warsh=await(await context.request.get('/quran-warsh.json')).json();const hafs=await(await context.request.get('/quran.json')).json();
 await page.goto('/#create');await page.getByLabel('القارئ',{exact:true}).selectOption('suhaim');await page.getByLabel('السورة',{exact:true}).selectOption('1');
 await page.getByLabel('من الآية',{exact:true}).fill('3');await page.getByLabel('إلى الآية',{exact:true}).fill('4');
 await page.locator('.source-review summary').click();const verse=page.locator('.source-review [data-verse-key="1:3"]');
 expect((await verse.textContent())!.startsWith(warsh.verses['1:3'])).toBeTruthy();expect(warsh.verses['1:3']).not.toBe(hafs.verses['1:3']);
 await page.evaluate(()=>document.fonts.load('40px KFGQPCWarsh'));expect(await verse.evaluate(e=>getComputedStyle(e).fontFamily)).toContain('KFGQPCWarsh');
 await page.locator('.editor-tabs').getByRole('button',{name:'النص',exact:true}).click();await expect(page.getByLabel('خط الآيات',{exact:true})).toBeDisabled();
 await page.locator('.editor-tabs').getByRole('button',{name:'التلاوة',exact:true}).click();await page.getByLabel('القارئ',{exact:true}).selectOption('alafasy');
 await page.locator('.source-review summary').click();expect((await page.locator('.source-review [data-verse-key="1:3"]').textContent())!.startsWith(hafs.verses['1:3'])).toBeTruthy();
});

test('المدى غير المتاح يمنع التجهيز والتصدير ولا يمنع حفظ مسودة قابلة للتعديل',async({page,context})=>{
 await page.goto('/#create');await page.getByLabel('القارئ',{exact:true}).selectOption('mossad');await page.getByLabel('السورة',{exact:true}).selectOption('2');
 await expect(page.getByTestId('export-editor')).toBeDisabled();await expect(page.getByTestId('prepare-audio')).toBeDisabled();
 await expect(page.getByTestId('available-recitations')).toContainText('ليست المصحف كاملًا');
 await page.locator('.editor-tabs').getByRole('button',{name:'التصدير',exact:true}).click();await page.getByLabel('اسم المشروع',{exact:true}).fill('QA v17 unavailable recitation draft');await page.locator('.editor-tabs').getByRole('button',{name:'التلاوة',exact:true}).click();
 const save=page.waitForResponse(r=>r.request().method()==='POST'&&r.url().endsWith('/api/projects'));await page.getByTestId('save-project').click();const saved=await save;expect(saved.status()).toBe(200);const project=await saved.json();qaProjects.push({id:project.id,workspace:await page.evaluate(()=>localStorage.getItem('ayat.workspace'))});
 await page.getByTestId('available-recitations').getByRole('button',{name:/سورة الإخلاص/}).click();await expect(page.getByTestId('export-editor')).toBeEnabled();
 const invalid=await context.request.post('/api/audio/prepare',{data:{surah:2,from_ayah:1,to_ayah:4,reciter:'mossad'}});expect(invalid.status()).toBe(422);
});

async function actualExport(page:Page,reciter:string,surah:number,from:number,to:number){
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('/#create');await page.getByLabel('القارئ',{exact:true}).selectOption(reciter);await page.getByLabel('السورة',{exact:true}).selectOption(String(surah));await page.getByLabel('من الآية',{exact:true}).fill(String(from));await page.getByLabel('إلى الآية',{exact:true}).fill(String(to));
 const audio=page.waitForResponse(r=>r.url().endsWith('/api/audio/prepare')&&r.request().method()==='POST');await page.getByTestId('prepare-audio').click();const plan=await(await audio).json();expect(plan.reciter).toBe(reciter);expect(plan.verses.every((v:any)=>v.derived_excerpt&&v.source_recording_sha256)).toBeTruthy();
 await page.getByRole('button',{name:'تشغيل التلاوة',exact:true}).click();await page.waitForFunction(()=>{const a=document.querySelector('audio');return !!a&&!a.paused&&a.currentTime>.5&&a.readyState>=3});await page.getByRole('button',{name:'إيقاف التلاوة',exact:true}).click();
 await page.locator('.editor-tabs').getByRole('button',{name:'النص',exact:true}).click();await page.getByRole('button',{name:'لون #E8EFDE',exact:true}).click();
 await page.locator('.editor-tabs').getByRole('button',{name:'التصدير',exact:true}).click();await page.getByRole('button',{name:/اقتصادية/}).click();
 const pending=page.waitForResponse(r=>r.url().endsWith('/api/jobs')&&r.request().method()==='POST');await page.getByTestId('export-editor').click();const response=await pending;expect(response.status()).toBe(200);const started=await response.json();
 const link=page.getByTestId('download-mp4');await expect(link).toBeVisible({timeout:150000});const dlEvent=page.waitForEvent('download');await link.click();const download=await dlEvent;const cache=homedir()+'/.cache/ayat-requested-readers';await mkdir(cache,{recursive:true});const local=cache+'/proof-'+reciter+'.mp4';await download.saveAs(local);expect(await download.failure()).toBeNull();
 const workspace=await page.evaluate(()=>localStorage.getItem('ayat.workspace'));const job=await(await page.request.get('/api/jobs/'+started.id+'?workspace='+workspace)).json();const audit=await(await page.request.get('/api/jobs/'+started.id+'/audit?workspace='+workspace)).json();
 const source=await(await page.request.get(reciter==='suhaim'?'/quran-warsh.json':'/quran.json')).json();
 expect(audit.all_cues_match_source).toBeTruthy();expect(audit.quran_source.sha256).toBe(source.sha256);expect(audit.cues).toHaveLength(to-from+1);expect(audit.cues.every((c:any)=>c.text===source.verses[c.key])).toBeTruthy();expect(audit.config.text_style.color).toBe('#E8EFDE');expect(audit.result.text_visible_ratio).toBeGreaterThan(.52);expect(audit.result.audio_peak).toBeGreaterThan(.001);
 expect(audit.config.narration).toBe(reciter==='suhaim'?'warsh':'hafs');expect(plan.narration).toBe(audit.config.narration);expect(audit.audio_files.every((v:any)=>v.source_provider===(reciter==='suhaim'?'MP3Quran':'Way2Quran'))).toBeTruthy();
 const data=await readFile(local);const file=await page.request.get((await link.getAttribute('href'))!);expect(digest(await file.body())).toBe(digest(data));expect(file.headers()['content-disposition']).toContain('attachment');expect(errors).toEqual([]);
 proofs.push({reciter,narration:audit.config.narration,job:started.id,project:started.project_id,workspace,canonical_file:'backend/runtime/exports/'+started.id+'/result.mp4',range:surah+':'+from+'-'+to,bytes:data.length,sha256:digest(data),source_sha256:source.sha256,text_exact:true,text_visible_ratio:audit.result.text_visible_ratio,audio_peak:audit.result.audio_peak,width:job.result.width,height:job.result.height,duration:job.result.duration,browser_download_saved:true,physical_android_tested:false});
}

test('عبدالرحمن مسعد: تشغيل تسجيل حقيقي وتصدير الإخلاص بنص حفص وتنسيق ظاهر',async({page})=>{await actualExport(page,'mossad',112,1,4)});
test('عبدالعزيز سحيم: الفاتحة 3–4 بصوت حقيقي ونص ورش الرسمي داخل MP4',async({page})=>{await actualExport(page,'suhaim',1,3,4)});

test('نصا حفص وورش والقائمتان والخط الرسمي متاحون دون اتصال API',async({page})=>{
 await page.route('**/api/**',route=>route.abort());await page.goto('/#create');await page.getByLabel('القارئ',{exact:true}).selectOption('suhaim');await expect(page.getByTestId('selected-narration')).toContainText('ورش');
 await page.locator('.bottom-nav').getByRole('button',{name:'القرآن',exact:true}).click();await expect(page.locator('.quran-page h1')).toBeVisible();await expect(page.locator('.reader-verses .reader-verse')).toHaveCount(4);await page.evaluate(()=>document.fonts.load('40px KFGQPCWarsh'));expect(await page.locator('.reader-verses .quran-readable').first().evaluate(e=>getComputedStyle(e).fontFamily)).toContain('KFGQPCWarsh');
});
