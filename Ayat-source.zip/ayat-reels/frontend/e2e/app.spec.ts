import {test,expect} from '@playwright/test';
import {writeFile,mkdir,readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const OUT='../deliverables',REPORT='../tests';
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
test.afterEach(async({page},info)=>{
 const ws=await page.evaluate(()=>localStorage.getItem('ayat.workspace')).catch(()=>null);if(!ws)return;let before:any[]=[];try{before=JSON.parse(await readFile('../tests/regression-ui-v17-workspaces.json','utf8'))}catch{}before.push({workspace:ws,test:info.title,status:info.status,temporary_assistant_qa_only:true});await writeFile('../tests/regression-ui-v17-workspaces.json',JSON.stringify(before,null,2));
});


test('الهاتف: تلاوة مسموعة، تحرير، حفظ واستعادة، وتصديران MP4 فعليان',async({page,context})=>{
 await mkdir(OUT,{recursive:true});await mkdir(REPORT,{recursive:true});
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('/');await page.locator('.home-hero').waitFor();await page.evaluate(()=>document.fonts.ready);
 await expect(page.locator('html')).toHaveAttribute('dir','rtl');
 expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
 const t1=await page.locator('video').first().evaluate(v=>(v as HTMLVideoElement).currentTime);
 await expect.poll(()=>page.locator('video').first().evaluate(v=>(v as HTMLVideoElement).currentTime)).toBeGreaterThan(t1+.2);
 await page.getByRole('button',{name:'أنشئ ريلز جديدًا'}).click();
 await page.getByLabel('إلى الآية',{exact:true}).fill('3');
 const audioResponse=page.waitForResponse(r=>r.url().endsWith('/api/audio/prepare')&&r.request().method()==='POST');
 await page.getByTestId('prepare-audio').click();const audio=await (await audioResponse).json();expect(audio.duration).toBeGreaterThan(5);
 await expect(page.getByRole('button',{name:'تشغيل التلاوة',exact:true})).toBeVisible();
 await page.getByRole('button',{name:'تشغيل التلاوة',exact:true}).click();
 await page.waitForFunction(()=>{const a=document.querySelector('audio');return a&&!a.paused&&a.currentTime>1.1&&a.readyState>=3});
 const sound=await page.evaluate(async()=>{const a=document.querySelector('audio')!;const C=window.AudioContext;const ctx=new C();const source=ctx.createMediaElementSource(a);const analyser=ctx.createAnalyser();analyser.fftSize=512;source.connect(analyser);analyser.connect(ctx.destination);await ctx.resume();await new Promise(r=>setTimeout(r,170));const samples=new Float32Array(analyser.fftSize);analyser.getFloatTimeDomainData(samples);return {peak:Math.max(...samples.map(Math.abs)),currentTime:a.currentTime,context:ctx.state}});
 expect(sound.peak).toBeGreaterThan(.001);
 await page.getByRole('button',{name:'إيقاف التلاوة',exact:true}).click();
 await page.locator('.editor-tabs').getByRole('button',{name:'المشاهد',exact:true}).click();
 await page.getByLabel('قص بداية المشهد 1',{exact:true}).fill('0.3');await page.getByLabel('قص نهاية المشهد 1',{exact:true}).fill('4.5');
 await page.getByRole('button',{name:'تحريك المشهد 1 لأسفل',exact:true}).click();
 await page.getByLabel('انتقال المشهد 1',{exact:true}).selectOption('wipeleft');
 await page.locator('.editor-tabs').getByRole('button',{name:'النص',exact:true}).click();
 await page.getByLabel('خط الآيات',{exact:true}).selectOption('amiri');
 await page.getByRole('button',{name:'لون #FFFFFF',exact:true}).click();
 await page.getByLabel('حجم خط الآيات',{exact:true}).focus();for(let i=0;i<5;i++)await page.keyboard.press('ArrowUp');
 await page.getByLabel('موضع النص الرأسي',{exact:true}).focus();for(let i=0;i<3;i++)await page.keyboard.press('ArrowUp');
 await page.locator('.editor-tabs').getByRole('button',{name:'التصدير',exact:true}).click();
 await page.getByLabel('اسم المشروع',{exact:true}).fill('QA v17 phone — آيات');
 const savedResponse=page.waitForResponse(r=>r.url().includes('/api/projects')&&['POST','PUT'].includes(r.request().method()));
 await page.getByTestId('save-project').click();const saved=await (await savedResponse).json();expect(saved.config.text_style.font).toBe('amiri');expect(saved.config.text_style.size).toBeGreaterThan(80);expect(saved.config.clips[0].scene_id).toBe('garden');
 await page.reload();await page.locator('.creator-page').waitFor();
 const draft=await page.evaluate(()=>JSON.parse(localStorage.getItem('ayat.draft')||'{}'));expect(draft.text_style.size).toBe(saved.config.text_style.size);expect(draft.clips[1].source_in).toBe(.3);
 await page.locator('.bottom-nav').getByRole('button',{name:'مشاريعي',exact:true}).click();await expect(page.getByRole('heading',{name:'QA v17 phone — آيات'})).toBeVisible();
 await page.getByRole('button',{name:'فتح وتعديل',exact:true}).click();
 const exportResponse=page.waitForResponse(r=>r.url().endsWith('/api/jobs')&&r.request().method()==='POST');
 await page.getByTestId('export-editor').click();const custom=await (await exportResponse).json();
 await expect(page.getByTestId('download-mp4')).toBeVisible({timeout:100000});
 const dlPromise=page.waitForEvent('download');await page.getByTestId('download-mp4').click();const dl=await dlPromise;const customFile=OUT+'/ayat_editor_test.mp4';await dl.saveAs(customFile);
 const workspace=await page.evaluate(()=>localStorage.getItem('ayat.workspace'));
 const auditResponse=await context.request.get('/api/jobs/'+custom.id+'/audit?workspace='+workspace);expect(auditResponse.ok()).toBeTruthy();const customAudit=await auditResponse.json();
 expect(customAudit.all_cues_match_source).toBeTruthy();expect(customAudit.result.text_visible_ratio).toBeGreaterThan(.52);expect(customAudit.config.clips[1].source_in).toBe(.3);expect(customAudit.result.timeline.clips[0].transition).toBe('wipeleft');
 const serverBytes=await context.request.get('/api/jobs/'+custom.id+'/file?workspace='+workspace);expect(sha(await serverBytes.body())).toBe(sha(await readFile(customFile)));
 await page.getByRole('button',{name:'إغلاق',exact:true}).click();await page.locator('.bottom-nav').getByRole('button',{name:'الرئيسية',exact:true}).click();
 await page.getByTestId('open-one-click').click();const modal=page.getByRole('dialog',{name:'ريلز، بضغطة واحدة'});
 await modal.getByLabel('السورة',{exact:true}).selectOption('112');await modal.getByLabel('إلى الآية',{exact:true}).fill('4');
 await modal.getByLabel('القارئ',{exact:true}).selectOption('alafasy');await modal.getByRole('button',{name:'ليل',exact:true}).click();
 await modal.locator('summary').filter({hasText:'مراجعة النص من المصدر'}).click();await modal.getByRole('checkbox').check();
 const quickResponse=page.waitForResponse(r=>r.url().endsWith('/api/jobs')&&r.request().method()==='POST');await page.getByTestId('one-click-generate').click();const quick=await (await quickResponse).json();
 expect(quick.config.mood).toBe('ليل');expect(quick.config.clips.map((x:any)=>x.scene_id)).toContain('stars');
 await expect(page.getByTestId('download-mp4')).toBeVisible({timeout:100000});await page.getByTestId('exported-video').evaluate((v:HTMLVideoElement)=>v.load());
 const oneClickDownload=page.waitForEvent('download');await page.getByTestId('download-mp4').click();await(await oneClickDownload).saveAs(OUT+'/ayat_one_click_test.mp4');
 const audit=await(await context.request.get('/api/jobs/'+quick.id+'/audit?workspace='+workspace)).json();
 expect(audit.cues.every((c:any)=>c.text&&c.text.length>0)).toBeTruthy();expect(audit.all_cues_match_source).toBeTruthy();expect(audit.result.width).toBe(720);expect(audit.result.audio_peak).toBeGreaterThan(.001);
 await writeFile(OUT+'/ayat_export_audit.json',JSON.stringify(audit,null,2));
 await page.screenshot({path:REPORT+'/mobile-export-success.jpg',fullPage:true});
 if(!(await page.evaluate(()=>!!navigator.canShare))){await page.getByRole('button',{name:'مشاركة',exact:true}).click();await expect(page.locator('.toast')).toContainText('غير مدعومة')}
 await writeFile(REPORT+'/mobile-flow.json',JSON.stringify({viewport:'390x844 Chromium mobile emulation, not physical Android',audio: sound,saved_project_id:saved.id,editor_job:custom.id,one_click_job:quick.id,download_sha256:sha(await readFile(OUT+'/ayat_one_click_test.mp4')),errors},null,2));
 expect(errors).toEqual([]);
});

test('إيقاف تصدير فعلي ثم إعادة المحاولة من الواجهة',async({page})=>{
 await page.goto('/');await page.locator('.home-hero').waitFor();await page.getByTestId('open-one-click').click();
 const modal=page.getByRole('dialog',{name:'ريلز، بضغطة واحدة'});await modal.getByLabel('إلى الآية',{exact:true}).fill('3');
 await modal.getByLabel('القارئ',{exact:true}).selectOption('husary');
 await page.getByTestId('one-click-generate').click();await expect(page.getByRole('button',{name:'إيقاف التصدير',exact:true})).toBeVisible();
 await page.getByRole('button',{name:'إيقاف التصدير',exact:true}).click();await expect(page.getByTestId('retry-export')).toBeVisible();
 await page.getByTestId('retry-export').click();await expect(page.getByTestId('download-mp4')).toBeVisible({timeout:120000});
 const d=page.waitForEvent('download');await page.getByTestId('download-mp4').click();await(await d).saveAs(OUT+'/ayat_retry_test.mp4');
});

test('قراءة المصدر ومكتبة الحركة، واستعادة محلية عند انقطاع الخادم',async({page,context})=>{
 await page.goto('/#quran');await page.locator('.reader').waitFor();
 const source=await(await context.request.get('/quran.json')).json();const text=await page.locator('[data-verse-key="112:1"]').textContent();expect(text).toContain(source.verses['112:1']);
 await page.locator('.bottom-nav').getByRole('button',{name:'المشاهد',exact:true}).click();await expect(page.locator('.scene-card')).toHaveCount((await(await context.request.get('/api/catalog')).json()).scenes.length);
 await page.getByRole('button',{name:'معاينة مشهد أنفاس البحر',exact:true}).click();await expect.poll(()=>page.locator('.scene-card video').evaluate(v=>(v as HTMLVideoElement).currentTime)).toBeGreaterThan(.3);
 await page.locator('.bottom-nav').getByRole('button',{name:'إنشاء',exact:true}).click();await page.locator('.editor-tabs').getByRole('button',{name:'التصدير',exact:true}).click();await page.getByLabel('اسم المشروع',{exact:true}).fill('نسخة الاختبار المحلية');await page.getByTestId('save-project').click();await expect(page.getByRole('status')).toContainText('حُفظ المشروع');
 await page.route('**/api/**',route=>route.abort());await page.goto('/#projects');await page.locator('.projects-page').waitFor();
 await expect(page.getByRole('heading',{name:'نسخة الاختبار المحلية'})).toBeVisible();await expect(page.locator('.info-note')).toContainText('النسخ المحلية');
 await page.getByRole('button',{name:'فتح وتعديل',exact:true}).click();await expect(page.locator('.creator-page')).toBeVisible();
 expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
});

test('شاشات سطح المكتب والقياسات الضيقة لا تتجاوز العرض',async({page})=>{
 for(const size of [{width:1440,height:1000},{width:360,height:800}]){
  await page.setViewportSize(size);await page.goto('/');await page.locator('.home-hero').waitFor();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
  await page.goto('/#templates');await page.locator('.templates-grid').waitFor();await expect(page.locator('.templates-grid .template-card')).toHaveCount(80);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
 }
});
