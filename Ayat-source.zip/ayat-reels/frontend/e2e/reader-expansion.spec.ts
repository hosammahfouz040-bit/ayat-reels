import {test,expect,type Page} from '@playwright/test';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {homedir} from 'node:os';
const proofs:any[]=[];
const hash=(x:Buffer)=>createHash('sha256').update(x).digest('hex');
test.afterAll(async()=>{if(proofs.length)await writeFile('../tests/reader-expansion-flow-v17-regression.json',JSON.stringify({version:'1.7.0',proofs,temporary_assistant_qa_only:true,physical_android_tested:false,real_arena_download_issue_resolved:false},null,2))});

test('الزيادة: 13 تسجيلًا و124 مقطع آية دون تغيير القراء السابقين، مع توضيح الكامل والجزئي',async({page,context})=>{
 const c=await(await context.request.get('/api/catalog')).json();expect(c.app_version).toBe('1.7.3');expect(c.reciters).toHaveLength(54);
 await page.goto('/#create');await page.getByLabel('القارئ',{exact:true}).selectOption('mossad');
 const available=page.getByTestId('available-recitations');await expect(available.locator('button')).toHaveCount(9);
 await expect(available.getByRole('button',{name:/^سورة الشرح/})).toContainText('كاملة');await expect(available.getByRole('button',{name:/^سورة التين/})).toContainText('كاملة');
 await expect(available.getByRole('button',{name:/^من سورة الضحى/})).toHaveCount(2);
 await available.getByRole('button',{name:/^سورة الشرح/}).click();await expect(page.getByLabel('من الآية',{exact:true})).toHaveValue('1');await expect(page.getByLabel('إلى الآية',{exact:true})).toHaveValue('8');await expect(page.getByTestId('export-editor')).toBeEnabled();
 await page.getByLabel('القارئ',{exact:true}).selectOption('suhaim');await expect(available.locator('button')).toHaveCount(9);await expect(available.getByRole('button',{name:/^من سورة القيامة/})).toHaveCount(4);
 await available.getByRole('button',{name:/^من سورة الفجر/}).click();await expect(page.getByLabel('من الآية',{exact:true})).toHaveValue('5');await expect(page.getByLabel('إلى الآية',{exact:true})).toHaveValue('32');await expect(page.getByTestId('selected-narration')).toContainText('ورش');
});

test('لا يُسمح بتجهيز أو تصدير مدى يعبر فجوة غير متحققة، ولا بتبديل القارئ خفية',async({page,context})=>{
 await page.goto('/#create');await page.getByLabel('القارئ',{exact:true}).selectOption('mossad');await page.getByLabel('السورة',{exact:true}).selectOption('93');await page.getByLabel('من الآية',{exact:true}).fill('3');await page.getByLabel('إلى الآية',{exact:true}).fill('11');
 await expect(page.getByTestId('prepare-audio')).toBeDisabled();await expect(page.getByTestId('export-editor')).toBeDisabled();
 await page.getByTestId('available-recitations').getByRole('button',{name:/^من سورة الضحى/}).first().click();await expect(page.getByLabel('إلى الآية',{exact:true})).toHaveValue('5');await expect(page.getByTestId('prepare-audio')).toBeEnabled();
 const blocked=await context.request.post('/api/audio/prepare',{data:{surah:75,from_ayah:6,to_ayah:10,reciter:'suhaim'}});expect(blocked.status()).toBe(422);
 await page.getByLabel('القارئ',{exact:true}).selectOption('suhaim');await page.getByLabel('السورة',{exact:true}).selectOption('75');await page.getByLabel('من الآية',{exact:true}).fill('6');await page.getByLabel('إلى الآية',{exact:true}).fill('10');await expect(page.getByTestId('prepare-audio')).toBeDisabled();
});

test('القائمة الموسعة وترقيم ورش حتى الفجر 32 متاحان دون API مع الخط الأصلي',async({page})=>{
 await page.route('**/api/**',r=>r.abort());await page.goto('/#create');await page.getByLabel('القارئ',{exact:true}).selectOption('suhaim');await expect(page.getByTestId('available-recitations').locator('button')).toHaveCount(9);
 await page.getByTestId('available-recitations').getByRole('button',{name:/^من سورة الفجر/}).click();await page.locator('.source-review summary').click();const last=page.locator('.source-review [data-verse-key="89:32"]');await expect(last).toBeVisible();await page.evaluate(()=>document.fonts.load('40px KFGQPCWarsh'));expect(await last.evaluate(e=>getComputedStyle(e).fontFamily)).toContain('KFGQPCWarsh');
});

async function exportActual(page:Page,reciter:string,surah:number,from:number,to:number){
 await page.goto('/#create');await page.getByLabel('القارئ',{exact:true}).selectOption(reciter);await page.getByLabel('السورة',{exact:true}).selectOption(String(surah));await page.getByLabel('من الآية',{exact:true}).fill(String(from));await page.getByLabel('إلى الآية',{exact:true}).fill(String(to));
 const audioResponse=page.waitForResponse(r=>r.url().endsWith('/api/audio/prepare')&&r.request().method()==='POST');await page.getByTestId('prepare-audio').click();const response=await audioResponse;expect(response.status()).toBe(200);const plan=await response.json();expect(plan.reciter).toBe(reciter);expect(plan.verses).toHaveLength(to-from+1);
 await page.getByRole('button',{name:'تشغيل التلاوة',exact:true}).click();await page.waitForFunction(()=>{const a=document.querySelector('audio');return a&&!a.paused&&a.currentTime>.4});await page.getByRole('button',{name:'إيقاف التلاوة',exact:true}).click();
 await page.locator('.editor-tabs').getByRole('button',{name:'المشاهد',exact:true}).click();for(let i=0;i<2;i++)await page.getByRole('button',{name:'حذف',exact:true}).first().click();await expect(page.locator('.clip-card')).toHaveCount(1);
 await page.locator('.editor-tabs').getByRole('button',{name:'النص',exact:true}).click();await page.getByRole('button',{name:'لون #E8EFDE',exact:true}).click();
 await page.locator('.editor-tabs').getByRole('button',{name:'التصدير',exact:true}).click();await page.getByLabel('اسم المشروع',{exact:true}).fill('QA v14 '+reciter+' '+surah+':'+from+'-'+to);await page.getByRole('button',{name:/اقتصادية/}).click();
 const start=page.waitForResponse(r=>r.url().endsWith('/api/jobs')&&r.request().method()==='POST');await page.getByTestId('export-editor').click();const job=await(await start).json();const link=page.getByTestId('download-mp4');await expect(link).toBeVisible({timeout:150000});const event=page.waitForEvent('download');await link.click();const dl=await event;expect(await dl.failure()).toBeNull();const cache=homedir()+'/.cache/ayat-reader-expansion';await mkdir(cache,{recursive:true});const saved=cache+'/export-'+reciter+'-v14.mp4';await dl.saveAs(saved);const bytes=await readFile(saved);
 const ws=await page.evaluate(()=>localStorage.getItem('ayat.workspace'));const audit=await(await page.request.get('/api/jobs/'+job.id+'/audit?workspace='+ws)).json();const source=await(await page.request.get(reciter==='suhaim'?'/quran-warsh.json':'/quran.json')).json();
 expect(audit.all_cues_match_source).toBeTruthy();expect(audit.cues.every((v:any)=>v.text===source.verses[v.key])).toBeTruthy();expect(audit.quran_source.sha256).toBe(source.sha256);expect(audit.config.narration).toBe(reciter==='suhaim'?'warsh':'hafs');expect(audit.config.text_style.color).toBe('#E8EFDE');expect(audit.result.text_visible_ratio).toBeGreaterThan(.52);expect(audit.result.audio_peak).toBeGreaterThan(.001);expect(audit.config.clips).toHaveLength(1);expect(audit.audio_files.every((v:any)=>v.derived_excerpt&&v.source_recording_sha256)).toBeTruthy();
 const file=await page.request.get((await link.getAttribute('href'))!);expect(hash(await file.body())).toBe(hash(bytes));expect(file.headers()['content-type']).toContain('video/mp4');
 await writeFile('../tests/reader-expansion-'+reciter+'-audit-v14.json',JSON.stringify(audit,null,2));
 proofs.push({reader:reciter,narration:audit.config.narration,surah,from_ayah:from,to_ayah:to,job:job.id,project:job.project_id,workspace:ws,canonical_file:'backend/runtime/exports/'+job.id+'/result.mp4',downloaded_file:saved,sha256:hash(bytes),bytes:bytes.length,duration:audit.result.duration,text_source_sha256:source.sha256,text_exact:true,text_visible_ratio:audit.result.text_visible_ratio,audio_peak:audit.result.audio_peak,source_plan:plan.id,browser_download_saved:true,retained_for_user:false,temporary_assistant_qa_only:true,physical_android_tested:false});
}

test('مسعد: تشغيل وتصدير فعلي من الإضافة الجديدة الشرح 5–6',async({page})=>{await exportActual(page,'mossad',94,5,6)});
test('سحيم: الفجر 30–32 بترقيم ورش وصوته الأصلي ونصه داخل MP4',async({page})=>{await exportActual(page,'suhaim',89,30,32)});
