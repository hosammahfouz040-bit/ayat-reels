import {test,expect} from '@playwright/test';
import {writeFile,readFile,mkdir,rename} from 'node:fs/promises';
import {homedir} from 'node:os';
import {createHash,randomUUID} from 'node:crypto';
import {defaultEffects} from '../src/effects';
const caps='warsh,reciters-v13,scene-library-v17,publisher-timing-v1,publication-v1,visual-fx-v1';
const jobs:any[]=[];const proofs:any[]=[];
function config(long=false){return {title:'QA connectivity172 '+(long?'long':'short'),surah:112,from_ayah:long?1:2,to_ayah:long?4:2,reciter:'raad_kurdi',narration:'hafs',template_id:'noor',mood:'سكينة',quality:'hd',text_style:{font:'amiri_quran',size:80,color:'#F5E8C8',x:.5,y:.49,max_width:.82,line_height:1.8,alignment:'center',box_color:'#071F1A',box_opacity:.26,shadow:true,shadow_color:'#000000',shadow_blur:5},clips:[{id:'qa-connection-clip',scene_id:'orbit',source_in:0,source_out:6,duration:6,transition:'fade',transition_duration:.5}],auto_fit:true,audio_trim_start:0,audio_trim_end:null,timings:null,text_reviewed:false,effects:defaultEffects()}}
async function boot(page:any,c:any,extra?:{legacy?:string;project?:string}){await page.addInitScript(({config,extra})=>{localStorage.setItem('ayat.draft',JSON.stringify(config));if(extra?.legacy)localStorage.setItem('ayat.activeJob',extra.legacy);if(extra?.project)localStorage.setItem('ayat.projectId',extra.project)},{config:c,extra});await page.goto('/#create');await expect(page.getByTestId('export-editor')).toBeVisible();await expect(page.locator('.engine-status')).toContainText('المحرك متصل')}
async function ws(page:any){return page.evaluate(()=>localStorage.getItem('ayat.workspace'))}
function hdr(workspace:string){return {'X-Workspace-Id':workspace,'X-Ayat-Capabilities':caps}}
function track(j:any,workspace:string){jobs.push({job:j.id,workspace,project:j.project_id,temporary_assistant_qa_only:true})}
async function start(page:any){const pending=page.waitForResponse((r:any)=>r.url().endsWith('/api/jobs')&&r.request().method()==='POST'&&r.ok());await page.getByTestId('export-editor').click();const j=await(await pending).json();track(j,await ws(page));return j}
async function completed(request:any,jid:string,workspace:string){let result:any;await expect.poll(async()=>{result=await(await request.get('/api/jobs/'+jid,{headers:hdr(workspace)})).json();return result.state},{timeout:150000,intervals:[500,1000]}).toBe('completed');return result}
test.beforeAll(async()=>{await mkdir(homedir()+'/.cache/ayat-connectivity-v172/browser',{recursive:true})});
test.afterAll(async()=>{let old:any={};try{old=JSON.parse(await readFile('../tests/export-connection-ui-v172.json','utf8'))}catch{}await writeFile('../tests/export-connection-ui-v172.json',JSON.stringify({version:'1.7.2',jobs:[...(old.jobs||[]),...jobs],proofs:[...(old.proofs||[]),...proofs],physical_android_tested:false,actual_fault_injection_not_a_fake_export:true},null,2))});

test('انقطاع الشبكة لا يوقف العامل: MP4 حقيقي يكتمل ثم تظهر النتيجة عند عودة الاتصال',async({page,context,request})=>{
 const c=config(true);c.effects.verse={enabled:true,kind:'glow',intensity:.3,duration:1.2};await boot(page,c);let active=0,max=0;const pending=new Set<any>();page.on('request',r=>{if(r.method()==='GET'&&/\/api\/jobs\/[0-9a-f-]{36}$/.test(r.url())){pending.add(r);active++;max=Math.max(max,active)}});const done=(r:any)=>{if(pending.delete(r))active--};page.on('requestfinished',done);page.on('requestfailed',done);
 const j=await start(page),workspace=await ws(page);await expect(page.getByRole('button',{name:'إيقاف التصدير',exact:true})).toBeVisible();await context.setOffline(true);await expect(page.getByTestId('export-connection')).toHaveAttribute('data-connection-state','offline',{timeout:12000});await expect(page.getByTestId('export-connection')).toContainText('حالة التصدير غير مؤكدة');
 const real=await completed(request,j.id,workspace);expect(real.result.bytes).toBeGreaterThan(5000);expect(await page.getByTestId('download-mp4').count()).toBe(0);await context.setOffline(false);await expect(page.getByTestId('download-mp4')).toBeVisible({timeout:15000});expect(max).toBeLessThanOrEqual(1);
 const audit=await(await request.get('/api/jobs/'+j.id+'/audit?workspace='+workspace)).json();expect(audit.all_cues_match_source).toBeTruthy();expect(audit.result.text_layout_version).toBe('compact-ink-v1');const file=await request.get('/api/jobs/'+j.id+'/file?workspace='+workspace);expect(file.ok()).toBeTruthy();const data=await file.body();await writeFile(homedir()+'/.cache/ayat-connectivity-v172/browser/offline-finished.mp4',data);proofs.push({case:'real-export-continued-while-browser-offline',job:j.id,workspace,bytes:data.length,sha256:createHash('sha256').update(data).digest('hex'),source_quran_exact:true,max_overlapping_job_gets:max,completed_before_browser_reconnected:true});
});

test('إعادة فتح الصفحة أثناء فقد متابعة الحالة تستعيد آخر رد موثق دون نسبة وهمية',async({page,request})=>{
 await boot(page,config(true));const j=await start(page),workspace=await ws(page);await expect.poll(async()=>page.evaluate(()=>!!localStorage.getItem('ayat.activeJobSnapshot.v1'))).toBeTruthy();
 await page.route('**/api/jobs/'+j.id,route=>route.abort('connectionreset'));await expect(page.getByTestId('export-connection')).toHaveAttribute('data-connection-state','offline',{timeout:12000});await page.reload();await expect(page.locator('.job-banner')).toBeVisible();await page.locator('.job-banner').click();await expect(page.getByText('آخر حالة وصلت من الخادم، وليست تأكيدًا بأنه يعمل الآن')).toBeVisible();await expect(page.getByTestId('export-connection')).toHaveAttribute('data-connection-state','offline');
 await completed(request,j.id,workspace);await page.unroute('**/api/jobs/'+j.id);await page.getByTestId('reconnect-export').click();await expect(page.getByTestId('download-mp4')).toBeVisible({timeout:15000});proofs.push({case:'local-snapshot-survives-reload-during-status-outage',job:j.id,workspace,restored_without_faking_progress:true});
});

test('404 حقيقي لسجل قديم لا يبقى في حلقة؛ استعادة المسودة تنشئ تصديرًا فعليًا واحدًا',async({page,request})=>{
 const absent=randomUUID(),project=randomUUID();const c=config();await boot(page,c,{legacy:absent,project});await expect(page.locator('.job-banner')).toContainText('سجل التصدير غير متاح');await page.locator('.job-banner').click();await expect(page.getByTestId('export-connection')).toHaveAttribute('data-connection-state','missing');expect(await page.locator('.export-progress').count()).toBe(0);
 const response=page.waitForResponse(r=>r.url().endsWith('/api/jobs')&&r.request().method()==='POST'&&r.ok());await page.getByTestId('recover-export').click();const j=await(await response).json(),workspace=await ws(page);track(j,workspace);await expect(page.getByTestId('download-mp4')).toBeVisible({timeout:90000});const list=await(await request.get('/api/jobs',{headers:hdr(workspace)})).json();expect(list).toHaveLength(1);expect(j.id).not.toBe(absent);expect(j.config.reciter).toBe(c.reciter);expect(j.config.clips).toMatchObject(c.clips);proofs.push({case:'real-404-classified-and-draft-reexported-once',job:j.id,workspace,no_indefinite_network_spinner:true,scene_order_and_style_retained:true});
});

test('ضياع رد POST بعد وصوله للخادم يستعيد الطلب نفسه ولا ينشئ فيديوهين',async({page,request})=>{
 await boot(page,config());let created:any=null,key='';let release!:()=>void;const hold=new Promise<void>(r=>release=r);let blocked=true;
 await page.route('**/api/jobs/by-request/*',async route=>{if(blocked)await hold;await route.continue()});
 await page.route('**/api/jobs',async route=>{if(route.request().method()!=='POST'){await route.continue();return}key=route.request().headers()['x-ayat-request-id'];const reply=await route.fetch();expect(reply.ok()).toBeTruthy();created=await reply.json();await route.abort('connectionreset')},{times:1});
 await page.getByTestId('export-editor').click();await expect(page.getByTestId('export-recovery')).toBeVisible();await expect(page.getByTestId('export-recovery')).toContainText('لم يصل تأكيد');const workspace=await ws(page);expect(created).toBeTruthy();expect(key).toMatch(/^[0-9a-f-]{36}$/);track(created,workspace);const before=await(await request.get('/api/jobs',{headers:hdr(workspace)})).json();expect(before).toHaveLength(1);
 blocked=false;release();await expect(page.getByTestId('download-mp4')).toBeVisible({timeout:90000});const after=await(await request.get('/api/jobs',{headers:hdr(workspace)})).json();expect(after).toHaveLength(1);expect(after[0].id).toBe(created.id);proofs.push({case:'actual-server-post-ack-dropped-and-recovered-by-request-key',job:created.id,workspace,request_id:key,server_job_count:1});
});

test('رد GET متأخر بعد الإلغاء لا يعيد الحالة إلى قيد التصدير، ولا تتداخل طلبات المتابعة',async({page,request})=>{
 const c=config(true);c.surah=2;c.from_ayah=c.to_ayah=255;c.reciter='qahtani';await boot(page,c);let release!:()=>void;const hold=new Promise<void>(r=>release=r);let held=false,reads=0;
 await page.route(/\/api\/jobs\/[0-9a-f-]{36}$/,async route=>{if(route.request().method()!=='GET'){await route.continue();return}reads++;if(!held){held=true;const reply=await route.fetch();await hold;try{await route.fulfill({response:reply})}catch{}}else await route.continue()});
 const j=await start(page),workspace=await ws(page);await expect.poll(()=>held).toBeTruthy();await page.waitForTimeout(2300);expect(reads).toBe(1);await page.getByRole('button',{name:'إيقاف التصدير',exact:true}).click();await expect(page.getByTestId('retry-export')).toBeVisible();release();await page.waitForTimeout(800);await expect(page.getByTestId('retry-export')).toBeVisible();const saved=await(await request.get('/api/jobs/'+j.id,{headers:hdr(workspace)})).json();expect(saved.state).toBe('canceled');proofs.push({case:'real-cancel-stays-terminal-after-delayed-active-get',job:j.id,workspace,overlapping_gets_while_held:reads,stale_progress_not_applied:true});
});


test('ملف قديم مفقود يُعلن بوضوح وتُستعاد نسخة جديدة دون الكتابة على تعديلات المشروع',async({page,request})=>{
 await boot(page,config());const original=await start(page),workspace=await ws(page);await expect(page.getByTestId('download-mp4')).toBeVisible({timeout:90000});
 const project=await(await request.get('/api/projects/'+original.project_id,{headers:hdr(workspace)})).json();project.config.title+=' edited after export';project.config.text_style.size=92;expect((await request.put('/api/projects/'+project.id,{headers:hdr(workspace),data:{config:project.config}})).ok()).toBeTruthy();
 const source='../backend/runtime/exports/'+original.id+'/result.mp4',hold=homedir()+'/.cache/ayat-connectivity-v172/browser/held-'+original.id+'.mp4';await rename(source,hold);
 try{
  await page.reload();await page.locator('.job-banner').click();await expect(page.getByTestId('export-recovery')).toContainText('نسخة الفيديو لم تعد متاحة');expect(await page.getByTestId('download-mp4').count()).toBe(0);
  const pending=page.waitForResponse(r=>r.url().endsWith('/api/jobs')&&r.request().method()==='POST'&&r.ok());await page.getByTestId('recover-export').click();const fresh=await(await pending).json();track(fresh,workspace);expect(fresh.project_id).not.toBe(original.project_id);await expect(page.getByTestId('download-mp4')).toBeVisible({timeout:90000});
  const retained=await(await request.get('/api/projects/'+project.id,{headers:hdr(workspace)})).json();expect(retained.config.text_style.size).toBe(92);expect(retained.config.title).toBe(project.config.title);proofs.push({case:'missing-real-test-file-detected-and-restored-as-new-project',original_job:original.id,recovered_job:fresh.id,workspace,old_project_edits_unchanged:true});
 }finally{await rename(hold,source)}
});
