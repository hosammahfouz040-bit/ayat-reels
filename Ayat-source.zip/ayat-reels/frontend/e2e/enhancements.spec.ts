import {test,expect} from '@playwright/test';
import {writeFile,readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';

test('الآيات: كتابة حرة وأرقام عربية وحدود صحيحة في المحرر والإنشاء السريع',async({page})=>{
 await page.goto('/#create');await page.locator('.creator-page').waitFor();
 const from=page.getByLabel('من الآية',{exact:true}),to=page.getByLabel('إلى الآية',{exact:true});
 await page.getByLabel('السورة',{exact:true}).selectOption('2');await from.fill('');await expect(from).toHaveValue('');await expect(page.getByTestId('export-editor')).toBeDisabled();
 await from.fill('١٢');await to.fill('١٥');await expect(from).toHaveValue('12');await expect(to).toHaveValue('15');await expect(page.getByTestId('export-editor')).toBeEnabled();
 await from.fill('12');await to.fill('25');await expect(from).toHaveValue('12');await expect(to).toHaveValue('25');
 await page.getByLabel('السورة',{exact:true}).selectOption('112');await to.fill('٥');await expect(to).toHaveValue('٥');await expect(page.locator('.ayah-range-error')).toContainText('هذه السورة تحتوي');await expect(page.getByTestId('export-editor')).toBeDisabled();
 await to.fill('4');await expect(page.getByTestId('export-editor')).toBeEnabled();
 await page.locator('.bottom-nav').getByRole('button',{name:'الرئيسية',exact:true}).click();await page.getByTestId('open-one-click').click();const m=page.getByRole('dialog',{name:'ريلز، بضغطة واحدة'});
 await m.getByLabel('إلى الآية',{exact:true}).fill('');await expect(page.getByTestId('one-click-generate')).toBeDisabled();await m.getByLabel('السورة',{exact:true}).selectOption('93');await m.getByLabel('من الآية',{exact:true}).fill('١');await m.getByLabel('إلى الآية',{exact:true}).fill('٥');await expect(page.getByTestId('one-click-generate')).toBeEnabled();
 await page.screenshot({path:'../tests/mobile-updated-range.jpg',fullPage:true});
});

test('80 قالبًا و54 قارئًا والبحث الحقيقي عن قارئ جديد وتشغيله',async({page})=>{
 await page.goto('/#templates');await expect(page.locator('.template-card')).toHaveCount(80);
 await page.getByTestId('template-falling_light').click();await expect(page.locator('.creator-page')).toBeVisible();
 await expect(page.getByLabel('القارئ',{exact:true}).locator('option')).toHaveCount(54);
 await page.getByLabel('بحث عن قارئ',{exact:true}).fill('ماهر');await page.getByRole('button',{name:'اختيار القارئ ماهر المعيقلي',exact:true}).click();await expect(page.getByLabel('القارئ',{exact:true})).toHaveValue('maher');
 await page.getByLabel('إلى الآية',{exact:true}).fill('2');await page.getByTestId('prepare-audio').click();await page.getByRole('button',{name:'تشغيل التلاوة',exact:true}).click();
 await page.waitForFunction(()=>{const a=document.querySelector('audio');return !!a&&!a.paused&&a.currentTime>.7&&a.readyState>=3});
 await page.getByRole('button',{name:'إيقاف التلاوة',exact:true}).click();
 await page.screenshot({path:'../tests/mobile-reader-search-and-nature.jpg',fullPage:true});
});

test('مكتبة متوسعة من الفيديو المصور والمعاينة والإضافة تتحرك فعليًا',async({page,context})=>{
 const catalog=await(await context.request.get('/api/catalog')).json();expect(catalog.scenes.length).toBeGreaterThanOrEqual(40);expect(catalog.scenes.filter((s:any)=>s.kind==='real-footage').length).toBeGreaterThanOrEqual(32);
 await page.goto('/#scenes');await expect(page.locator('.scene-card')).toHaveCount(catalog.scenes.length);
 for(const id of ['waterfall','beach','blue_flowers','snow_forest']){
  const s=catalog.scenes.find((s:any)=>s.id===id);await page.getByRole('button',{name:'معاينة مشهد '+s.name,exact:true}).click();await expect.poll(()=>page.locator('.scene-card video').evaluate((v:HTMLVideoElement)=>v.currentTime)).toBeGreaterThan(.3);
 }
 await page.getByRole('button',{name:'اختيار مشهد اندفاع الشلال',exact:true}).click();await page.getByRole('button',{name:'ترتيب المشاهد',exact:true}).click();await page.locator('.editor-tabs').getByRole('button',{name:'المشاهد',exact:true}).click();await expect(page.locator('.clip-card')).toHaveCount(4);await expect(page.locator('.clip-card')).toContainText(['محراب النور','ندى البستان','مدارات السكينة','اندفاع الشلال']);
 expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
});

test('من ١ إلى ٥ بالضحى + قارئ جديد + طبيعة حقيقية → MP4 وصوت ونص موثق',async({page,context})=>{
 const catalog=await(await context.request.get('/api/catalog')).json();const quran=await(await context.request.get('/quran.json')).json();
 await page.goto('/');await page.getByTestId('open-one-click').click();const modal=page.getByRole('dialog',{name:'ريلز، بضغطة واحدة'});
 await modal.getByLabel('السورة',{exact:true}).selectOption('93');await modal.getByLabel('من الآية',{exact:true}).fill('١');await modal.getByLabel('إلى الآية',{exact:true}).fill('٥');await modal.getByLabel('القارئ',{exact:true}).selectOption('yasser');await modal.getByRole('button',{name:'طبيعة',exact:true}).click();
 const pending=page.waitForResponse(r=>r.url().endsWith('/api/jobs')&&r.request().method()==='POST');await page.getByTestId('one-click-generate').click();const response=await pending;expect(response.ok()).toBeTruthy();const job=await response.json();
 expect(job.config.surah).toBe(93);expect(job.config.from_ayah).toBe(1);expect(job.config.to_ayah).toBe(5);expect(job.config.reciter).toBe('yasser');expect(job.config.clips.every((c:any)=>catalog.scenes.find((s:any)=>s.id===c.scene_id)?.kind==='real-footage')).toBeTruthy();
 await expect(page.getByTestId('download-mp4')).toBeVisible({timeout:140000});const downloaded=page.waitForEvent('download');await page.getByTestId('download-mp4').click();const file=await downloaded;await file.saveAs('../deliverables/ayat_nature_update.mp4');
 const workspace=await page.evaluate(()=>localStorage.getItem('ayat.workspace'));const auditResponse=await context.request.get('/api/jobs/'+job.id+'/audit?workspace='+workspace);expect(auditResponse.ok()).toBeTruthy();const audit=await auditResponse.json();
 expect(audit.all_cues_match_source).toBeTruthy();expect(audit.cues).toHaveLength(5);expect(audit.cues.every((v:any)=>v.text===quran.verses[v.key])).toBeTruthy();expect(audit.visual_sources).toHaveLength(3);expect(audit.visual_sources.every((s:any)=>s.license==='CC0-1.0'&&s.source_url&&s.kind==='real-footage')).toBeTruthy();expect(audit.result.text_visible_ratio).toBeGreaterThan(.52);expect(audit.result.audio_peak).toBeGreaterThan(.001);
 const bytes=await readFile('../deliverables/ayat_nature_update.mp4');const proof={job:job.id,project:job.project_id,workspace,sha256:createHash('sha256').update(bytes).digest('hex'),bytes:bytes.length,scene_ids:job.config.clips.map((c:any)=>c.scene_id),duration:audit.result.duration,reciter:job.config.reciter,range:'93:1-5',quran_source_sha256:audit.result.source_sha256,all_source_text_exact:true,phone_hardware_tested:false};
 await writeFile('../tests/enhancements-flow.json',JSON.stringify(proof,null,2));await writeFile('../deliverables/ayat_nature_audit.json',JSON.stringify(audit,null,2));await page.screenshot({path:'../tests/mobile-nature-export-success.jpg',fullPage:true});
});
