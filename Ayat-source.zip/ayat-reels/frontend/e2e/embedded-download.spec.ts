import {test,expect,type Page,type FrameLocator,type Download} from '@playwright/test';
import {readFile,writeFile,mkdir,unlink} from 'node:fs/promises';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {homedir} from 'node:os';

// Opt in when the already-rendered genuine MP4 and its DB job are available.
// These are HTTP/browser-policy tests, not a replacement for a real encoder test.
const fixture=JSON.parse(readFileSync('../tests/mosques-flow.json','utf8'));
const enabled=process.env.AYAT_DOWNLOAD_REUSE_FIXTURE==='1';
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const escapes='allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox';
const evidence:any[]=[];
let base='';
const harness='dist/__ayat_download_policy_harness__.html';
const wrapper=`<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0}iframe{width:100%;height:100vh;border:0}</style><script>addEventListener('DOMContentLoaded',()=>{const p=new URLSearchParams(location.search),f=document.createElement('iframe'),u=new URL(p.get('child')||'/#projects',location.origin);u.hostname=u.hostname==='127.0.0.1'?'localhost':'127.0.0.1';f.title='إطار اختبار';f.setAttribute('sandbox',p.get('sandbox')||'');f.src=u.href;document.body.append(f)})</script>`;
function parentUrl(sandbox:string,child='/#projects'){return '/__ayat_download_policy_harness__.html?sandbox='+encodeURIComponent(sandbox)+'&child='+encodeURIComponent(child)}

test.describe('تنزيل MP4 الحقيقي في الإطار وخارجه',()=>{
 test.skip(!enabled,'فعّل AYAT_DOWNLOAD_REUSE_FIXTURE=1 مع ملف MP4 المكتمل ومساحة الاختبار المحفوظة.');
 test.setTimeout(45000);
 test.beforeAll(async({request,baseURL})=>{
  base=baseURL!;
  expect(['127.0.0.1','localhost']).toContain(new URL(base).hostname);
  // Serve a REAL parent response. Intercepting the parent with route.fulfill classifies
  // its address space differently in Chromium 156 and blocks loopback iframe requests.
  // Do not disable Local Network Access checks or sandbox protections.
  await writeFile(harness,wrapper);
  const response=await request.get('/api/jobs/'+fixture.job+'?workspace='+fixture.workspace);
  expect(response.status(),'The retained genuine export must exist; never manufacture a completed job.').toBe(200);
  expect((await response.json()).state).toBe('completed');
 });
 test.afterAll(async()=>{
  if(enabled)await unlink(harness).catch(()=>{});
  if(enabled)await writeFile('../tests/embedded-download-policy.json',JSON.stringify({date:'2026-10-25',environment:'Chromium with Pixel 7 emulation; not physical Android',real_arena_parent_policy_inspected:false,fixture_job:fixture.job,bytes:fixture.bytes,sha256:fixture.sha256,cases:evidence},null,2));
 });

 async function open(page:Page,sandbox?:string){
  await page.addInitScript(({workspace,job})=>{localStorage.setItem('ayat.workspace',workspace);localStorage.setItem('ayat.activeJob',job)},fixture);
  let app:Page|FrameLocator=page;
  if(sandbox!==undefined){
   await page.goto(parentUrl(sandbox));app=page.frameLocator('iframe');
  }else await page.goto('/#projects');
  await app.getByRole('button',{name:/^التصدير الأخير /}).first().click();
  const link=app.getByTestId('download-mp4');await expect(link).toBeVisible();
  return {app,link};
 }
 function nextDownload(page:Page,timeout=15000):Promise<Download>{
  const context=page.context();const watched=new Set<Page>();
  return new Promise((resolve,reject)=>{
   const clean=()=>{clearTimeout(timer);context.off('page',watch);for(const p of watched)p.off('download',done)};
   const done=(d:Download)=>{clean();resolve(d)};
   const watch=(p:Page)=>{if(!watched.has(p)){watched.add(p);p.on('download',done)}};
   const timer=setTimeout(()=>{clean();reject(Error('No browser download event in any page'))},timeout);
   context.on('page',watch);for(const p of context.pages())watch(p);
  });
 }
 async function saveExact(page:Page,click:()=>Promise<void>,label:string){
  const root=homedir()+'/.cache/ayat-download-frame-qa';await mkdir(root,{recursive:true});
  const started=Date.now();const pending=nextDownload(page);await click();const download=await pending;
  const delay=Date.now()-started;
  const path=root+'/'+label+'.mp4';await download.saveAs(path);
  expect(await download.failure()).toBeNull();expect(download.suggestedFilename()).toBe('Ayat_112_1-4.mp4');
  const file=await readFile(path);expect(file.length).toBe(fixture.bytes);expect(sha(file)).toBe(fixture.sha256);
  expect(download.url()).toContain('/file?workspace=');expect(download.url()).not.toMatch(/^blob:/);
  evidence.push({label,download_saved:true,identical_to_genuine_export:true,request_event_ms:delay,filename:download.suggestedFilename()});
 }

 test('الصفحة المستقلة: ضغطة واحدة تحفظ MP4 مطابقًا بلا تغيير الصفحة',async({page})=>{
  const {app,link}=await open(page);
  await expect(link).toHaveAttribute('download','Ayat_112_1-4.mp4');await expect(link).not.toHaveAttribute('target');
  await expect(app.getByTestId('embedded-download-warning')).toHaveCount(0);
  await saveExact(page,()=>link.click(),'standalone-primary');
  expect(page.url()).toContain('#projects');
 });
 test('إعادة إنتاج الخلل: download داخل إطار بلا صلاحية تنزيل يُحظر رغم سلامة MP4',async({page})=>{
  const blocked:string[]=[];page.on('console',m=>{if(/download.*(disallow|sandbox)|allow-downloads/i.test(m.text()))blocked.push(m.text())});
  const {link}=await open(page,escapes);
  // Reproduce ONLY the previous link attributes; do not replace the real file/API.
  await link.evaluate((a:HTMLAnchorElement)=>{const u=new URL(a.href);u.pathname=u.pathname.replace(/\/open$/,'/file');u.searchParams.delete('start');a.href=u.href;a.removeAttribute('target');a.setAttribute('download','Ayat_112_1-4.mp4')});
  const pending=nextDownload(page,2000).catch(()=>null);await link.click();expect(await pending).toBeNull();
  await expect(page.locator('iframe')).toHaveAttribute('sandbox',escapes);
  evidence.push({label:'previous-in-frame-download-attributes',download_saved:false,blocked_as_expected:true,browser_policy_message:blocked[0]||null,paired_control:'The same previous attributes save the identical file when allow-downloads is present.'});
 });
 test('اختبار ضابط: الصفات القديمة تعمل داخل الإطار فقط عند منح صلاحية التنزيل',async({page})=>{
  const {link}=await open(page,escapes+' allow-downloads');
  await link.evaluate((a:HTMLAnchorElement)=>{const u=new URL(a.href);u.pathname=u.pathname.replace(/\/open$/,'/file');u.searchParams.delete('start');a.href=u.href;a.removeAttribute('target');a.setAttribute('download','Ayat_112_1-4.mp4')});
  await saveExact(page,()=>link.click(),'previous-link-with-allow-downloads-control');
 });
 test('الإطار الذي يسمح بتبويب مستقل: الزر الجديد يحفظ الملف من أول ضغطة',async({page})=>{
  const {app,link}=await open(page,escapes);
  await expect(link).toHaveAttribute('target','_blank');await expect(link).not.toHaveAttribute('download');
  await expect(link).toHaveAttribute('href',/\/open\?start=1&workspace=/);await expect(link).toHaveAttribute('rel','noopener noreferrer');await expect(app.getByTestId('embedded-download-warning')).toBeVisible();
  let newExports=0;page.on('request',r=>{if(r.method()==='POST'&&r.url().endsWith('/api/jobs'))newExports++});
  await saveExact(page,()=>link.click(),'embedded-primary');expect(newExports).toBe(0);
 });
 test('صفحة التنزيل البديلة المستقلة تحتفظ بتنزيل يدوي حقيقي للملف',async({page})=>{
  await page.goto('/api/jobs/'+fixture.job+'/open?workspace='+fixture.workspace);const link=page.getByTestId('direct-mp4-download');
  await expect(link).not.toHaveAttribute('target');await expect(link).toHaveAttribute('download','');
  await saveExact(page,()=>link.click(),'standalone-fallback');
 });
 test('يبقى مسار التنزيل السابق متاحًا إذا سُمح بالتنزيل ومنعت التبويبات',async({page})=>{
  const {app}=await open(page,'allow-scripts allow-same-origin allow-downloads');
  const direct=app.getByTestId('download-within-frame');
  await expect(direct).toHaveAttribute('download','Ayat_112_1-4.mp4');await expect(direct).not.toHaveAttribute('target');
  await saveExact(page,()=>direct.click(),'downloads-allowed-popups-forbidden-fallback');
 });
 test('صفحة البدء التلقائي لا تطلب تنزيلًا عندما تُحمّل داخل الإطار نفسه',async({page})=>{
  let fileRequests=0;page.on('request',r=>{if(r.url().includes('/file?workspace='))fileRequests++});
  const pending=nextDownload(page,1800).catch(()=>null);
  await page.goto(parentUrl(escapes,'/api/jobs/'+fixture.job+'/open?start=1&workspace='+fixture.workspace));
  await expect(page.frameLocator('iframe').getByTestId('direct-mp4-download')).toBeVisible();
  expect(await pending).toBeNull();expect(fileRequests).toBe(0);expect(page.context().pages()).toHaveLength(1);
  evidence.push({label:'auto-page-inside-frame',download_saved:false,no_auto_download_attempted:true,no_popup_attempted:true,top_level_guard_respected:true});
 });
 test('حظر فتح التبويبات من المنصة لا يتم تجاوزه ولا يُعلن حفظ وهمي',async({page})=>{
  const blocked:string[]=[];page.on('console',m=>{if(/allow-popups|Blocked opening/i.test(m.text()))blocked.push(m.text())});
  const {app,link}=await open(page,'allow-scripts allow-same-origin');
  const pending=nextDownload(page,2000).catch(()=>null);await link.click();expect(await pending).toBeNull();
  expect(page.context().pages()).toHaveLength(1);await expect(app.getByTestId('embedded-download-warning')).toContainText('لا يستطيع التطبيق تجاوز');
  await expect(app.locator('.toast')).toHaveCount(0);
  evidence.push({label:'parent-forbids-popups',download_saved:false,blocked_as_expected:true,sandbox_respected:true,no_fake_success:true,browser_policy_message:blocked[0]||null});
 });
 test('السماح بتبويب مع إبقاء sandbox عليه لا يكفي لإتاحة التنزيل',async({page})=>{
  const {app,link}=await open(page,'allow-scripts allow-same-origin allow-popups');
  const pending=nextDownload(page,2500).catch(()=>null);await link.click();expect(await pending).toBeNull();
  await expect(app.getByTestId('embedded-download-warning')).toBeVisible();
  evidence.push({label:'popup-inherits-no-download-sandbox',download_saved:false,blocked_as_expected:true,sandbox_respected:true});
 });
});
