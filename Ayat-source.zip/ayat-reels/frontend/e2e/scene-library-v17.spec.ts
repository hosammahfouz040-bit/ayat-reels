import {test,expect} from '@playwright/test';
import {readFile,writeFile,mkdir,rename,stat} from 'node:fs/promises';
import {homedir} from 'node:os';
import {createHash} from 'node:crypto';
const CAPS='reciters-v13,warsh,publication-v1,visual-fx-v1,scene-library-v17,publisher-timing-v1';
const proof:any[]=[];const jobs:any[]=[];const cache=homedir()+'/.cache/ayat-library-v17/browser';
const sha=(data:Buffer)=>createHash('sha256').update(data).digest('hex');
const headers=(ws:string)=>({'X-Workspace-Id':ws,'X-Ayat-Capabilities':CAPS});
async function draft(page:any){return page.evaluate(()=>JSON.parse(localStorage.getItem('ayat.draft')||'{}'))}
async function workspace(page:any){return page.evaluate(()=>localStorage.getItem('ayat.workspace'))}
async function history(page:any,ws:string){return (await page.request.get('/api/scenes/history',{headers:headers(ws)})).json()}
async function complete(page:any,id:string,ws:string){let result:any;await expect.poll(async()=>{result=await(await page.request.get('/api/jobs/'+id,{headers:headers(ws)})).json();return result.state},{timeout:150000,intervals:[500,900,1300]}).toBe('completed');return result}
function track(job:any,ws:string){jobs.push({job:job.id,project:job.project_id,workspace:ws,temporary_assistant_qa_only:true})}
test.beforeAll(async()=>{await mkdir(cache,{recursive:true})});
test.afterAll(async()=>{const runId=process.env.AYAT_QA_RUN||'v17';let before:any={};try{const previous=JSON.parse(await readFile('../tests/scene-library-ui-v17.json','utf8'));if(previous.run_id===runId)before=previous}catch{}const allJobs=[...(before.jobs||[]),...jobs].filter((j,i,a)=>a.findIndex(x=>x.job===j.job)===i);await writeFile('../tests/scene-library-ui-v17.json',JSON.stringify({version:'1.7.0',run_id:runId,physical_android_tested:false,real_arena_download_issue_resolved:false,jobs:allJobs,proofs:[...(before.proofs||[]),...proof]},null,2))});

test('٧٢ مشهدًا: الملصقات مرفقة والتنزيل البارد حقيقي ولا يستهلك سجل الريلز',async({page})=>{
 const catalog=await(await page.request.get('/api/catalog',{headers:{'X-Ayat-Capabilities':CAPS}})).json();expect(catalog.scenes).toHaveLength(72);expect(catalog.reciters).toHaveLength(54);expect(catalog.templates).toHaveLength(80);
 const scene=catalog.scenes.find((s:any)=>s.id==='v17_falls_spray');const dir='../backend/runtime/.cache/scene-library-v17';const hold=cache+'/cold-start';await mkdir(hold,{recursive:true});
 for(const suffix of ['.mp4','.json']){try{await rename(dir+'/'+scene.id+suffix,hold+'/'+scene.id+suffix)}catch(e:any){if(e.code!=='ENOENT')throw e}}
 const original=dir+'/sources/'+scene.remote_source.sha256+'.media';try{await rename(original,hold+'/'+scene.remote_source.sha256+'.media')}catch(e:any){if(e.code!=='ENOENT')throw e}
 await expect(stat(original)).rejects.toThrow();expect((await page.request.get('/api/media/'+scene.id+'.mp4')).status()).toBe(409);
 await page.goto('/#scenes');await expect(page.locator('.scene-card')).toHaveCount(72);const ws=await workspace(page);expect((await history(page,ws)).completed_clips).toBe(0);
 await page.getByRole('button',{name:'جديد · عند الطلب',exact:true}).click();await expect(page.locator('.scene-card')).toHaveCount(24);const card=page.getByTestId('scene-card-'+scene.id);await card.scrollIntoViewIfNeeded();await expect(card).toHaveAttribute('data-asset-state','not_downloaded');await expect(card.locator('img')).toHaveJSProperty('complete',true);
 await page.getByRole('button',{name:'معاينة مشهد '+scene.name,exact:true}).click();await expect(card).toHaveAttribute('data-asset-state','ready',{timeout:90000});await expect.poll(()=>card.locator('video').evaluate((v:HTMLVideoElement)=>v.currentTime)).toBeGreaterThan(.3);
 const bytes=await readFile(original);expect(bytes.length).toBe(scene.remote_source.bytes);expect(sha(bytes)).toBe(scene.remote_source.sha256);const receipt=JSON.parse(await readFile(dir+'/'+scene.id+'.json','utf8'));expect(receipt).toMatchObject({width:720,height:1280,muted:true,full_decode_exit:0,source_sha256:scene.remote_source.sha256});
 expect((await history(page,ws)).completed_clips).toBe(0);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
 proof.push({case:'real-cold-download-and-moving-preview',scene:scene.id,source_bytes:bytes.length,source_sha256:sha(bytes),receipt_sha256:receipt.sha256,preview_did_not_consume_history:true,actual_network_source_absent_before_request:true});await page.screenshot({path:'../tests/library-mobile-v17.jpg',fullPage:true});
});

test('فشل شبكة مضبوط يظهر بوضوح ثم إعادة محاولة تعيد فيديو حقيقيًا',async({page})=>{
 await page.goto('/#scenes');await page.getByRole('button',{name:'جديد · عند الطلب',exact:true}).click();const id='v17_pine_mist';const card=page.getByTestId('scene-card-'+id);
 await page.route('**/api/scenes/'+id+'/prepare',async route=>{await route.fulfill({status:503,contentType:'application/json',body:JSON.stringify({error:'انقطاع تجريبي مضبوط لاختبار إعادة المحاولة',code:'QA_CONTROLLED_FAILURE'})})},{times:1});
 await card.getByRole('button',{name:/معاينة مشهد/}).click();await expect(card).toHaveAttribute('data-asset-state','failed');await expect(card.locator('.scene-load-error')).toContainText('انقطاع تجريبي');expect(await card.locator('video').count()).toBe(0);
 await card.getByRole('button',{name:/معاينة مشهد/}).click();await expect(card).toHaveAttribute('data-asset-state','ready');await expect.poll(()=>card.locator('video').evaluate((v:HTMLVideoElement)=>v.currentTime)).toBeGreaterThan(.3);
 proof.push({case:'explicit-controlled-503-then-real-retry',network_failure_was_test_injection:true,real_video_recovered:true});
});

test('عدة مشاهد جديدة وقارئ جديد إلى MP4 حقيقي؛ سجل النجاح والتزامن والتصفير دون حذف',async({page})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));const catalog=await(await page.request.get('/api/catalog',{headers:{'X-Ayat-Capabilities':CAPS}})).json();
 await page.goto('/#scenes');await expect(page.locator('.scene-card')).toHaveCount(72);
 for(const id of ['v17_pink_blossom','v17_pacific_sunset','v17_deer_falls']){const scene=catalog.scenes.find((s:any)=>s.id===id);await page.getByRole('button',{name:'اختيار مشهد '+scene.name,exact:true}).click()}
 for(const id of ['mihrab','garden','orbit']){const scene=catalog.scenes.find((s:any)=>s.id===id);await page.getByRole('button',{name:'اختيار مشهد '+scene.name,exact:true}).click()}
 await page.getByRole('button',{name:'ترتيب المشاهد',exact:true}).click();await page.locator('.editor-tabs').getByRole('button',{name:'المشاهد',exact:true}).click();await expect(page.locator('.clip-card')).toHaveCount(3);await expect(page.getByLabel('قص نهاية المشهد 1',{exact:true})).toHaveValue('3.4');await page.getByLabel('قص بداية المشهد 1',{exact:true}).fill('0.2');await page.getByLabel('قص نهاية المشهد 1',{exact:true}).fill('3.1');
 await page.locator('.editor-tabs').getByRole('button',{name:'التلاوة',exact:true}).click();await page.getByLabel('القارئ',{exact:true}).selectOption('raad_kurdi');await page.getByLabel('السورة',{exact:true}).selectOption('112');await page.getByLabel('من الآية',{exact:true}).fill('1');await page.getByLabel('إلى الآية',{exact:true}).fill('4');
 await page.getByTestId('prepare-audio').click();await expect(page.getByRole('button',{name:'تشغيل التلاوة',exact:true})).toBeVisible();await page.getByRole('button',{name:'تشغيل التلاوة',exact:true}).click();await page.waitForFunction(()=>{const a=document.querySelector('audio');return !!a&&!a.paused&&a.currentTime>.6&&a.readyState>=3});await page.getByRole('button',{name:'إيقاف التلاوة',exact:true}).click();
 await page.locator('.editor-tabs').getByRole('button',{name:'التصدير',exact:true}).click();await page.getByLabel('اسم المشروع',{exact:true}).fill('QA v17 new-scenes multi-scene real export');
 const pending=page.waitForResponse(r=>r.url().endsWith('/api/jobs')&&r.request().method()==='POST');await page.getByTestId('export-editor').click();const response=await pending;expect(response.ok()).toBeTruthy();const job=await response.json();const ws=await workspace(page);track(job,ws);
 await expect(page.getByTestId('download-mp4')).toBeVisible({timeout:150000});await expect(page.getByTestId('publication-panel')).toBeVisible();const download=page.waitForEvent('download');await page.getByTestId('download-mp4').click();const file=await download;await file.saveAs(cache+'/new-scenes-real-export.mp4');expect(await file.failure()).toBeNull();
 const audit=await(await page.request.get('/api/jobs/'+job.id+'/audit?workspace='+ws)).json();expect(audit.all_cues_match_source).toBeTruthy();expect(audit.config.reciter).toBe('raad_kurdi');expect(audit.result.timeline.clips).toHaveLength(3);expect(audit.visual_sources.every((s:any)=>s.availability==='on-demand'&&s.kind==='real-footage')).toBeTruthy();expect(audit.result.visual_attribution_burned).toBeTruthy();expect(audit.config.clips[0].source_in).toBe(.2);expect(audit.config.clips[0].source_out).toBe(3.1);
 const binary=await readFile(cache+'/new-scenes-real-export.mp4');const first=await history(page,ws);expect(first.completed_clips).toBe(1);expect(first.unique_scenes).toBe(3);await writeFile('../tests/library-real-export-audit-v17.json',JSON.stringify(audit,null,2));
 proof.push({case:'real-mobile-ui-new-reader-multiple-new-sources-export',job:job.id,workspace:ws,project:job.project_id,bytes:binary.length,sha256:sha(binary),source_quran_exact:true,reciter:'raad_kurdi',duration:audit.result.duration,canonical_file:'backend/runtime/exports/'+job.id+'/result.mp4',temporary_assistant_qa_only:true});
 // Real concurrent one-click requests: serialized selection plus pending reservations.
 const config={...(await draft(page)),title:'QA v17 concurrent history',surah:112,from_ayah:2,to_ayah:2,reciter:'idrees_abkar',narration:'hafs',mood:'طبيعة',quality:'draft',timings:null,audio_trim_start:0,audio_trim_end:null};
 const requests=await Promise.all([1,2].map(n=>page.request.post('/api/jobs',{headers:headers(ws),data:{config:{...config,title:config.title+' '+n},one_click:true}})));const concurrent=await Promise.all(requests.map(async r=>{expect(r.ok()).toBeTruthy();const j=await r.json();track(j,ws);return j}));
 const a=concurrent[0].config.clips.map((c:any)=>c.scene_id),b=concurrent[1].config.clips.map((c:any)=>c.scene_id);expect(a.filter((id:string)=>b.includes(id))).toHaveLength(0);expect([...a,...b].filter(id=>job.config.clips.some((c:any)=>c.scene_id===id))).toHaveLength(0);
 for(const j of concurrent)await complete(page,j.id,ws);const used=await history(page,ws);expect(used.completed_clips).toBe(3);expect(used.unique_scenes).toBe(9);
 await page.getByRole('button',{name:'إغلاق',exact:true}).click();await page.locator('.bottom-nav').getByRole('button',{name:'المشاهد',exact:true}).click();await expect(page.getByTestId('scene-history-counts')).toContainText('٣');
 const projectsBefore=await(await page.request.get('/api/projects',{headers:headers(ws)})).json();const projectIds=projectsBefore.map((p:any)=>p.id).sort();
 await page.getByTestId('reset-scene-history').click();const dialog=page.getByRole('dialog',{name:'تأكيد تصفير سجل المشاهد'});await expect(dialog).toBeVisible();await expect(dialog).toContainText('لن تُحذف');await page.keyboard.press('Escape');await expect(dialog).not.toBeVisible();expect((await history(page,ws)).completed_clips).toBe(3);
 await page.getByTestId('reset-scene-history').click();await page.getByTestId('confirm-scene-history-reset').click();await expect(dialog).not.toBeVisible();const reset=await history(page,ws);expect(reset.epoch).toBe(used.epoch+1);expect(reset.completed_clips).toBe(0);expect(reset.unique_scenes).toBe(0);const projectsAfter=await(await page.request.get('/api/projects',{headers:headers(ws)})).json();expect(projectsAfter.map((p:any)=>p.id).sort()).toEqual(projectIds);
 const afterFile=await page.request.get('/api/jobs/'+job.id+'/file?workspace='+ws);expect(afterFile.ok()).toBeTruthy();expect(sha(await afterFile.body())).toBe(sha(binary));expect(errors).toEqual([]);
 proof.push({case:'concurrent-success-history-and-nondestructive-ui-reset',workspace:ws,jobs:concurrent.map(j=>j.id),disjoint_scene_ids:[a,b],successful_reels_before:3,unique_scenes_before:9,epoch_before:used.epoch,epoch_after:reset.epoch,projects_unchanged:true,real_mp4_sha256_unchanged_after_reset:true});await page.screenshot({path:'../tests/history-reset-mobile-v17.jpg',fullPage:true});
});

test('إلغاء تصدير فعلي لا يستهلك مشاهد؛ لا نجاح أو ملف MP4 وهمي',async({page})=>{
 await page.goto('/#create');await page.getByLabel('القارئ',{exact:true}).selectOption('hassan_saleh');await page.locator('.editor-tabs').getByRole('button',{name:'التصدير',exact:true}).click();await page.getByLabel('اسم المشروع',{exact:true}).fill('QA v17 real cancel history');await page.getByRole('button',{name:/فائقة/}).click();
 const pending=page.waitForResponse(r=>r.url().endsWith('/api/jobs')&&r.request().method()==='POST');await page.getByTestId('export-editor').click();const r=await pending;expect(r.ok()).toBeTruthy();const job=await r.json(),ws=await workspace(page);track(job,ws);await page.getByRole('button',{name:'إيقاف التصدير',exact:true}).click();await expect(page.getByTestId('retry-export')).toBeVisible();expect((await history(page,ws)).completed_clips).toBe(0);expect((await page.request.get('/api/jobs/'+job.id+'/file?workspace='+ws)).status()).toBe(409);proof.push({case:'real-queued-or-running-job-cancel',job:job.id,workspace:ws,no_successful_history:true,no_downloadable_partial_mp4:true});
});

test('دون API: النص والخلفيات القديمة تعمل والإضافات لا تتظاهر بالعمل أو النجاح',async({page})=>{
 await page.route('**/api/**',route=>route.abort('internetdisconnected'));await page.goto('/#scenes');await expect(page.locator('.scene-card')).toHaveCount(72);await expect(page.getByTestId('scene-history-panel')).toContainText('يحتاج الاتصال');
 const card=page.getByTestId('scene-card-garden');await card.getByRole('button',{name:/معاينة مشهد/}).click();await expect.poll(()=>card.locator('video').evaluate((v:HTMLVideoElement)=>v.currentTime)).toBeGreaterThan(.3);
 await page.getByRole('button',{name:'جديد · عند الطلب',exact:true}).click();const remote=page.getByTestId('scene-card-v17_pine_mist');await remote.getByRole('button',{name:/معاينة مشهد/}).click();await expect(remote).toHaveAttribute('data-asset-state','failed');expect(await remote.locator('video').count()).toBe(0);await expect(remote.locator('.scene-load-error')).toContainText('تعذر الاتصال');proof.push({case:'offline-old-assets-work-new-assets-honest-network-error',bundled_moving_preview:true,remote_fake_playback:false});
});
