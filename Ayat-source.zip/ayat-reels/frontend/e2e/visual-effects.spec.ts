import{test,expect,type Page}from'@playwright/test';
import{writeFile,readFile,mkdir}from'node:fs/promises';import{createHash}from'node:crypto';import{homedir}from'node:os';
import{cameraValues,defaultEffects,fxEnvelope,verseVisual,transitionSeconds}from'../src/effects';
const proofRows:any[]=[];
test.afterAll(async()=>{if(proofRows.length)await writeFile('../tests/effects-ui-real-export-v17.json',JSON.stringify({version:'1.7.0',proofs:proofRows,physical_android_tested:false,real_arena_download_issue_resolved:false},null,2))});
async function fxTab(page:Page){await page.locator('.editor-tabs').getByRole('button',{name:'المؤثرات',exact:true}).click();await expect(page.getByTestId('effects-editor')).toBeVisible()}
async function draft(page:Page){return await page.evaluate(()=>JSON.parse(localStorage.getItem('ayat.draft')||'{}'))}
async function frameExists(page:Page){await page.waitForFunction(()=>{const c=document.querySelector('[data-testid="scene-effects-canvas"]') as HTMLCanvasElement|null;if(!c)return false;const data=c.getContext('2d')!.getImageData(0,0,c.width,c.height).data;let changed=0;for(let i=0;i<data.length;i+=800)if(data[i]+data[i+1]+data[i+2]>10)changed++;return changed>20})}

test('المكتبة فُحصت: الانتقالات القديمة باقية والجديد مضبوط بلا تكديس',async({page,context})=>{
 const c=await(await context.request.get('/api/catalog')).json();expect(c.app_version).toBe('1.7.3');expect(c.effects.verse).toHaveLength(5);expect(c.effects.scene).toHaveLength(6);expect(c.effects.camera).toHaveLength(4);expect(c.effects.transitions.filter((x:any)=>x.existing).map((x:any)=>x.id)).toEqual(['cut','fade','wipeleft','slideup']);
 await page.goto('/#create');await fxTab(page);await expect(page.getByTestId('fx-word-timing-warning')).toContainText('ليسا مزامنة لفظية');
 await page.getByTestId('fx-scene-rain').click();await expect(page.getByTestId('fx-scene-rain')).toHaveAttribute('aria-pressed','true');await frameExists(page);await expect.poll(()=>page.getByTestId('video-preview').getAttribute('data-effects-time')).not.toBe('0.000');
 await page.getByTestId('fx-scene-fog').click();await expect(page.getByTestId('fx-scene-rain')).toHaveAttribute('aria-pressed','false');await expect(page.getByTestId('fx-scene-fog')).toHaveAttribute('aria-pressed','true');await expect.poll(async()=>(await draft(page)).effects.scene.kind).toBe('fog');expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
});

test('كل مؤثر جوي وكاميرا يعاين على فيديو فعلي، لا بطاقة شكلية',async({page})=>{
 await page.goto('/#create');await fxTab(page);
 for(const kind of ['fog','rain','sunrays','dust','stars','bloom']){await page.getByTestId('fx-scene-'+kind).click();await frameExists(page);await expect.poll(async()=>(await draft(page)).effects.scene.kind).toBe(kind);await expect(page.getByTestId('video-preview')).toHaveAttribute('data-effects-preview','playing')}
 for(const kind of ['zoom_in','zoom_out','pan','depth']){await page.getByTestId('fx-camera-'+kind).click();await frameExists(page);await expect.poll(async()=>(await draft(page)).effects.camera.kind).toBe(kind)}
 await page.getByTestId('effects-preview-toggle').click();await expect(page.getByTestId('video-preview')).toHaveAttribute('data-effects-preview','paused');await page.getByTestId('effects-preview-toggle').click();await expect(page.getByTestId('video-preview')).toHaveAttribute('data-effects-preview','playing');
});

test('كتابة وإبراز الكلمات مع بقاء نص القرآن حرفيًا وزمن لظهوره كاملًا',async({page,context})=>{
 const q=await(await context.request.get('/quran.json')).json();await page.goto('/#create');await fxTab(page);await page.getByTestId('fx-verse-reveal').click();
 await expect(page.getByTestId('preview-verse')).toHaveText(q.verses['112:1']);await expect(page.locator('[data-word-index]')).toHaveCount(4);
 await page.waitForFunction(()=>Array.from(document.querySelectorAll('[data-word-index]')).every(e=>Number(getComputedStyle(e).opacity)>.99));
 await page.getByTestId('fx-verse-highlight').click();await expect(page.getByTestId('preview-verse')).toHaveText(q.verses['112:1']);await expect.poll(async()=>(await draft(page)).effects.verse.kind).toBe('highlight');
 for(const kind of ['fade','glow','verse_switch']){await page.getByTestId('fx-verse-'+kind).click();await expect.poll(async()=>(await draft(page)).effects.verse.kind).toBe(kind)}
});

test('التشغيل والشدة والمدة محفوظة، والإيقاف يعيد مسار بلا مؤثر',async({page})=>{
 await page.goto('/#create');await fxTab(page);await page.getByTestId('fx-scene-rain').click();const slider=page.getByLabel('شدة مؤثر scene',{exact:true});await slider.focus();await slider.press('Home');for(let i=0;i<4;i++)await slider.press('ArrowLeft');
 await page.getByLabel('طوال scene',{exact:true}).uncheck();await page.getByLabel('مدة مؤثر scene',{exact:true}).fill('2');await expect.poll(async()=>(await draft(page)).effects.scene).toMatchObject({enabled:true,kind:'rain',intensity:.2,duration:2});await page.getByLabel('مدة مؤثر scene',{exact:true}).fill('١٫٦');await expect.poll(async()=>(await draft(page)).effects.scene.duration).toBe(1.6);await page.getByLabel('مدة مؤثر scene',{exact:true}).fill('2');
 const save=page.waitForResponse(r=>r.request().method()==='POST'&&r.url().endsWith('/api/projects'));await page.getByTestId('save-project').click();expect((await save).status()).toBe(200);
 await page.reload();await fxTab(page);expect((await draft(page)).effects.scene.duration).toBe(2);await page.getByLabel('تشغيل مؤثر scene',{exact:true}).uncheck();await expect(page.getByTestId('scene-effects-canvas')).toHaveCount(0);
 await page.getByTestId('fx-verse-glow').click();await page.getByTestId('fx-camera-pan').click();await page.getByTestId('disable-all-effects').click();await expect.poll(async()=>Object.values((await draft(page)).effects).every((x:any)=>x.enabled===false)).toBeTruthy();await expect.poll(async()=>(await draft(page)).clips.every((x:any)=>x.transition_enabled===false)).toBeTruthy();await expect(page.getByTestId('scene-effects-canvas')).toHaveCount(0);
});

test('مؤثر الإضاءة والضباب يوصلان للانتقال مع مدة وشدة وإيقاف حقيقي',async({page})=>{
 await page.goto('/#create');await fxTab(page);await page.getByTestId('fx-transition-light').click();let c=await draft(page);await expect.poll(async()=>(await draft(page)).clips.slice(0,-1).every((x:any)=>x.transition==='light')).toBeTruthy();await frameExists(page);
 await page.getByLabel('مدة انتقال المؤثرات',{exact:true}).fill('1');await page.getByLabel('شدة الانتقال',{exact:true}).focus();await page.getByLabel('شدة الانتقال',{exact:true}).press('Home');await page.getByLabel('شدة الانتقال',{exact:true}).press('ArrowLeft');c=await draft(page);await expect.poll(async()=>(await draft(page)).clips[0].transition_intensity).toBe(.05);
 await page.getByTestId('fx-transition-mist').click();await page.getByLabel('تشغيل الانتقال',{exact:true}).uncheck();c=await draft(page);await expect.poll(async()=>(await draft(page)).clips.slice(0,-1).every((x:any)=>x.transition==='mist'&&x.transition_enabled===false)).toBeTruthy();
});

test('ساعات المعاينة محدودة وهادئة وتطابق قواعد التصدير',()=>{
 const f=defaultEffects();expect(cameraValues(f.camera,0,10)).toEqual({zoom:1,x:.5,y:.5});f.camera={enabled:true,kind:'zoom_in',intensity:1,duration:2};expect(cameraValues(f.camera,2,10)).toEqual(cameraValues(f.camera,9,10));expect(cameraValues(f.camera,2,10).zoom).toBeCloseTo(1.08);expect(fxEnvelope(3,2,10)).toBe(0);expect(verseVisual({enabled:true,kind:'reveal',intensity:1,duration:8},1.5,2).progress).toBe(1);
 expect(transitionSeconds({id:'unit',scene_id:'orbit',source_in:0,source_out:6,duration:6,transition:'fade',transition_duration:1,transition_intensity:.4},2)).toBe(.4);
});

test('من الواجهة إلى MP4 فعلي: النص والمطر والكاميرا والإضاءة تظهر في الملف النهائي',async({page})=>{
 await page.goto('/#create');await page.getByLabel('القارئ',{exact:true}).selectOption('mossad');await page.getByLabel('من الآية',{exact:true}).fill('2');await page.getByLabel('إلى الآية',{exact:true}).fill('2');await page.getByTestId('prepare-audio').click();await expect(page.getByRole('button',{name:'تشغيل التلاوة',exact:true})).toBeVisible();
 await page.locator('.editor-tabs').getByRole('button',{name:'المشاهد',exact:true}).click();await page.getByRole('button',{name:'حذف',exact:true}).first().click();
 await fxTab(page);await page.getByTestId('fx-verse-glow').click();await page.getByTestId('fx-scene-rain').click();await page.getByTestId('fx-camera-zoom_in').click();await page.getByTestId('fx-transition-light').click();await frameExists(page);
 await page.locator('.editor-tabs').getByRole('button',{name:'التصدير',exact:true}).click();await page.getByLabel('اسم المشروع',{exact:true}).fill('QA v17 real effects');await page.getByRole('button',{name:/اقتصادية/}).click();
 const started=page.waitForResponse(r=>r.url().endsWith('/api/jobs')&&r.request().method()==='POST');await page.getByTestId('export-editor').click();const job=await(await started).json();await expect(page.getByTestId('download-mp4')).toBeVisible({timeout:150000});await expect(page.getByTestId('publication-panel')).toBeVisible();
 const event=page.waitForEvent('download');await page.getByTestId('download-mp4').click();const download=await event;const dir=homedir()+'/.cache/ayat-fx-tests';await mkdir(dir,{recursive:true});const file=dir+'/ui-export.mp4';await download.saveAs(file);expect(await download.failure()).toBeNull();const bytes=await readFile(file);const ws=await page.evaluate(()=>localStorage.getItem('ayat.workspace'));const a=await(await page.request.get('/api/jobs/'+job.id+'/audit?workspace='+ws)).json();expect(a.all_cues_match_source).toBeTruthy();expect(a.visual_effects.verse).toMatchObject({enabled:true,kind:'glow'});expect(a.visual_effects.scene).toMatchObject({enabled:true,kind:'rain'});expect(a.visual_effects.camera).toMatchObject({enabled:true,kind:'zoom_in'});expect(a.animated_overlay_stream).toBeTruthy();expect(a.result.timeline.clips[0].transition).toBe('light');expect(a.word_effect_timing).toContain('NOT recitation word alignment');
 await writeFile('../tests/effects-ui-export-audit-v17.json',JSON.stringify(a,null,2));proofRows.push({job:job.id,project:job.project_id,workspace:ws,canonical_file:'backend/runtime/exports/'+job.id+'/result.mp4',bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),duration:a.result.duration,source_sha256:a.quran_source.sha256,text_exact:true,effects_applied:true,post_feature_still_available:true,downloaded_cache_file:file,temporary_assistant_qa_only:true,physical_android_tested:false});
});
