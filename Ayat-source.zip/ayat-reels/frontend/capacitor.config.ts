import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
 appId:'org.ayat.reels', appName:'آيات — ريلز قرآني', webDir:'dist',
 backgroundColor:'#F5F4EF',
 android:{backgroundColor:'#F5F4EF',allowMixedContent:false},
 server:{androidScheme:'https'},
};
export default config;
