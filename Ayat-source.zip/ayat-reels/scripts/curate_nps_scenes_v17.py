"""Make REVIEW DRAFTS from real, downloaded NPS videos; production registration is separate.
Source windows were selected from actual frame inspection and shot-boundary detection.
No generated scenery, repeated photo crops, source audio, or religious-site relabeling.
"""
from pathlib import Path
import sys,json,os,hashlib,subprocess
import numpy as np,imageio_ffmpeg
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'backend'))
import scene_assets
C=Path.home()/'.cache/ayat-library-v17/nps';REV=C/'portrait-review';REV.mkdir(exist_ok=True);FF=imageio_ffmpeg.get_ffmpeg_exe()
rows=json.loads((C/'intake-sources.json').read_text());by={r['id']:r for r in rows}
Y='av_A45A7B7C295C4718B5FAFE30882C291F';R='av_CA91095B989A4762916555D275B2065D'
# id, Arabic label, category, moods, original source, in, duration, x/y crop focus,
# family, lighting, REAL camera description (not an added simulated movement).
SPECS=[
 ('v17_sequoia_light','نور بين السيكويا','غابات',['سكينة','طبيعة','نور'],Y,205.8,9.6,.42,.5,'forest','نهار وضوء جانبي','تصوير متحرك بين الأشجار'),
 ('v17_mirror_lake','مرآة الجبال','بحيرات',['سكينة','طبيعة'],Y,10.4,4.3,.53,.5,'lake','ضوء صباحي بارد','انعكاس وتموّج طبيعي'),
 ('v17_rainbow_mist','قوس في رذاذ الشلال','شلالات',['طبيعة','نور','سكينة'],Y,35.2,5.1,.58,.5,'waterfall','رذاذ مضاء بالشمس','تصوير قريب للماء والرذاذ'),
 ('v17_poppy_meadow','مرج الخشخاش','زهور',['طبيعة','نور'],Y,49.2,5.4,.4,.5,'flowers','شمس ودرجات برتقالية','أزهار تتحرك مع النسيم'),
 ('v17_granite_river','الماء وصخور الجرانيت','مياه',['طبيعة','سكينة'],Y,86,8,.52,.5,'river','نهار صافٍ','جريان ماء مصوّر'),
 ('v17_half_dome','قمة في السماء الزرقاء','جبال',['طبيعة','نور','سكينة'],Y,61.5,6.1,.66,.5,'mountain','نهار وسماء صافية','تصوير هادئ لقمة صخرية'),
 ('v17_alpine_lake','زرقة البحيرة الجبلية','بحيرات',['طبيعة','سكينة','نور'],Y,308.5,7.2,.48,.5,'lake','شمس جبلية','تصوير بحيرة وجبال'),
 ('v17_snowy_river','النهر بين الأغصان البيضاء','ثلوج',['طبيعة','سكينة'],Y,358.5,6.7,.52,.5,'snow','شتاء وضوء ناعم','ماء جارٍ وأغصان ثلجية'),
 ('v17_pink_blossom','نسيم الزهر الوردي','زهور',['طبيعة','نور','سكينة'],Y,370.5,3.4,.47,.5,'flowers','ضوء ربيعي','تصوير قريب لزهر يتحرك'),
 ('v17_snow_peak','قمة رينيير البيضاء','جبال',['سكينة','طبيعة','نور'],R,32,8,.52,.5,'mountain','قمة ثلجية وسحب','حركة سحب مصوّرة'),
 ('v17_pine_mist','الصنوبر في الغيم','غابات',['سكينة','طبيعة'],R,127,9,.5,.5,'forest','ضباب وضوء بارد','ضباب يمر بين الأشجار'),
 ('v17_falling_snow','تساقط الثلج في الغابة','ثلوج',['سكينة','طبيعة'],R,145,9,.48,.5,'snow','شتاء وإضاءة منتشرة','ثلج متساقط مصوّر'),
 ('v17_deer_falls','شلال بين الجروف','شلالات',['سكينة','طبيعة'],'av_ED254BB7155D451F67B12E38646DAE7E',3,9,.5,.5,'waterfall','ظل الصخور','حركة كاميرا نزولًا مع الشلال'),
 ('v17_falls_spray','التقاء الماء والرذاذ','شلالات',['سكينة','طبيعة'],'av_EE9C970E155D451F67DE52612E9E3D2C',.5,8,.5,.5,'waterfall','ضوء ناعم ورذاذ','تصوير قريب لقاعدة الشلال'),
 ('v17_canyon_flight','آفاق الوادي من أعلى','جبال',['طبيعة','نور'],'av_B6D01994155D451F679C4406F71D1006',4,9,.5,.5,'mountain','نهار وطبقات صخرية','تصوير جوي حقيقي'),
 ('v17_canyon_dusk','شفق فوق جروف الوادي','غروب',['سكينة','طبيعة','نور'],'av_C4D62356155D451F671284967DAAF12C',7,9,.52,.5,'sunset','ضوء آخر النهار','تصوير جوي بانسياب'),
 ('v17_water_reflections','ألوان على صفحة الماء','مياه',['سكينة','طبيعة','نور'],'av_E914CCBB155D451F67145502215368AD',5,9,.52,.5,'river','انعكاسات مضيئة','تموّج وانعكاس طبيعيان'),
 ('v17_summer_clouds','عبور السحب','سماء',['طبيعة','نور','سكينة'],'av_86B0B928155D451F6702D6AE1A150C99',5,9,.5,.5,'sky','سحب صيفية','تايم لابس مصوّر للسحب'),
 ('v17_rain_curtain','ستائر المطر فوق الوادي','مطر',['سكينة','طبيعة'],'av_879DBFCD155D451F671CA3725864BF38',7,9,.5,.5,'rain','سماء ممطرة','تايم لابس لعاصفة مطر'),
 ('v17_cloud_sea','بحر الغيم بين الجروف','سماء',['سكينة','طبيعة'],'av_8D90A2EE155D451F672ED23B8A0C1F37',20,9,.5,.5,'sky','سحب بيضاء منخفضة','انقلاب سحابي مصوّر'),
 ('v17_winter_sunrise','إشراق الوادي','شروق',['نور','طبيعة','سكينة'],'av_2C35FFB6155D451F678201C028FFC38A',2,9,.5,.5,'sunrise','شروق شتوي','تايم لابس للضوء على الصخور'),
 ('v17_snow_clouds','حين يقترب الشتاء','سماء',['سكينة','طبيعة'],'av_786E9815155D451F67A0A18E7686211E',53,9,.5,.5,'sky','غيوم وثلج','سحب متحركة وتساقط ثلج'),
 ('v17_pacific_waves','أمواج الساحل الهادئ','بحر',['سكينة','طبيعة'],'av_561323191DD8B71B0B410405E8F135F8',28,9,.5,.5,'sea','نهار وإضاءة ساحلية','أمواج حقيقية على الشاطئ'),
 ('v17_pacific_sunset','ضوء الغروب على الموج','غروب',['نور','طبيعة','سكينة'],'av_561323191DD8B71B0B410405E8F135F8',53,5.8,.35,.5,'sunset','شمس منخفضة وضوء ذهبي','تصوير موج عند الغروب'),
]

def run(args):
 p=subprocess.run([FF,'-hide_banner','-nostdin','-y','-v','error',*args],capture_output=True,timeout=120)
 if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace')[-1200:])
 return p.stdout
out=[]
only=set(sys.argv[1:]);existing={r['id']:r for r in json.loads((C/'proposed-catalog.json').read_text())} if (C/'proposed-catalog.json').exists() else {}
scene_assets.SCENE_MAP.update(existing)
for i,spec in enumerate(SPECS):
 ident,name,category,moods,source_id,start,duration,x,y,family,lighting,camera=spec
 if only and ident not in only:out.append(existing[ident]);continue
 r=by[source_id];assert start+duration<=r['source_duration']-.01,(ident,start,duration,r['source_duration'])
 assert '©' not in r['author'] and ('NPS' in r['author'] or 'National Park Service' in r['author']),r['author']
 row={'id':ident,'name':name,'category':category,'moods':moods,'duration':duration,'width':720,'height':1280,'fps':24,'kind':'real-footage','subject':'nature','family':family,'lighting':lighting,'camera_motion':camera,'availability':'on-demand','license':'Public-domain-USGov','license_label':'Public domain · NPS','license_url':r['license_url'],'requires_attribution':False,'attribution_requested':True,'author':r['author'],'source_url':r['page'],'source_short_url':r['page'],'source_title':r['title'],'source_credit_title':{'forest':'Forest','lake':'Mountain lake','waterfall':'Waterfall','flowers':'Wildflowers','river':'River','snow':'Winter scene','mountain':'Mountain landscape','sky':'Cloudscape','sunset':'Sunset','sunrise':'Sunrise','rain':'Rainstorm','sea':'Pacific waves'}[family],'source_sha256':r['source_sha256'],'source_start':start,'source_width':r['source_width'],'source_height':r['source_height'],'source_fps':r['source_fps'],'source_duration':r['source_duration'],'remote_source':{'url':r['url'],'sha256':r['source_sha256'],'bytes':r['source_bytes'],'in':start,'publisher':'National Park Service'},'portrait_crop':{'x':x,'y':y},'video':f'/api/media/{ident}.mp4','poster':f'/api/media/{ident}.jpg','adaptation':f'{duration}s excerpt at {start}s, source audio removed, portrait crop, 720x1280 H.264/24fps. Published source is 1920x1080 landscape, NOT native 4K portrait.','curation':'Draft: source frames and shot boundaries examined; portrait composition and genuine motion still need final review.'}
 scene_assets.SCENE_MAP[ident]=row
 folder=scene_assets.CACHE/'sources';folder.mkdir(exist_ok=True);target=folder/(r['source_sha256']+'.media')
 if not target.exists():os.link(r['source_path'],target) # Same verified bytes; never fabricated placeholders.
 video=scene_assets.ensure_scene_asset(ident);poster=REV/(ident+'.jpg');run(['-ss',str(min(1,duration/3)),'-i',str(video),'-frames:v','1','-q:v','3',str(poster)])
 frames=[np.frombuffer(run(['-ss',str(t),'-i',str(video),'-frames:v','1','-vf','scale=90:160','-f','rawvideo','-pix_fmt','rgb24','pipe:1']),np.uint8).astype(float) for t in [min(.7,duration*.2),min(duration-.2,3)]]
 row['motion_difference']=round(float(np.abs(frames[0]-frames[1]).mean()),6);row['sha256']=scene_assets.sha_file(video);row['bytes']=video.stat().st_size;row['poster_sha256']=scene_assets.sha_file(poster);row['review_poster']=str(poster);row['all_frames_fully_decoded']=True;out.append(row)
 (C/'proposed-catalog.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('PORTRAIT_REVIEW_READY',i+1,ident,duration,'motion',row['motion_difference'],flush=True)
for group in range(4):
 entries=out[group*6:group*6+6]
 if only and not any(r['id'] in only for r in entries):continue
 w,h=192,342;sheet=Image.new('RGB',(w*3,(h+25)*len(entries)),(18,25,25));draw=ImageDraw.Draw(sheet)
 for j,row in enumerate(entries):
  for k,pct in enumerate([.12,.5,.86]):
   data=run(['-ss',str(row['duration']*pct),'-i',str(scene_assets.asset_path(row['id'])),'-frames:v','1','-vf',f'scale={w}:{h}','-f','image2pipe','-vcodec','png','pipe:1']);from io import BytesIO
   im=Image.open(BytesIO(data));sheet.paste(im,(k*w,j*(h+25)));draw.text((k*w+5,j*(h+25)+h+4),f'{row["id"].replace("v17_","")} {pct:.0%}',fill='white')
 sheet.save(REV/f'portrait-group-{group+1}.jpg',quality=87)
print('PORTRAIT_DRAFTS_FINISHED',len(out),'below_motion_threshold',[x['id'] for x in out if x['motion_difference']<=.5],flush=True)
