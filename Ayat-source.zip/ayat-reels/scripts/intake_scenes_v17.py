"""Recorded-footage intake. Downloads/cache only; DOES NOT register unreviewed scenes.
Respects Commons 429/Retry-After globally; never rotates hosts, credentials or proxies.
"""
from pathlib import Path
import requests,json,time,hashlib,subprocess,re,html,email.utils,os
import imageio_ffmpeg
FF=imageio_ffmpeg.get_ffmpeg_exe()
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1];C=Path.home()/'.cache/ayat-library-v17';SRC=C/'scene-sources';REVIEW=C/'review';SRC.mkdir(parents=True,exist_ok=True);REVIEW.mkdir(parents=True,exist_ok=True)
# Exact source titles, not search-result images or synthetic camera animations.
TITLES=[
 'File:Sahalie Falls during Winter jm1101.webm','File:Waterfalls Langtang National Park.webm','File:Athirapally falls.webm','File:Diving Vøringsfossen waterfall by drone.webm',
 'File:Mravaltskaro Rainbow Hills.webm','File:El Hornocal, Humahuaca, Jujuy, Argentina.webm','File:Looking Over a Cliff in the Dieng Mountains.webm',
 'File:Aerial Shot Of Sea With Speedboat.webm','File:Northern Shore of Madeira near Porto Moniz 2.webm','File:Plage de Grand-Bassam.mpg',
 'File:October 2021 California rainstorm - Sonoma - 2021-10-24 - Sarah Stierch 15.ogg','File:Heavy rain in Longhua District, Shenzhen (20250424).webm','File:Dest-20220814 170334.ogv',
 'File:Wolken Zeitraffer - Clouds Timelapse 4K HD 24FPS.webm','File:Aurora Borealis over Spruce Woods, Manitoba.webm','File:Southern sky time-lapse.webm',
 'File:Another Sunrise Time Lapse in 4K.webm','File:Sunrise atLake Bled.webm','File:Kobuleti2025sunset.webm','File:Free video clip - Sunset through Palm Tree.webm',
 'File:2022-08-06, Pacific Ocean sunset (Ocean Shores, Washington), 01.webm','File:One Day in Istanbul 4K.webm']
if os.getenv('AYAT_INTAKE_ONLY'):TITLES=[os.environ['AYAT_INTAKE_ONLY']]
def clean(s):return html.unescape(re.sub('<[^>]+>','',s)).strip()
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def checked(cmd):
 r=subprocess.run([FF,*cmd[1:]],capture_output=True)
 if r.returncode:raise RuntimeError(r.stderr.decode(errors='replace')[-2000:])
 return r.stdout
rows=json.loads((C/'discovered-candidates.json').read_text());throttle=C/'commons-cooldown.json'
if throttle.exists():
 wait=max(0,json.loads(throttle.read_text())['resume_at']-time.time())
 if wait:print('RESPECTING_COMMONS_COOLDOWN_SECONDS',int(wait),flush=True);time.sleep(wait)
result=[]
for i,title in enumerate(TITLES):
 row=rows[title];p=row['metadata'];v=p['videoinfo'][0];m=v['extmetadata'];lic=clean(m['LicenseShortName']['value'])
 if lic not in ['CC0','CC BY 2.0','CC BY 3.0','CC BY 4.0']:raise RuntimeError('Not an approved license: '+lic)
 profile=os.getenv('AYAT_SOURCE_PROFILE','original');chosen=next((d for d in v.get('derivatives',[]) if d.get('transcodekey')==profile),None) if profile!='original' else None
 if profile!='original' and not chosen:raise RuntimeError('Requested profile is not published in authoritative metadata.')
 url=(chosen['src'] if chosen else v['url']).split('?')[0];key=hashlib.sha256((title+':'+profile).encode()).hexdigest()[:16];path=SRC/(key+Path(url).suffix);part=path.with_suffix(path.suffix+'.part')
 if not path.exists():
  print('DOWNLOADING',i+1,len(TITLES),title,v['size'],flush=True)
  with requests.get(url,stream=True,timeout=(15,90),headers={'User-Agent':'AyatReels/1.7 recorded-footage license review'}) as response:
   if response.status_code==429:
    retry=response.headers.get('Retry-After','600')
    try:seconds=int(retry)
    except ValueError:
     try:seconds=max(0,email.utils.parsedate_to_datetime(retry).timestamp()-time.time())
     except:seconds=600
    throttle.write_text(json.dumps({'resume_at':time.time()+max(seconds,600),'retry_after':retry,'url':url}));raise RuntimeError('Commons rate limit: stopped all downloads and persisted cooldown, no bypass.')
   response.raise_for_status();written=0
   with part.open('wb') as f:
    for chunk in response.iter_content(1024*1024):
     if not chunk:continue
     f.write(chunk);written+=len(chunk)
     if written>1_100_000_000:raise RuntimeError('Source exceeds intake safety limit.')
   expected=int(response.headers.get('Content-Length',0)) if chosen else v['size']
   if expected and written!=expected:raise RuntimeError(f'Source byte count differs from published response: {written} vs {expected}')
   part.replace(path)
  time.sleep(2)
 reader=imageio_ffmpeg.read_frames(str(path));probe=next(reader);reader.close();video={'width':probe['source_size'][0],'height':probe['source_size'][1]};duration=probe['duration'];frames=[]
 positions=[duration*t for t in [.1,.35,.6,.85]]
 if 'Istanbul' in title:positions=list(range(5,int(duration)-5,10))
 for k,at in enumerate(positions):
  image=REVIEW/f'{key}-{k}.jpg'
  if not image.exists():checked(['ffmpeg','-hide_banner','-loglevel','error','-nostdin','-y','-ss',str(at),'-i',str(path),'-frames:v','1','-vf','scale=480:-2',str(image)])
  frames.append({'time':round(at,2),'image':str(image)})
 cols=4;w,h=480,300;sheet=Image.new('RGB',(w*cols,40+h*((len(frames)+cols-1)//cols)),(18,28,28));draw=ImageDraw.Draw(sheet);draw.text((6,8),f'{i+1}. {title} | {video["width"]}x{video["height"]} | {duration:.2f}s | {lic}',fill='white')
 for j,f in enumerate(frames):
  im=Image.open(f['image']);im.thumbnail((w,h-25));x=(j%cols)*w;y=40+(j//cols)*h;sheet.paste(im,(x,y));draw.text((x+8,y+h-23),f'{f["time"]:.2f}s',fill='white')
 sheet_path=REVIEW/f'{i+1:02}-{key}.jpg';sheet.save(sheet_path,quality=85)
 source={'title':title,'pageid':p['pageid'],'revision':p.get('revisions',[{}])[0],'source_url':v['descriptionurl'],'download_url':url,'source_sha256':sha(path),'source_bytes':path.stat().st_size,'source_width':video['width'],'source_height':video['height'],'source_duration':duration,'license':lic,'license_url':m.get('LicenseUrl',{}).get('value','https://creativecommons.org/publicdomain/zero/1.0/' if lic=='CC0' else ''),'author':clean(m.get('Artist',{}).get('value','')),'description':clean(m.get('ImageDescription',{}).get('value','')),'source_path':str(path),'review_sheet':str(sheet_path),'review_frames':frames,'metadata':p}
 result.append(source);(C/'intake-sources.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('INTAKE_SOURCE_READY',i+1,title,str(sheet_path),flush=True)
print('INTAKE_FINISHED',len(result),flush=True)
