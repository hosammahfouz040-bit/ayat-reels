"""Real isolated server stop/restart/retry test. Never stops the user's live preview.
A separate runtime and port are used; audio is genuine and every claimed result is decoded.
"""
from pathlib import Path
import os,sys,json,time,uuid,signal,subprocess,hashlib
import httpx
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'backend'))
from models import ProjectConfig,SceneClip
from media_engine import FFMPEG
C=Path.home()/'.cache/ayat-connectivity-v172/restart-runtime';C.mkdir(parents=True,exist_ok=True);PORT=8012;URL=f'http://127.0.0.1:{PORT}';env=os.environ.copy();env.update({'AYAT_RUNTIME_DIR':str(C),'AYAT_ENVIRONMENT':'restart-integration-test'});processes=[]

def start(label):
 log=(C/(label+'.log')).open('wb');p=subprocess.Popen([sys.executable,'-m','uvicorn','app:app','--host','0.0.0.0','--port',str(PORT),'--workers','1','--no-access-log'],cwd=R/'backend',env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);processes.append((p,log))
 deadline=time.monotonic()+20
 while time.monotonic()<deadline:
  if p.poll() is not None:raise RuntimeError('Isolated server failed: '+(C/(label+'.log')).read_text()[-1200:])
  try:
   value=httpx.get(URL+'/api/health',timeout=.5)
   if value.status_code==200:return p,value.json()
  except httpx.HTTPError:pass
  time.sleep(.08)
 raise RuntimeError('Isolated server startup timeout')

def child_pids(parent):
 try:return list({int(v) for task in Path(f'/proc/{parent}/task').glob('*/children') for v in task.read_text().split()})
 except OSError:return []

try:
 server,health1=start('before-stop');ws=str(uuid.uuid4());headers={'X-Workspace-Id':ws,'X-Ayat-Capabilities':'warsh,reciters-v13,scene-library-v17,publisher-timing-v1'};request_id=str(uuid.uuid4());cfg=ProjectConfig(title='QA connectivity172 isolated restart',surah=112,from_ayah=1,to_ayah=4,reciter='raad_kurdi',quality='fullhd',clips=[SceneClip(scene_id='orbit')]);latency=[]
 with httpx.Client(base_url=URL,timeout=25) as client:
  response=client.post('/api/jobs',headers={**headers,'X-Ayat-Request-Id':request_id},json={'config':cfg.model_dump()});response.raise_for_status();original=response.json();jid=original['id'];deadline=time.monotonic()+60
  while True:
   now=time.monotonic();status=client.get('/api/jobs/'+jid,headers=headers).json();latency.append((time.monotonic()-now)*1000)
   if status['progress']>=43 and status['state']!='completed' and child_pids(server.pid):break
   if status['state'] in ['completed','failed','canceled']:raise RuntimeError('Did not reach a running export before test stop: '+json.dumps(status,ensure_ascii=False))
   if time.monotonic()>deadline:raise RuntimeError('Actual export did not reach encoding stage')
   time.sleep(.15)
  children=child_pids(server.pid);assert children,'The actual encoder process must exist before the crash test.';server.kill();server.wait(timeout=8)
  for pid in children:
   try:os.kill(pid,signal.SIGKILL)
   except ProcessLookupError:pass
  unreachable=False
  try:client.get('/api/jobs/'+jid,headers=headers,timeout=.6)
  except httpx.HTTPError:unreachable=True
  assert unreachable
 print('ISOLATED_REAL_SERVER_STOPPED_AT',status['state'],status['progress'],flush=True)
 server2,health2=start('after-restart');assert health2['server_instance_id']!=health1['server_instance_id']
 with httpx.Client(base_url=URL,timeout=25) as client:
  restored=client.get('/api/jobs/by-request/'+request_id,headers=headers);restored.raise_for_status();recovered=restored.json();assert recovered['id']==jid and recovered['state']=='interrupted' and recovered['project_id']==original['project_id'];assert client.get('/api/jobs/'+jid+'/file',headers=headers).status_code==409
  retry_key=str(uuid.uuid4());new=client.post('/api/jobs/'+jid+'/retry',headers={**headers,'X-Ayat-Request-Id':retry_key});new.raise_for_status();retried=new.json();assert retried['id']!=jid and retried['project_id']==original['project_id'];deadline=time.monotonic()+100
  while True:
   t=time.monotonic();current=client.get('/api/jobs/'+retried['id'],headers=headers).json();latency.append((time.monotonic()-t)*1000)
   if current['state']=='completed':break
   if current['state'] in ['failed','canceled','interrupted']:raise RuntimeError('Retry did not complete: '+json.dumps(current,ensure_ascii=False))
   if time.monotonic()>deadline:raise RuntimeError('Retry timeout')
   time.sleep(.25)
  response=client.get('/api/jobs/'+retried['id']+'/file',headers=headers);response.raise_for_status();out=C/'actual-restarted-export.mp4';out.write_bytes(response.content);audit=client.get('/api/jobs/'+retried['id']+'/audit',headers=headers).json();assert audit['all_cues_match_source'] and current['file_available'] is True
  usage=client.get('/api/scenes/history',headers=headers).json();assert usage['completed_clips']==1
 decode=subprocess.run([FFMPEG,'-v','error','-i',str(out),'-map','0:v:0','-map','0:a:0','-f','null','-'],capture_output=True);assert decode.returncode==0
 report={'version':'1.7.2','separate_runtime_not_live_user_server':True,'real_server_killed_during_actual_encoding':True,'network_unreachable_during_stop':unreachable,'request_key_survived_restart':True,'old_job_marked_interrupted_not_fake_completed':True,'same_saved_project_retried_successfully':True,'retry_actual_bytes':out.stat().st_size,'retry_actual_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'full_decode_exit':0,'source_quran_exact':True,'layout_version':audit['result']['text_layout_version'],'completed_scene_history_count':usage['completed_clips'],'status_get_max_ms':round(max(latency),2),'status_get_count':len(latency),'phone_hardware_tested':False,'cache_file':str(out)}
 (R/'tests/export-restart-integration-v172.json').write_text(json.dumps(report,indent=2));print('ACTUAL_SERVER_RESTART_RETRY_MP4_PASSED',json.dumps(report),flush=True)
finally:
 for p,log in processes:
  if p.poll() is None:
   p.terminate()
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();p.wait(timeout=5)
  log.close()
