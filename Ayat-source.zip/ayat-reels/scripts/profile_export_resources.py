"""Supervised genuine export/RSS measurement. Guard only our test process, not user jobs.
No synthesized recitation, no false MP4 success, no deletion of existing exports.
"""
from pathlib import Path
import os,sys,time,json,subprocess,signal,hashlib
R=Path(__file__).resolve().parents[1];C=Path.home()/'.cache/ayat-resource-repair';C.mkdir(parents=True,exist_ok=True)

def descendants(pid):
 found={pid};todo=[pid]
 while todo:
  parent=todo.pop()
  try:children={int(x) for task in Path(f'/proc/{parent}/task').glob('*/children') for x in task.read_text().split()}
  except OSError:children=set()
  for child in children-found:found.add(child);todo.append(child)
 return found

def rss(pid):
 try:return int(Path(f'/proc/{pid}/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
 except (OSError,ValueError,IndexError):return 0

if len(sys.argv)>1 and sys.argv[1]=='--worker':
 sys.path.insert(0,str(R/'backend'));import media_engine as e
 import numpy as np
 from models import ProjectConfig
 cfg_path=Path(sys.argv[2]);out=Path(sys.argv[3]);cfg=ProjectConfig.model_validate(json.loads(cfg_path.read_text()));out.mkdir(parents=True,exist_ok=True);e.EXPORTS=out
 p=e.prepare_audio(cfg.surah,cfg.from_ayah,cfg.to_ayah,cfg.reciter)
 def progress(value,message):(out/'last-progress.json').write_text(json.dumps({'progress':value,'stage':message}))
 result=e.render(cfg,p,'case',progress,lambda:False,lambda proc:None);file=out/'case/result.mp4';audit=json.loads((file.parent/'audit.json').read_text());assert audit['all_cues_match_source']
 full=subprocess.run([e.FFMPEG,'-v','error','-i',str(file),'-map','0:v:0','-map','0:a:0','-f','null','-'],capture_output=True);assert full.returncode==0
 # Every page is checked from actual decoded MP4 pixels, including after scene switches.
 from PIL import Image
 from io import BytesIO
 page_scores=[]
 for page in audit['text_composition']['pages']:
  lay=page['layout'];cue={'text':' '.join(v['text'] for v in lay['verse']['lines']),'number':int(page['key'].split(':')[1]),'layout':lay};mask=e.text_graphics(cfg,cue,[v['text'] for v in lay['verse']['lines']],result['width'],result['height'],lay)[2];probe=e.glyph_mask_probe(mask);alpha=np.asarray(mask);selected=alpha>probe['alpha_threshold'];timepoint=page['start']+(page['end']-page['start'])*.65
  png=e.run_checked(['-ss',str(timepoint),'-i',str(file),'-frames:v','1','-f','image2pipe','-vcodec','png','pipe:1']);image=Image.open(BytesIO(png)).convert('RGB');a=np.asarray(image,dtype=float);foreground=np.array(e.rgb(cfg.text_style.color));worst=float(np.linalg.norm(np.maximum(foreground,255-foreground)));tolerance=65+np.maximum(0,245-alpha[selected].astype(float))/255*worst;score=float(np.mean(np.linalg.norm(a[selected]-foreground,axis=1)<tolerance));assert score>.65,(page['key'],score)
  page_scores.append({'key':page['key'],'page':page['page'],'time':timepoint,'actual_quran_pixels_visible_ratio':score})
 (out/'proof.json').write_text(json.dumps({'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'full_decode_exit':full.returncode,'width':result['width'],'height':result['height'],'fps':result['fps'],'duration':result['duration'],'source_quran_exact':True,'layout_version':result.get('text_layout_version'),'render_backend':audit.get('render_backend'),'render_resources':audit.get('render_resources'),'every_page_pixel_checked':True,'page_pixel_scores':page_scores},indent=2));print('ACTUAL_EXPORT_SUCCESS',file,flush=True)
else:
 if len(sys.argv)<3:raise SystemExit('Usage: profile_export_resources.py CONFIG_JSON LABEL [MEMORY_GUARD_MIB]')
 config=Path(sys.argv[1]).resolve();label=sys.argv[2];guard=float(sys.argv[3]) if len(sys.argv)>3 else 1024;out=C/label;out.mkdir(parents=True,exist_ok=True);log=(out/'run.log').open('wb');start=time.monotonic()
 env=os.environ.copy();env['OPENBLAS_NUM_THREADS']='1';p=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--worker',str(config),str(out)],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);peak=0;samples=[];stopped=False
 try:
  while p.poll() is None:
   tree=descendants(p.pid);total=sum(rss(pid) for pid in tree);peak=max(peak,total);samples.append({'seconds':round(time.monotonic()-start,2),'tree_rss_bytes':total,'processes':len(tree)})
   if total>guard*1024**2:
    stopped=True
    for child in tree-{p.pid}:
     try:os.kill(child,signal.SIGKILL)
     except ProcessLookupError:pass
    p.kill();break
   if time.monotonic()-start>360:
    for child in tree:
     try:os.kill(child,signal.SIGKILL)
     except ProcessLookupError:pass
    raise RuntimeError('Our test timeout; no production process stopped.')
   time.sleep(.05)
  rc=p.wait(timeout=15)
 finally:log.close()
 proof=json.loads((out/'proof.json').read_text()) if (out/'proof.json').exists() and rc==0 else None
 report={'label':label,'config':json.loads(config.read_text()),'seconds':round(time.monotonic()-start,2),'exit_code':rc,'test_memory_guard_mib':guard,'stopped_by_test_guard_not_os':stopped,'peak_python_plus_descendant_rss_bytes':peak,'peak_tree_rss_mib':round(peak/1024**2,2),'genuine_mp4_proof':proof,'cache_dir':str(out),'sample_count':len(samples),'samples':samples}
 (R/'tests'/('export-rss-'+label+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['samples','config']},ensure_ascii=False,indent=2));print((out/'run.log').read_text(errors='replace')[-2200:]);raise SystemExit(0 if proof else 2)
