"""Analysis-only alignment helpers. NEVER rewrite canonical Quran text with these.
Derived unchanged from the v1.3 curation implementation.
"""
import re,unicodedata
import numpy as np

def norm(s):
 s=s.split('۝')[0].replace('ٰ','ا').translate(str.maketrans({chr(n):'ا' for n in range(0x870,0x87a)}))
 s=s.translate(str.maketrans({'ٱ':'ا','ى':'ي','ے':'ي','ی':'ي','ؤ':'و','ئ':'ي','أ':'ا','إ':'ا','آ':'ا'}))
 s=''.join(c for c in unicodedata.normalize('NFKD',s) if not unicodedata.category(c).startswith('M'))
 return re.sub('[^ء-ي]','',s)

def distance(a,b):
 row=list(range(len(b)+1))
 for i,x in enumerate(a):
  prev=row;row=[i+1]
  for j,y in enumerate(b):row.append(min(row[-1]+1,prev[j+1]+1,prev[j]+(x!=y)))
 return row[-1]/max(1,len(a),len(b))

def align(ref,obs):
 n=len(ref);m=len(obs);dp=np.full((n+1,m+1),1e8);dp[0,:]=0;back={}
 for i in range(1,n+1):
  for j in range(m+1):
   options=[(dp[i-1,j]+1.25,(i-1,j,1,0,1.0))]
   if j:
    options.append((dp[i,j-1]+.8,(i,j-1,0,1,1.0)))
    for nr,no in [(1,1),(1,2),(2,1)]:
     if i<nr or j<no or (nr==2 and ref[i-1]['key']!=ref[i-2]['key']):continue
     a=''.join(x['normalized'] for x in ref[i-nr:i]);b=''.join(x['normalized'] for x in obs[j-no:j]);d=distance(a,b)
     cost=d*1.6+.04*(nr+no-2)
     options.append((dp[i-nr,j-no]+cost,(i-nr,j-no,nr,no,d)))
   dp[i,j],back[i,j]=min(options,key=lambda x:x[0])
 i=n;j=int(np.argmin(dp[n,:]));matches=[]
 while i:
  pi,pj,nr,no,d=back[i,j]
  if nr and no and d<=.65:matches.append((ref[pi:i],obs[pj:j],d))
  i,j=pi,pj
 return matches
