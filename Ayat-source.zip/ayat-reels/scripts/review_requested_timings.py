"""Development-only timing curation. Exact source texts are used only as references.
Stores offsets and validation metrics, NEVER recognition text in application/source data.
Optional --commit registers accepted pinned recordings; no synthesized recitation/audio.
"""
from pathlib import Path
import json,re,unicodedata,hashlib,argparse,gzip
import numpy as np,soundfile as sf
R=Path(__file__).resolve().parents[1];C=Path.home()/'.cache/ayat-requested-readers'
parser=argparse.ArgumentParser();parser.add_argument('--commit',action='store_true');args=parser.parse_args()
H=json.loads((R/'backend/data/quran.json').read_text())['verses']
W={f"{x['sura_no']}:{x['aya_no']}":x['aya_text_unicode'] for x in json.loads(gzip.decompress((R/'backend/data/quran-warsh-source.json.gz').read_bytes()))}
def norm(s):
 s=s.split('۝')[0].replace('ٰ','ا').translate(str.maketrans({chr(n):'ا' for n in range(0x870,0x87a)}))
 s=s.translate(str.maketrans({'ٱ':'ا','ى':'ي','ے':'ي','ی':'ي','ؤ':'و','ئ':'ي','أ':'ا','إ':'ا','آ':'ا'}))
 s=''.join(c for c in unicodedata.normalize('NFKD',s) if not unicodedata.category(c).startswith('M'))
 return re.sub('[^ء-ي]','',s)
def distance(a,b):
 row=list(range(len(b)+1))
 for i,x in enumerate(a):
  prev=row;row=[i+1]
  for j,y in enumerate(b):row.append(min(row[-1]+1,prev[j+1]+1,prev[j]+(x!=y)))
 return row[-1]/max(1,len(a),len(b))
def align(ref,obs):
 n=len(ref);m=len(obs);dp=np.full((n+1,m+1),1e8);dp[0,:]=0;back={}
 for i in range(1,n+1):
  for j in range(m+1):
   options=[(dp[i-1,j]+1.25,(i-1,j,1,0,1.0))]
   if j:
    options.append((dp[i,j-1]+.8,(i,j-1,0,1,1.0)))
    for nr,no in [(1,1),(1,2),(2,1)]:
     if i<nr or j<no or (nr==2 and ref[i-1]['key']!=ref[i-2]['key']):continue
     a=''.join(x['normalized'] for x in ref[i-nr:i]);b=''.join(x['normalized'] for x in obs[j-no:j]);d=distance(a,b)
     cost=d*1.6+.04*(nr+no-2)
     options.append((dp[i-nr,j-no]+cost,(i-nr,j-no,nr,no,d)))
   dp[i,j],back[i,j]=min(options,key=lambda x:x[0])
 i=n;j=int(np.argmin(dp[n,:]));matches=[]
 while i:
  pi,pj,nr,no,d=back[i,j]
  if nr and no and d<=.65:matches.append((ref[pi:i],obs[pj:j],d))
  i,j=pi,pj
 return matches
accepted={};reports=[]
for p in sorted(C.glob('*-proposed-timing.json')):
 proposal=json.loads(p.read_text());ident=proposal['id'];surah=proposal['surah'];name=f'{ident}-{surah:03}';source=W if proposal['narration']=='warsh' else H
 keys=sorted([k for k in source if k.startswith(str(surah)+':')],key=lambda k:int(k.split(':')[1]));ref=[]
 for key in keys:
  for word in source[key].split():
   n=norm(word)
   if n:ref.append({'key':key,'normalized':n})
 obs=[{**w,'normalized':norm(w['word'])} for w in json.loads((C/(name+'-recognition.json')).read_text())['words'] if norm(w['word'])]
 matches=align(ref,obs);by={k:[] for k in keys}
 for refs,words,d in matches:
  for rr in refs:by[rr['key']].append({'start':min(w['start'] for w in words),'end':max(w['end'] for w in words),'similarity':1-d})
 audio,sr=sf.read(C/(name+'.wav'),dtype='float32');duration=len(audio)/sr
 # Acoustic energy only chooses low-energy points near reference-aligned transitions.
 hop=int(sr*.01);trim=audio[:len(audio)//hop*hop];energy=np.sqrt(np.mean(trim.reshape(-1,hop)**2,axis=1));t=(np.arange(len(energy))+.5)*.01
 def quiet_point(target,low,high):
  indices=np.flatnonzero((t>=max(low,target-.48))&(t<=min(high,target+.48)))
  if not len(indices):return target
  scale=max(float(np.percentile(energy,85)),.001)
  # Favor a low-energy pause close to the aligned transition, never arbitrary equal divisions.
  scores=energy[indices]/scale+np.abs(t[indices]-target)*.12
  return float(t[indices[int(np.argmin(scores))]])
 spans=[];fail=[]
 for k in keys:
  parts=by[k];count=sum(x['key']==k for x in ref);coverage=len(parts)/count;similarity=sum(x['similarity'] for x in parts)/max(1,count)
  if not parts or coverage<.75 or similarity<.65:fail.append({'key':k,'coverage':coverage,'similarity':similarity})
  spans.append({'key':k,'number':int(k.split(':')[1]),'aligned_start':min(x['start'] for x in parts) if parts else None,'aligned_end':max(x['end'] for x in parts) if parts else None,'matched_word_fraction':round(coverage,6),'reference_word_similarity':round(similarity,6)})
 if any(s['aligned_start'] is None for s in spans):
  reports.append({'id':ident,'surah':surah,'accepted':False,'rejected':fail});continue
 boundaries=[]
 for left,right in zip(spans,spans[1:]):
  target=(left['aligned_end']+right['aligned_start'])/2
  low=max(left['aligned_start']+.12,left['aligned_end']-.42);high=min(right['aligned_end']-.12,right['aligned_start']+.42)
  if low>high:fail.append({'crossed_verse_boundary':[left['key'],right['key']]});point=target
  else:point=quiet_point(target,low,high)
  boundaries.append(point)
 first=quiet_point(max(0,spans[0]['aligned_start']-.13),max(0,spans[0]['aligned_start']-.5),spans[0]['aligned_start']+.02)
 if spans[0]['aligned_start']<.3:first=0
 intervals=[]
 for i,s in enumerate(spans):
  start=first if i==0 else boundaries[i-1];end=duration if i==len(spans)-1 else boundaries[i]
  if end-start<.35:fail.append({'short_interval':s['key']})
  intervals.append({'number':s['number'],'start':round(start,4),'end':round(end,4),'reference_word_similarity':s['reference_word_similarity']})
 # Check every actual isolated clip, independently of the whole-track alignment.
 # Fail closed on uncertain recognition; never use its text in the final output.
 isolated=json.loads((C/'isolated-clip-check.json').read_text()) if (C/'isolated-clip-check.json').exists() else []
 checks=[x for x in isolated if x['reciter']==ident and x['surah']==surah]
 minimum_isolated=min((x['isolated_clip_similarity'] for x in checks),default=0)
 if not fail and (len(checks)!=len(keys) or minimum_isolated<.75):
  fail.append({'isolated_clip_confidence_insufficient':minimum_isolated,'checked':len(checks),'expected':len(keys)})
 # Fail closed for uncertain order/coverage; no proportional fallback.
 ok=not fail
 entry={'url':proposal['url'],'sha256':proposal['sha256'],'bytes':proposal['bytes'],'narration':proposal['narration'],'surah':surah,'duration':round(duration,7),'verse_intervals':intervals,'source_page':'https://www.mp3quran.net/ar/aabd-laazyz-shym' if ident=='suhaim' else 'https://way2quran.com/ar/reciters/abdul-rahman-musaad/hafs-an-asim','source_provider':'MP3Quran' if ident=='suhaim' else 'Way2Quran','timing_method':'Pinned original recording; acoustic word-to-official-reference alignment with silence-boundary refinement. Not publisher timings or word-level highlighting; editable and should be reviewed before publication. Recognition output is never used as Quran text.','timing_validation':{'method':'sequential reference-word alignment + near-boundary energy minima','minimum_matched_word_fraction':min(s['matched_word_fraction'] for s in spans),'minimum_reference_word_similarity':min(s['reference_word_similarity'] for s in spans),'automatic_validation_passed':ok,'human_auditory_review_performed':False,'isolated_clip_check_count':len(checks),'minimum_isolated_clip_similarity':minimum_isolated,'all_intervals_nonoverlapping':all(a['end']<=b['start'] for a,b in zip(intervals,intervals[1:])),'all_text_from_canonical_source':True},'full_decode_exit':0}
 reports.append({'id':ident,'surah':surah,'accepted':ok,'rejected':fail,'minimum_reference_similarity':entry['timing_validation']['minimum_reference_word_similarity'],'intervals':intervals,'duration':duration})
 if ok:accepted.setdefault(ident,{})[str(surah)]=entry
 print('TIMING_REVIEW',ident,surah,'ACCEPTED' if ok else 'REJECTED',json.dumps({'failures':fail,'minimum_similarity':entry['timing_validation']['minimum_reference_word_similarity'],'boundaries':[x['end'] for x in intervals]},ensure_ascii=False),flush=True)
(C/'reviewed-recordings.json').write_text(json.dumps(accepted,ensure_ascii=False,indent=2));(C/'timing-review-report.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2))
if args.commit:
 assert all(accepted.get(k) for k in ['mossad','suhaim'])
 (R/'backend/data/curated-recordings.json').write_text(json.dumps(accepted,ensure_ascii=False,indent=2))
 (R/'tests/requested-reciters-timing-validation.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2))
 (R/'tests/requested-reciters-isolated-checks.json').write_text(json.dumps(isolated,indent=2))
 readers=json.loads((R/'backend/data/reciters.json').read_text());readers=[r for r in readers if r['id'] not in ['mossad','suhaim']]
 for ident,name,narration,aliases in [('mossad','عبدالرحمن مسعد','hafs',['عبد الرحمن مسعد','Abdulrahman Mossad']),('suhaim','عبدالعزيز سحيم','warsh',['عبد العزيز سحيم','Abdelaziz Suhaim','Abdelaziz Sheim'])]:
  probes=[{'url':v['url'],'sha256':v['sha256'],'bytes':v['bytes'],'duration':v['duration'],'full_decode_exit':0,'surah':v['surah'],'peak':float(np.max(np.abs(sf.read(C/f"{ident}-{v['surah']:03}.wav",dtype='float32')[0]))),'timing_validation':v['timing_validation']} for v in accepted[ident].values()]
  nar='ورش عن نافع' if narration=='warsh' else 'حفص عن عاصم'
  readers.append({'id':ident,'name':name,'aliases':aliases,'narration':narration,'provider':'curated-surah','detail':nar+' · تلاوات مختارة بمحاذاة صوتية قابلة للمراجعة','source':next(iter(accepted[ident].values()))['source_page'],'verification_samples':probes})
 assert len(readers)==42
 (R/'backend/data/reciters.json').write_text(json.dumps(readers,ensure_ascii=False,indent=2))
 print('REGISTERED_TWO_GENUINE_READERS',[(k,len(v)) for k,v in accepted.items()])
