"""Additive v1.4 curation of genuine reader recordings and explicitly bounded excerpts.
Recognition is development-only and NEVER supplies the Quran text used by the app.
All canonical text/font sources and all existing registered audio intervals stay unchanged.
No proportional timing fallback, lowered confidence threshold, or reader substitution.
"""
from pathlib import Path
from collections import defaultdict
import argparse,hashlib,json,os,subprocess,time,sys
import requests,numpy as np,soundfile as sf,imageio_ffmpeg
from reader_curation_common import norm,align
R=Path(__file__).resolve().parents[1];C=Path.home()/'.cache/ayat-reader-expansion';C.mkdir(parents=True,exist_ok=True)
os.environ.setdefault('HF_HOME',str(C/'hf'))
sys.path.insert(0,str(R/'backend'))
from quran import quran_source
parser=argparse.ArgumentParser();parser.add_argument('--commit',action='store_true');args=parser.parse_args()
TRACKS=json.loads((R/'docs/sources/reader-expansion-1-4.json').read_text())['candidates']
FF=imageio_ffmpeg.get_ffmpeg_exe();MODEL=None
BASELINE=json.loads((R/'docs/sources/requested-reciters-curation.json').read_text())['models'][0]
if not (C/'baseline-recordings.json').exists():
 pinned=json.loads((R/'tests/reader-library-v13-baseline.json').read_text())['recordings']
 current=json.loads((R/'backend/data/curated-recordings.json').read_text())
 previous={rec:{chapter:current[rec][chapter] for chapter in tracks} for rec,tracks in pinned.items()}
 (C/'baseline-recordings.json').write_text(json.dumps(previous,ensure_ascii=False,indent=2))


def sha_file(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()

def recognizer():
 global MODEL
 if MODEL is None:
  from faster_whisper import WhisperModel
  from faster_whisper.utils import download_model
  print('LOADING_PINNED_ACOUSTIC_MODEL',BASELINE['snapshot'],flush=True)
  folder=download_model('small',cache_dir=str(C/'models'),revision=BASELINE['snapshot'])
  assert sha_file(Path(folder)/'model.bin')==BASELINE['sha256'],'Acoustic model changed.'
  MODEL=WhisperModel(folder,device='cpu',compute_type='int8',cpu_threads=2,num_workers=1)
 return MODEL

def transcribe(audio,words=False):
 segments,_=recognizer().transcribe(audio,language='ar',beam_size=5,word_timestamps=words,vad_filter=False,condition_on_previous_text=False,temperature=0)
 if words:return [{'word':w.word,'start':w.start,'end':w.end,'probability':w.probability} for s in segments for w in s.words or []]
 return ' '.join(s.text for s in segments)

def contiguous(numbers,minimum=1):
 groups=[]
 for n in sorted(set(numbers)):
  if groups and n==groups[-1][-1]+1:groups[-1].append(n)
  else:groups.append([n])
 return [g for g in groups if len(g)>=minimum]

def fetch_original(track):
 name=f"{track['reciter']}-{track['surah']:03}";mp3=C/(name+'.mp3');wav=C/(name+'.wav')
 if not mp3.exists():
  for attempt in range(3):
   response=requests.get(track['url'],timeout=75)
   if response.status_code==429 and attempt<2:
    pause=min(30,max(2,int(response.headers.get('Retry-After','5'))));print('SOURCE_RATE_LIMIT_WAIT',name,pause,flush=True);time.sleep(pause);continue
   response.raise_for_status();assert len(response.content)>1000
   mp3.write_bytes(response.content);break
 if not wav.exists():subprocess.run([FF,'-v','error','-y','-i',str(mp3),'-ac','1','-ar','16000','-c:a','pcm_s16le',str(wav)],check=True)
 audio,sr=sf.read(wav,dtype='float32');assert sr==16000 and len(audio)>16000 and np.isfinite(audio).all() and np.max(np.abs(audio))>.001
 return name,mp3,audio,sr


def curate(track):
 from difflib import SequenceMatcher
 name,mp3,audio,sr=fetch_original(track);duration=len(audio)/sr;source=quran_source(track['narration']);surah=track['surah']
 print('ORIGINAL_DECODED',name,round(duration,3),mp3.stat().st_size,flush=True)
 words_path=C/(name+'-words.json')
 if words_path.exists():words=json.loads(words_path.read_text())
 else:words=transcribe(audio,words=True);words_path.write_text(json.dumps(words,ensure_ascii=False,indent=2))
 print('WHOLE_TRACK_ANALYZED',name,len(words),'words; recognition remains scratch-only',flush=True)
 keys=sorted((k for k in source['verses'] if k.startswith(str(surah)+':')),key=lambda k:int(k.split(':')[1]))
 ref=[]
 for key in keys:
  for word in source['verses'][key].split():
   normalized=norm(word)
   if normalized:ref.append({'key':key,'normalized':normalized})
 obs=[{**w,'normalized':norm(w['word'])} for w in words if norm(w['word'])]
 matches=align(ref,obs);parts=defaultdict(list)
 for rr,ww,diff in matches:
  for word in rr:parts[word['key']].append({'start':min(w['start'] for w in ww),'end':max(w['end'] for w in ww),'similarity':1-diff})
 hop=160;frames=audio[:len(audio)//hop*hop].reshape(-1,hop);energy=np.sqrt(np.mean(frames**2,axis=1));times=(np.arange(len(energy))+.5)*.01;scale=max(float(np.percentile(energy,85)),.001)
 def quiet(target,low,high):
  indices=np.flatnonzero((times>=max(low,target-.48))&(times<=min(high,target+.48)))
  if not len(indices):return target
  scores=energy[indices]/scale+np.abs(times[indices]-target)*.12
  return float(times[indices[int(np.argmin(scores))]])
 spans=[];failures=defaultdict(list)
 for key in keys:
  ps=parts[key];count=sum(x['key']==key for x in ref);coverage=len(ps)/max(1,count);similarity=sum(p['similarity'] for p in ps)/max(1,count)
  if not ps or coverage<.75 or similarity<.65:failures[int(key.split(':')[1])].append('insufficient sequential reference-word coverage')
  spans.append({'key':key,'number':int(key.split(':')[1]),'start':min((p['start'] for p in ps),default=None),'end':max((p['end'] for p in ps),default=None),'coverage':round(coverage,6),'similarity':round(similarity,6)})
 edges=[]
 for left,right in zip(spans,spans[1:]):
  if left['end'] is None or right['start'] is None:edges.append(None);continue
  target=(left['end']+right['start'])/2;low=max(left['start']+.12,left['end']-.42);high=min(right['end']-.12,right['start']+.42)
  if low>high:
   failures[left['number']].append('crossed alignment boundary');failures[right['number']].append('crossed alignment boundary');edges.append(None)
  else:edges.append(quiet(target,low,high))
 first=0
 if spans[0]['start'] is None:first=None
 elif spans[0]['start']>=.3:first=quiet(max(0,spans[0]['start']-.13),max(0,spans[0]['start']-.5),spans[0]['start']+.02)
 # Do not append a spoken postlude to the final Quran cue.
 last=duration
 if spans[-1]['end'] is not None:
  tail_words=[w for w in obs if w['start']>=spans[-1]['end']+.15]
  if tail_words or duration-spans[-1]['end']>1.5:
   last=quiet(spans[-1]['end']+.18,spans[-1]['end'],min(duration,spans[-1]['end']+.7))
 intervals={}
 for i,s in enumerate(spans):
  a=first if i==0 else edges[i-1];b=last if i==len(spans)-1 else edges[i]
  if a is None or b is None or b-a<.35 or a<0 or b>duration+.001:
   failures[s['number']].append('unresolved or invalid acoustic interval');continue
  intervals[s['number']]={'number':s['number'],'start':round(a,4),'end':round(b,4),'reference_word_similarity':s['similarity']}
 # Check each actual isolated candidate clip at the SAME >=.75 threshold as v1.3.
 checkpoints=C/(name+'-isolated.json');checks=json.loads(checkpoints.read_text()) if checkpoints.exists() else {}
 for number,v in intervals.items():
  if number in failures:continue
  fingerprint=hashlib.sha256((sha_file(mp3)+json.dumps(v,sort_keys=True)).encode()).hexdigest()
  old=checks.get(str(number))
  if old and old.get('fingerprint')==fingerprint:score=old['similarity']
  else:
   clip=audio[round(v['start']*sr):round(v['end']*sr)]
   recognized=transcribe(clip);reference=source['verses'][f'{surah}:{number}']
   score=SequenceMatcher(None,norm(reference),norm(recognized),autojunk=False).ratio()
   checks[str(number)]={'similarity':round(score,6),'fingerprint':fingerprint,'scratch_recognized':recognized}
   checkpoints.write_text(json.dumps(checks,ensure_ascii=False,indent=2))
  if score<.75:failures[number].append('isolated clip confidence below unchanged .75 threshold')
  print('ISOLATED_CHECK',name,number,round(score,4),flush=True)
 # Be conservative at boundaries: also withhold each neighbor of an uncertain verse.
 unsafe={n for bad in failures for n in [bad-1,bad,bad+1] if 1<=n<=len(keys)}
 groups=contiguous([n for n in intervals if n not in unsafe],minimum=3)
 enabled=[n for group in groups for n in group];held=[n for n in range(1,len(keys)+1) if n not in enabled]
 source_digest=sha_file(mp3)
 validation={'method':'v1.3 sequential reference-word alignment, near-boundary energy minima, isolated-clip checks; uncertain verses AND immediate neighbors withheld; only runs of 3+ enabled','minimum_matched_word_fraction':min((s['coverage'] for s in spans if s['number'] in enabled),default=0),'minimum_reference_word_similarity':min((s['similarity'] for s in spans if s['number'] in enabled),default=0),'minimum_isolated_clip_similarity':min((checks[str(n)]['similarity'] for n in enabled),default=0),'automatic_validation_passed':bool(enabled),'human_auditory_review_performed':False,'isolated_clip_check_count':len(enabled),'source_verse_count':len(keys),'enabled_verse_count':len(enabled),'verified_subset_only':bool(held),'withheld_verse_numbers':held,'all_intervals_nonoverlapping':all(intervals[a]['end']<=intervals[b]['start'] for a,b in zip(enabled,enabled[1:])),'all_text_from_canonical_source':True}
 record={'url':track['url'],'sha256':source_digest,'bytes':mp3.stat().st_size,'narration':track['narration'],'surah':surah,'duration':round(duration,7),'verse_intervals':[intervals[n] for n in enabled],'source_page':track['source_page'],'source_provider':track['source_provider'],'timing_method':'Pinned original recording; reference-based acoustic alignment and isolated-clip validation. Only explicitly listed verified ranges are enabled; not publisher timings or word-level highlighting. Review/edit before publication. Recognition never supplies Quran text.','timing_validation':validation,'full_decode_exit':0}
 report={'reciter':track['reciter'],'surah':surah,'source_url':track['url'],'source_sha256':source_digest,'source_bytes':mp3.stat().st_size,'source_duration':duration,'source_verse_count':len(keys),'enabled_count':len(enabled),'ranges':[{'from_ayah':g[0],'to_ayah':g[-1]} for g in groups],'withheld_verses':held,'failed_checks':dict(failures),'minimum_isolated_similarity_enabled':validation['minimum_isolated_clip_similarity'],'all_enabled_text_from_source_sha256':source['sha256'],'full_decode_exit':0,'peak':float(np.max(np.abs(audio))),'physical_android_tested':False}
 print('TRACK_RESULT',name,json.dumps({k:report[k] for k in ['enabled_count','ranges','withheld_verses','minimum_isolated_similarity_enabled']},ensure_ascii=False),flush=True)
 return record,report

new=defaultdict(dict);reports=[]
for t in TRACKS:
 try:
  record,report=curate(t);reports.append(report)
  if record['verse_intervals']:new[t['reciter']][str(t['surah'])]=record
 except Exception as exc:
  reports.append({'reciter':t['reciter'],'surah':t['surah'],'enabled_count':0,'failed':str(exc),'ranges':[]});print('TRACK_NOT_ENABLED',t['reciter'],t['surah'],str(exc),flush=True)
 (C/'new-recordings.json').write_text(json.dumps(new,ensure_ascii=False,indent=2));(C/'expansion-report.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2))

if args.commit:
 baseline=json.loads((C/'baseline-recordings.json').read_text());existing=json.loads((R/'backend/data/curated-recordings.json').read_text())
 assert all(existing.get(r,{}).get(s)==v for r,tracks in baseline.items() for s,v in tracks.items()),'An existing registered interval changed.'
 assert all(new.get(r) for r in ['mossad','suhaim']),'Do not claim expansion of both unless both have additions.'
 additions=defaultdict(dict)
 for reciter,tracks in new.items():
  for surah,row in tracks.items():
   if surah in existing.get(reciter,{}):
    assert existing[reciter][surah]==row,'Additive expansion must not alter a previously registered recording.'
    continue
   existing.setdefault(reciter,{})[surah]=row;additions[reciter][surah]=row
 if not additions:
  print('ALREADY_REGISTERED_NO_SOURCE_FILES_CHANGED',flush=True);sys.exit(0)
 new=additions
 readers=json.loads((R/'backend/data/reciters.json').read_text())
 for reader in readers:
  if reader['id'] not in new:continue
  for surah,row in new[reader['id']].items():
   peak=next(p['peak'] for p in reports if p['reciter']==reader['id'] and p['surah']==int(surah))
   reader['verification_samples'].append({'url':row['url'],'sha256':row['sha256'],'bytes':row['bytes'],'duration':row['duration'],'full_decode_exit':0,'surah':int(surah),'peak':peak,'timing_validation':row['timing_validation']})
 assert len(readers)==42
 (R/'backend/data/curated-recordings.json').write_text(json.dumps(existing,ensure_ascii=False,indent=2));(R/'backend/data/reciters.json').write_text(json.dumps(readers,ensure_ascii=False,indent=2))
 (R/'tests/reader-expansion-v14.json').write_text(json.dumps({'date':'2026-10-25','strictly_additive':True,'all_previous_6_recordings_unchanged':True,'all_previous_33_intervals_unchanged':True,'new_tracks':sum(len(t) for t in new.values()),'new_intervals':sum(len(v['verse_intervals']) for t in new.values() for v in t.values()),'recognition_used_as_quran_text':False,'human_auditory_review_performed':False,'tracks':reports},ensure_ascii=False,indent=2))
 print('ADDITIVE_COMMIT_COMPLETED',sum(len(t) for t in new.values()),'tracks',flush=True)
else:print('DRY_RUN_COMPLETE_NO_APP_DATA_CHANGED',flush=True)
