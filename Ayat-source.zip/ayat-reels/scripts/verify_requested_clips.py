"""Development-only isolated-verse acoustic checks; never a Quran text source."""
from pathlib import Path
import json,sys,os
from difflib import SequenceMatcher
import numpy as np,soundfile as sf
R=Path(__file__).resolve().parents[1];C=Path.home()/'.cache/ayat-requested-readers'
os.environ.setdefault('HF_HOME',str(C/'hf'));sys.path.insert(0,str(R/'backend'));sys.path.insert(0,str(R/'scripts'))
from quran import quran_source
# Import only the reference normalizer without executing curation/registration again.
import unicodedata,re
def norm(s):
 s=s.split('۝')[0].replace('ٰ','ا').translate(str.maketrans({chr(n):'ا' for n in range(0x870,0x87a)}));s=s.translate(str.maketrans({'ٱ':'ا','ى':'ي','ے':'ي','ی':'ي','ؤ':'و','ئ':'ي','أ':'ا','إ':'ا','آ':'ا'}));s=''.join(c for c in unicodedata.normalize('NFKD',s) if not unicodedata.category(c).startswith('M'));return re.sub('[^ء-ي]','',s)
from faster_whisper import WhisperModel
m=WhisperModel('small',device='cpu',compute_type='int8',cpu_threads=2,num_workers=1,download_root=str(C/'models'))
rows=json.loads((C/'reviewed-recordings.json').read_text());report=[];scratch=[]
for ident,recordings in rows.items():
 for surah,recording in recordings.items():
  audio,sr=sf.read(C/f'{ident}-{int(surah):03}.wav',dtype='float32');source=quran_source(recording['narration'])
  for v in recording['verse_intervals']:
   clip=audio[round(v['start']*sr):round(v['end']*sr)]
   segs,info=m.transcribe(clip,language='ar',beam_size=5,condition_on_previous_text=False,vad_filter=False,temperature=0)
   recognized=' '.join(s.text for s in segs);key=surah+':'+str(v['number']);reference=source['verses'][key]
   score=SequenceMatcher(None,norm(reference),norm(recognized),autojunk=False).ratio()
   row={'reciter':ident,'surah':int(surah),'key':key,'isolated_clip_similarity':round(score,6),'seconds':v['end']-v['start']};report.append(row);scratch.append({**row,'scratch_recognized':recognized})
   print('ISOLATED_AUDIO_CHECK',json.dumps(row),flush=True)
(C/'isolated-clip-check.json').write_text(json.dumps(report,indent=2));(C/'isolated-recognition-scratch.json').write_text(json.dumps(scratch,ensure_ascii=False,indent=2));print('ISOLATED_CHECK_COMPLETED',len(report),flush=True)
