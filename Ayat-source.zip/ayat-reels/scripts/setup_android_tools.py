"""Optional build-environment setup. Downloads stay in excluded .cache, not the project."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import requests,tarfile,zipfile,subprocess,os,json
ROOT=Path.home()/'.cache/ayat-android';ROOT.mkdir(parents=True,exist_ok=True)
urls={
 'jdk.tar.gz':'https://corretto.aws/downloads/latest/amazon-corretto-21-x64-linux-jdk.tar.gz',
 'cmdline.zip':'https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip'}
def download(pair):
 name,url=pair;dest=ROOT/name
 if not dest.exists():
  with requests.get(url,stream=True,timeout=120) as r:
   r.raise_for_status()
   with dest.open('wb') as f:
    for data in r.iter_content(1024*1024):f.write(data)
 print('Downloaded',name,dest.stat().st_size,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(download,urls.items()))
jdks=list(ROOT.glob('amazon-corretto-*'))
if not jdks:
 with tarfile.open(ROOT/'jdk.tar.gz') as tar:tar.extractall(ROOT,filter='data')
 jdks=list(ROOT.glob('amazon-corretto-*'))
java=jdks[0];sdk=ROOT/'sdk';cmd=sdk/'cmdline-tools/latest'
if not cmd.exists():
 temp=ROOT/'unzip';temp.mkdir(exist_ok=True)
 with zipfile.ZipFile(ROOT/'cmdline.zip') as z:z.extractall(temp)
 cmd.parent.mkdir(parents=True,exist_ok=True)
 (temp/'cmdline-tools').rename(cmd)
 for executable in (cmd/'bin').iterdir():executable.chmod(0o755)
env=os.environ.copy();env.update({'JAVA_HOME':str(java),'ANDROID_HOME':str(sdk),'ANDROID_SDK_ROOT':str(sdk),'PATH':str(java/'bin')+':'+env['PATH']})
manager=str(cmd/'bin/sdkmanager')
subprocess.run([manager,'--sdk_root='+str(sdk),'--licenses'],input='y\n'*100,text=True,env=env,check=True)
subprocess.run([manager,'--sdk_root='+str(sdk),'platform-tools','platforms;android-35','build-tools;35.0.0'],env=env,check=True)
(ROOT/'env.json').write_text(json.dumps({'JAVA_HOME':str(java),'ANDROID_HOME':str(sdk)},indent=2))
print('ANDROID_TOOLS_READY',java,sdk,flush=True)
