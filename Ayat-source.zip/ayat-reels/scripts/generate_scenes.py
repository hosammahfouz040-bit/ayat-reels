"""Original, genuinely animated MP4 scene library. All visual assets CC0.
No Quran text is generated or painted into these source clips.
"""
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
import math,json,subprocess,imageio_ffmpeg,hashlib
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'backend/media';OUT.mkdir(parents=True,exist_ok=True)
W,H,FPS,SECONDS=540,960,24,6
X,Y=np.meshgrid(np.linspace(0,1,W,dtype=np.float32),np.linspace(0,1,H,dtype=np.float32))
rng=np.random.default_rng(6226)
particles=rng.random((72,4))
SCENES=[
 ('mihrab','محراب النور','هندسية',['نور','سكينة'],(8,43,37),(27,93,71)),
 ('orbit','مدارات السكينة','هندسية',['سكينة','ليل'],(7,27,38),(20,75,94)),
 ('dunes','شفق الرمال','طبيعة',['نور','طبيعة'],(101,63,42),(214,155,89)),
 ('ocean','أنفاس البحر','طبيعة',['طبيعة','سكينة'],(13,53,69),(51,124,136)),
 ('rain','مطر وضياء','طبيعة',['ليل','سكينة'],(15,24,45),(50,74,98)),
 ('dawn','إشراقة الفجر','سماء',['نور','طبيعة'],(109,79,88),(224,171,123)),
 ('garden','ندى البستان','طبيعة',['طبيعة','سكينة'],(9,43,37),(40,105,76)),
 ('stars','سكون النجوم','سماء',['ليل','سكينة'],(6,14,35),(24,48,78)),
]

def frame(kind,t,c1,c2):
 phase=2*math.pi*t/SECONDS
 light=np.clip((1-Y)*.45+.17*np.sin(X*3+phase)*np.sin(Y*2+phase)*.30+.12,0,1)
 rgb=np.stack([c1[i]+(c2[i]-c1[i])*light for i in range(3)],axis=2)
 if kind in ('dawn','dunes'):
  glow=np.exp(-((X-(.70+.03*math.sin(phase)))**2+(Y-.26)**2)/.075)
  rgb+=glow[:,:,None]*np.array([47,33,13])
 elif kind in ('mihrab','garden'):
  beam=np.maximum(0,np.cos((X-.50)*5+np.sin(Y*2+phase)*.22))**8*(1-Y)*17
  rgb+=beam[:,:,None]*np.array([.65,1,.7])
 elif kind=='ocean':
  waves=(np.sin(Y*170+np.sin(X*9+phase)*2+phase*3)+np.sin(Y*85-X*12-phase*2))*(Y>.37)*3
  rgb+=waves[:,:,None]*np.array([.5,.8,1])
 im=Image.fromarray(np.uint8(np.clip(rgb,0,255))).convert('RGBA')
 lay=Image.new('RGBA',(W,H));d=ImageDraw.Draw(lay)
 if kind=='mihrab':
  for j in range(6):
   pad=55+j*22;top=150+j*28;bottom=H+120
   x0,x1=pad,W-pad;mid=W/2
   pts=[]
   for k in range(81):
    a=math.pi+math.pi*k/80
    xx=mid+(x1-x0)/2*math.cos(a)
    yy=top+200+200*math.sin(a)
    # Lift the central point into a stylized pointed arch.
    yy-=60*(max(0,1-abs(xx-mid)/((x1-x0)/2)))
    pts.append((xx,yy))
   pts=[(x0,bottom),(x0,top+200)]+pts+[(x1,bottom)]
   d.line(pts,fill=(211,188,128,int(95-j*10+10*math.sin(phase+j))),width=2)
  for j in range(12):
   xx=j*50-30+12*math.sin(phase)
   d.line((xx,0,xx+170,H),fill=(196,207,143,7),width=13)
 elif kind=='orbit':
  cx,cy=W/2,H*.36
  for rad in [88,134,184,242,315]:
   for k in range(16):
    a=2*math.pi*k/16+phase*.08
    x=cx+rad*math.cos(a);y=cy+rad*math.sin(a)
    b=a+math.pi/4
    xx=cx+rad*math.cos(b);yy=cy+rad*math.sin(b)
    d.line((x,y,xx,yy),fill=(132,197,191,38),width=1)
  d.ellipse((cx-34,cy-34,cx+34,cy+34),outline=(228,205,155,100),width=1)
 elif kind=='dunes':
  for j in range(5):
   baseline=H*(.43+j*.125)
   pts=[(x,baseline+50*math.sin(x/W*4+j*.95+.035*math.sin(phase))) for x in range(-5,W+6,4)]
   pts += [(W,H),(0,H)]
   d.polygon(pts,fill=(100+j*9,62+j*6,40+j*4,255))
   d.line(pts[:-2],fill=(225,168,97,95),width=2)
 elif kind=='ocean':
  horizon=H*.37
  d.line((0,horizon,W,horizon),fill=(176,209,200,70),width=1)
  for j in range(27):
   yy=horizon+j*j*.65
   pts=[(x,yy+math.sin(x*.025+phase*2+j)*(.8+j*.16)) for x in range(0,W+5,5)]
   d.line(pts,fill=(147,200,201,15+j*2),width=1+(j>20))
 elif kind=='rain':
  bokeh=Image.new('RGBA',(W,H));bd=ImageDraw.Draw(bokeh)
  for i,p in enumerate(particles[:22]):
   xx=p[0]*W;yy=p[1]*H;r=6+p[2]*25
   bd.ellipse((xx-r,yy-r,xx+r,yy+r),fill=(211,171,110,int(20+12*math.sin(phase+i))))
  im=Image.alpha_composite(im,bokeh.filter(ImageFilter.GaussianBlur(14)))
  for i,p in enumerate(particles):
   xx=(p[0]*W+t*18)%W;yy=(p[1]*H+t*H/SECONDS*2)%H
   d.line((xx,yy,xx-9,yy+37),fill=(176,203,223,int(34+p[2]*65)),width=1)
 elif kind=='dawn':
  d.ellipse((W*.65,H*.17,W*.78,H*.17+W*.13),fill=(255,221,166,150))
  for j in range(5):
   xx=((j*.31+phase*.012)%1.5-.25)*W;yy=H*(.23+j*.055)
   d.ellipse((xx-120,yy-24,xx+150,yy+24),fill=(245,203,169,18))
  d.rectangle((0,H*.83,W,H),fill=(35,47,49,255))
  # Original skyline silhouette; not a representation of a named mosque.
  for xx,hh in [(90,145),(430,120)]:
   d.rectangle((xx-7,H*.83-hh,xx+7,H*.83),fill=(35,47,49,255))
   d.polygon([(xx-9,H*.83-hh),(xx,H*.83-hh-22),(xx+9,H*.83-hh)],fill=(35,47,49,255))
  d.pieslice((190,H*.74,350,H*.9),180,360,fill=(35,47,49,255))
 elif kind=='garden':
  for i in range(75):
   xx=i*W/74;hh=80+particles[i%72,2]*180
   sway=math.sin(phase+xx*.017)*18
   pts=[(xx,H),(xx+sway*.25,H-hh*.4),(xx+sway,H-hh)]
   d.line(pts,fill=(35+i%4*8,100+i%5*6,65+i%4*5,150),width=2)
   d.ellipse((xx+sway-3,H-hh-7,xx+sway+3,H-hh+7),fill=(145,171,111,100))
 elif kind=='stars':
  cx,cy=W*.72,H*.21;r=32
  d.ellipse((cx-r,cy-r,cx+r,cy+r),fill=(225,218,177,215))
  d.ellipse((cx-r+12,cy-r-7,cx+r+8,cy+r-4),fill=(12,27,52,255))
  for i,p in enumerate(particles):
   xx=(p[0]*W+6*math.sin(phase))%W;yy=p[1]*H*.82
   a=int(60+130*(.5+.5*math.sin(phase+i)))
   r=1+(p[3]>.85)
   d.ellipse((xx-r,yy-r,xx+r,yy+r),fill=(228,227,202,a))
 # Slow drifting dust/light is real per-frame animation, not a camera pan.
 if kind not in ('rain','stars'):
  for i,p in enumerate(particles[:44]):
   xx=(p[0]*W+math.sin(phase+i)*12)%W;yy=(p[1]*H-t*H/SECONDS*.2)%H
   r=1+p[2]*1.7
   d.ellipse((xx-r,yy-r,xx+r,yy+r),fill=(239,226,176,int(20+65*p[3])))
 im=Image.alpha_composite(im,lay).convert('RGB')
 return im

ff=imageio_ffmpeg.get_ffmpeg_exe();catalog=[]
for sid,name,cat,moods,c1,c2 in SCENES:
 path=OUT/f'{sid}.mp4'
 if not path.exists():
  cmd=[ff,'-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','pipe:0','-an','-c:v','libx264','-preset','veryfast','-crf','23','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart',str(path)]
  proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=subprocess.PIPE)
  for i in range(FPS*SECONDS):proc.stdin.write(np.array(frame(sid,i/FPS,c1,c2)).tobytes())
  proc.stdin.close();error=proc.stderr.read().decode();code=proc.wait()
  if code:raise RuntimeError(error)
 frame(sid,1,c1,c2).save(OUT/f'{sid}.jpg',quality=91)
 a=np.array(frame(sid,1,c1,c2),dtype=np.float32);b=np.array(frame(sid,3,c1,c2),dtype=np.float32)
 motion=float(np.mean(np.abs(a-b)))
 catalog.append({'id':sid,'name':name,'category':cat,'moods':moods,'duration':SECONDS,'width':W,'height':H,'fps':FPS,'kind':'original-motion-video','license':'CC0-1.0','author':'Ayat project — procedural animation','video':f'/api/media/{sid}.mp4','poster':f'/api/media/{sid}.jpg','motion_difference':round(motion,3),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 print(sid,round(path.stat().st_size/1024),'KB motion',round(motion,3),flush=True)
if (OUT/'THIRD_PARTY_SCENES.json').exists():catalog+=json.loads((OUT/'THIRD_PARTY_SCENES.json').read_text())
(OUT/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'ORIGINAL_MOTION_LICENSE.txt').write_text('All original visual MP4 scenes and poster images in this directory were created programmatically for Ayat.\nDedicated to the public domain under CC0 1.0: https://creativecommons.org/publicdomain/zero/1.0/\nNo Quran text or third-party stock footage is embedded in the source clips.\n',encoding='utf-8')
print('SCENES_READY',len(catalog),flush=True)
