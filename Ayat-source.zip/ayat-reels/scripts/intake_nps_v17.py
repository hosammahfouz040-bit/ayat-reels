"""Independent NPS recorded-footage intake after unavailable Commons sources were paused.
Uses only publisher pages explicitly marking reuse/public domain; does NOT register scenes.
No aliases, credentials, proxies, or rate-limit bypass. Source audio is never retained in clips.
"""
from pathlib import Path
from bs4 import BeautifulSoup
import requests,json,time,hashlib,subprocess,re
import imageio_ffmpeg
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1];C=Path.home()/'.cache/ayat-library-v17/nps';S=C/'sources';REV=C/'review';S.mkdir(parents=True,exist_ok=True);REV.mkdir(exist_ok=True);FF=imageio_ffmpeg.get_ffmpeg_exe();UA={'User-Agent':'AyatReels/1.7 licensed natural-scene review'}
# All IDs below were enumerated from published NPS video elements.
IDS=['av_A45A7B7C295C4718B5FAFE30882C291F','av_ED254BB7155D451F67B12E38646DAE7E','av_EE9C970E155D451F67DE52612E9E3D2C','av_B6D01994155D451F679C4406F71D1006','av_C2A43648155D451F6722A3EAFE93E679','av_C4D62356155D451F671284967DAAF12C','av_E914CCBB155D451F67145502215368AD','av_86B0B928155D451F6702D6AE1A150C99','av_879DBFCD155D451F671CA3725864BF38','av_8D90A2EE155D451F672ED23B8A0C1F37','av_2C35FFB6155D451F678201C028FFC38A','av_786E9815155D451F67A0A18E7686211E','av_561323191DD8B71B0B410405E8F135F8','av_CA91095B989A4762916555D275B2065D']
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def run(args):
 r=subprocess.run([FF,'-hide_banner','-nostdin','-y','-v','error',*args],capture_output=True,timeout=180)
 if r.returncode:raise RuntimeError(r.stderr.decode(errors='replace')[-2000:])
 return r.stdout
rows=json.loads((C/'candidates.json').read_text())
# Three different desert landscapes, from the publisher's explicitly reusable collection.
dv=C/'extra-5.html'
if dv.exists():
 soup=BeautifulSoup(dv.read_text(),'html.parser');links={a.get_text(' ',strip=True):a['href'] for a in soup.find_all('a',href=re.compile('/media/video/view.htm')) if a.get_text(' ',strip=True)}
 for title in ['Sand Dunes','Panamint Mountains','Badwater Basin']:
  if title not in links:continue
  u=links[title];u=u if u.startswith('http') else 'https://www.nps.gov'+u;p=C/(title.replace(' ','_')+'.html')
  if not p.exists():r=requests.get(u,headers=UA,timeout=40);r.raise_for_status();p.write_text(r.text);time.sleep(.4)
  bs=BeautifulSoup(p.read_text(),'html.parser')
  for v in bs.select('video'):
   variants=[dict(x.attrs) for x in v.select('source[src]') if x['src'].startswith('https://www.nps.gov/nps-audiovideo/')]
   if not variants:continue
   ch=max(variants,key=lambda x:int(x.get('res',0)));row={'slug':'deathvalley','id':v['id'],'title':title,'page':u,'url':ch['src'],'profile':int(ch.get('res',0)),'description':title,'page_text':bs.get_text(' ',strip=True),'page_html':str(p),'permission_page':'https://www.nps.gov/deva/learn/photosmultimedia/b-roll-footage.htm','permission_quote':'These silent videos are in the public domain and can be used for any purpose. Please credit Courtsey of the National Park Service.'};rows.append(row);IDS.append(v['id'])
rows={x['id']:x for x in rows};output=[]
for i,ident in enumerate(IDS):
 row=rows[ident]
 if row['profile']<1080:
  print('REJECTED_LOWER_RESOLUTION',ident,row['profile'],flush=True);continue
 assert 'public domain' in row['page_text'].lower() or row.get('permission_quote'),ident
 path=S/(ident+'.mp4')
 if ident=='av_561323191DD8B71B0B410405E8F135F8' and (C/'freshwater-sunset-1080.mp4').exists() and not path.exists():(C/'freshwater-sunset-1080.mp4').replace(path)
 if not path.exists():
  print('DOWNLOADING_RECORDED_NPS',i+1,len(IDS),ident,flush=True)
  with requests.get(row['url'],headers=UA,stream=True,timeout=(15,90)) as response:
   if response.status_code==429:
    (C/'retry-after.json').write_text(json.dumps({'retry_after':response.headers.get('Retry-After'),'url':row['url'],'stopped_at':time.time()}));raise RuntimeError('NPS rate limited: stop, do not switch hosts or profiles.')
   response.raise_for_status();part=path.with_suffix('.download');written=0
   with part.open('wb') as f:
    for b in response.iter_content(1024*1024):
     f.write(b);written+=len(b)
     if written>1_100_000_000:raise RuntimeError('Intake per-source safety limit reached.')
   expected=response.headers.get('Content-Length')
   if expected:assert written==int(expected)
   part.replace(path)
  time.sleep(.5)
 reader=imageio_ffmpeg.read_frames(str(path));meta=next(reader);reader.close();duration=meta['duration'];width,height=meta['source_size'];assert width>=1920 and height>=1080,(ident,meta)
 step=12 if 'A45A7B7C' in ident else 5 if 'CA91095B' in ident else 8 if row['slug']=='deathvalley' else None
 positions=list(range(2,int(duration)-2,step)) if step else [duration*t for t in [.1,.35,.6,.85]]
 frames=[]
 for n,t in enumerate(positions):
  p=REV/f'{ident}-{n}.jpg'
  if not p.exists():run(['-ss',str(t),'-i',str(path),'-frames:v','1','-vf','scale=384:-2',str(p)])
  frames.append({'time':t,'image':str(p)})
 w,h=384,240;sheet=Image.new('RGB',(w*4,40+h*((len(frames)+3)//4)),(18,25,25));d=ImageDraw.Draw(sheet);d.text((6,8),f'{i+1}. {ident} | {duration:.2f}s | {width}x{height} | NPS public domain',fill='white')
 for j,f in enumerate(frames):
  im=Image.open(f['image']);im.thumbnail((w,h-25));x=(j%4)*w;y=40+(j//4)*h;sheet.paste(im,(x,y));d.text((x+8,y+h-20),f'{f["time"]:.2f}s',fill='white')
 cover=REV/f'{i+1:02}-{ident}.jpg';sheet.save(cover,quality=86)
 match=re.search(r'(?:Credit|Credits)\s+(.*?)\s+(?:Date Created|Copyright and Usage Info)',row['page_text']);author=match.group(1).strip() if match and len(match.group(1))<180 else 'National Park Service'
 out={**row,'source_path':str(path),'source_sha256':digest(path),'source_bytes':path.stat().st_size,'source_width':width,'source_height':height,'source_fps':meta['fps'],'source_duration':duration,'license':'Public-domain-USGov','license_url':'https://www.nps.gov/aboutus/disclaimer.htm','author':author,'review_sheet':str(cover),'review_frames':frames,'reviewed':False}
 output.append(out);(C/'intake-sources.json').write_text(json.dumps(output,ensure_ascii=False,indent=2));print('RECORDED_NPS_READY',ident,path.stat().st_size,cover,flush=True)
print('NPS_INTAKE_FINISHED',len(output),flush=True)
