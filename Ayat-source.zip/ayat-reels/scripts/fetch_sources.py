"""Fetch official Tanzil XML, preserving verse attributes exactly, plus notices.
XML is used because its bismillah attribute is separate from ayah 1.
The source bytes are retained unmodified and SHA-256 pinned.
"""
from pathlib import Path
import hashlib,json,requests,xml.etree.ElementTree as ET,re,shutil
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'backend/data'; DATA.mkdir(parents=True,exist_ok=True)
SOURCE='https://tanzil.net/pub/download/index.php?quranType=uthmani&outType=xml&agree=true'
r=requests.get(SOURCE,timeout=45);r.raise_for_status();raw=r.content
(DATA/'quran-uthmani.xml').write_bytes(raw)
xml=ET.fromstring(raw)
verses={};basmalas={}
for sura in xml.findall('sura'):
 for aya in sura.findall('aya'):
  key=f"{int(sura.attrib['index'])}:{int(aya.attrib['index'])}"
  verses[key]=aya.attrib['text']  # No normalization, stripping, diacritic changes or AI.
  if 'bismillah' in aya.attrib:basmalas[str(int(sura.attrib['index']))]=aya.attrib['bismillah']
assert len(verses)==6236 and len(set(k.split(':')[0] for k in verses))==114
notice=re.search(r'<!--(.*?)-->',raw.decode('utf-8'),re.S).group(1)
(DATA/'TANZIL_NOTICE.txt').write_text(notice,encoding='utf-8')
metaurl='https://tanzil.net/res/text/metadata/quran-data.xml'
rr=requests.get(metaurl,timeout=30);rr.raise_for_status();meta=rr.content
(DATA/'quran-data.xml').write_bytes(meta)
surahs=[]
for el in ET.fromstring(meta).findall('.//suras/sura'):
 d=el.attrib
 surahs.append({'id':int(d['index']),'name':d['name'],'english_name':d.get('tname',''),'count':int(d['ayas']),'revelation':d.get('type','')})
assert len(surahs)==114
for s in surahs:
 assert len([k for k in verses if k.startswith(str(s['id'])+':')])==s['count']
manifest={'text_source':SOURCE,'publisher':'Tanzil Project','edition':'Uthmani v1.1 (official XML)','sha256':hashlib.sha256(raw).hexdigest(),'verse_count':len(verses),'surah_count':len(surahs),'metadata_source':metaurl,'metadata_sha256':hashlib.sha256(meta).hexdigest(),'license_url':'https://tanzil.net/docs/text_license','source_url':'https://tanzil.net','notice':notice,'surahs':surahs,'verses':verses,'basmalas':basmalas}
(DATA/'quran.json').write_text(json.dumps(manifest,ensure_ascii=False),encoding='utf-8')
public=ROOT/'frontend/public';public.mkdir(exist_ok=True,parents=True)
# Vite serves/copies backend/data/quran.json verbatim; no duplicate source copy.
for name,url in {
 'AmiriQuran-Regular.ttf':'https://raw.githubusercontent.com/google/fonts/main/ofl/amiriquran/AmiriQuran-Regular.ttf',
 'Amiri-Regular.ttf':'https://raw.githubusercontent.com/google/fonts/main/ofl/amiri/Amiri-Regular.ttf',
 'Tajawal-Regular.ttf':'https://raw.githubusercontent.com/google/fonts/main/ofl/tajawal/Tajawal-Regular.ttf',
 'Tajawal-Medium.ttf':'https://raw.githubusercontent.com/google/fonts/main/ofl/tajawal/Tajawal-Medium.ttf',
 'Tajawal-Bold.ttf':'https://raw.githubusercontent.com/google/fonts/main/ofl/tajawal/Tajawal-Bold.ttf',
 'Tajawal-ExtraBold.ttf':'https://raw.githubusercontent.com/google/fonts/main/ofl/tajawal/Tajawal-ExtraBold.ttf',
}.items():
 dest=ROOT/'backend/fonts'/name
 if not dest.exists():
  rr=requests.get(url,timeout=30);rr.raise_for_status();dest.write_bytes(rr.content)
 shutil.copyfile(dest,public/'fonts'/name)
for family in ['amiri','amiriquran','tajawal']:
 dest=ROOT/'backend/fonts'/f'{family}-OFL.txt'
 if not dest.exists():
  rr=requests.get(f'https://raw.githubusercontent.com/google/fonts/main/ofl/{family}/OFL.txt',timeout=25)
  if rr.ok:dest.write_bytes(rr.content)
print(json.dumps({k:v for k,v in manifest.items() if k not in ['surahs','verses','notice','basmalas']},ensure_ascii=False,indent=2))
print('Exact XML 112:1:',repr(verses['112:1']))
