"""Verify distinct new MP3Quran readers, original recordings and publisher timing pairs.
No synthesized recitations, no verse text from an audio model, no blanket rights claim.
"""
from pathlib import Path
import requests,json,hashlib,subprocess,time,sys
import numpy as np,imageio_ffmpeg
R=Path(__file__).resolve().parents[1];C=Path.home()/'.cache/ayat-library-v17/readers';C.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(R/'backend'))
from publisher_audio import validate_intervals
FF=imageio_ffmpeg.get_ffmpeg_exe();reads=json.loads((C.parent/'timing-reads.json').read_text());by={x['id']:x for x in reads}
chosen=[(12,'idrees_abkar'),(20,'khalid_jalil'),(56,'abdulaziz_zahrani'),(217,'bandar_baleela'),(219,'wadee_yamani'),(221,'raad_kurdi'),(225,'abdulrahman_oosi'),(243,'abdullah_mousa'),(245,'mansour_salimi'),(259,'ahmad_nufais'),(273,'haitham_dukhain'),(299,'hassan_saleh')]
old=[r for r in json.loads((R/'backend/data/reciters.json').read_text()) if r.get('provider')!='publisher-timed'];new=[]
for read,ident in chosen:
 record=by[read];assert record['rewaya']=='حفص عن عاصم' and ident not in {x['id'] for x in old}
 samples=[]
 for surah,count in [(1,7),(112,4)]:
  url=record['folder_url']+f'{surah:03}.mp3';p=C/f'{ident}-{surah:03}.mp3'
  if not p.exists():r=requests.get(url,timeout=60);r.raise_for_status();p.write_bytes(r.content);time.sleep(.2)
  pcm=subprocess.run([FF,'-v','error','-i',str(p),'-f','f32le','-ac','1','-ar','16000','pipe:1'],capture_output=True);pcm.check_returncode();audio=np.frombuffer(pcm.stdout,np.float32);assert len(audio)>16000 and np.max(np.abs(audio))>.001
  timing_url=f'https://mp3quran.net/api/v3/ayat_timing?read={read}&surah={surah}';tpath=C/f'{ident}-{surah:03}-timing.json'
  if not tpath.exists():resp=requests.get(timing_url,timeout=40);resp.raise_for_status();tpath.write_bytes(resp.content);time.sleep(.2)
  rows=json.loads(tpath.read_bytes());numbers=sorted({int(x['ayah']) for x in rows});assert numbers==list(range(1,count+1)),(ident,numbers)
  tail_adjustments=[]
  for x in rows:
   assert 0<=x['start_time']<x['end_time'],(ident,x)
   if x['end_time']>len(audio)/16000*1000:
    assert x['ayah']==count and x['end_time']-len(audio)/16000*1000<=1000 and x['start_time']<len(audio)/16000*1000,(ident,x)
    tail_adjustments.append({'ayah':count,'publisher_end_ms':x['end_time'],'decoded_end_ms':len(audio)/16000*1000,'reason':'Only the final endpoint is bounded to the actual decoded EOF; no verse content beyond the recording can be invented.'})
  validate_intervals(rows,count,len(audio)/16000)
  samples.append({'surah':surah,'url':url,'bytes':p.stat().st_size,'duration':len(audio)/16000,'peak':float(np.max(np.abs(audio))),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'full_decode_exit':0,'publisher_timing_url':timing_url,'publisher_timing_sha256':hashlib.sha256(tpath.read_bytes()).hexdigest(),'publisher_verse_count_verified':count,'publisher_timing_bound_to_reader':read,'final_endpoint_bounded_to_decoded_eof':tail_adjustments})
 new.append({'id':ident,'name':record['name'],'detail':'حفص عن عاصم · تسجيل أصلي وتوقيت آيات من الناشر','narration':'hafs','provider':'publisher-timed','source':'https://www.mp3quran.net/ar/timing-api','publisher_timing_read':read,'publisher_audio_base':record['folder_url'],'publisher_available_surahs':list(range(1,115)),'verification_samples':samples})
 print('NEW_GENUINE_READER_VERIFIED',ident,record['name'],flush=True)
(R/'docs/sources/readers-v17.json').write_text(json.dumps({'date':'2026-10-25','catalog_url':'https://mp3quran.net/api/v3/ayat_timing/reads','publisher_metadata':[{k:r[k] for k in ['id','name','rewaya','folder_url','soar_count']} for r in reads if r['id'] in {x[0] for x in chosen}],'readers':new,'all_114_chapters_physically_downloaded':False,'two_original_recordings_fully_decoded_per_reader':True},ensure_ascii=False,indent=2))
(C/'new-readers.json').write_text(json.dumps(new,ensure_ascii=False,indent=2));print('VERIFIED_NEW_READER_COUNT',len(new),flush=True)
