"""Real MP4 effect matrix against genuine recitation and matching disabled controls.
Outputs stay in excluded .cache, not user projects. Numeric/audit evidence persists.
No fake encoder state, no manufactured audio, no image-only UI proof.
"""
from pathlib import Path
import sys,json,hashlib,time,subprocess
import numpy as np,soundfile as sf
from PIL import Image
from io import BytesIO
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'backend'))
import media_engine as e
from models import ProjectConfig,SceneClip
from visual_effects import EFFECTS_CATALOG
C=Path.home()/'.cache/ayat-effects-matrix';C.mkdir(parents=True,exist_ok=True);e.EXPORTS=C
plan=e.prepare_audio(112,2,2,'mossad');reports=[];results={}

def make(name,fx=None,transition=None,quality='draft',reciter='mossad',from_ayah=2,to_ayah=2,scene_ids=None):
 p=plan if reciter=='mossad' and from_ayah==2 and to_ayah==2 else e.prepare_audio(112,from_ayah,to_ayah,reciter)
 clips=[SceneClip(scene_id='orbit')]
 if transition:clips=[SceneClip(scene_id=(scene_ids or ['orbit','garden'])[0],transition=transition,transition_duration=1,transition_intensity=.8),SceneClip(scene_id=(scene_ids or ['orbit','garden'])[1])]
 cfg=ProjectConfig(title='FX matrix '+name,surah=112,from_ayah=from_ayah,to_ayah=to_ayah,reciter=reciter,quality=quality,clips=clips,effects=fx or {})
 start=time.time();result=e.render(cfg,p,name,lambda *a:None,lambda:False,lambda proc:None);file=C/name/'result.mp4';audit=json.loads((C/name/'audit.json').read_text());assert audit['all_cues_match_source'] and result['text_visible_ratio']>.52
 full=subprocess.run([e.FFMPEG,'-v','error','-i',str(file),'-map','0:v:0','-map','0:a:0','-f','null','-'],capture_output=True);assert full.returncode==0
 expected,sr=sf.read(e.AUDIO/p['id']/'combined.wav',dtype='float32');actual=np.frombuffer(e.run_checked(['-i',str(file),'-vn','-ac','1','-ar','48000','-f','f32le','pipe:1']),np.float32);n=min(len(actual),len(expected));corr=float(np.corrcoef(expected[:n],actual[:n])[0,1]);assert corr>.95
 row={'case':name,'effects':cfg.effects.model_dump(),'transition':transition,'narration':cfg.narration,'quality':quality,'width':result['width'],'height':result['height'],'duration':result['duration'],'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'full_decode_exit':0,'all_cues_match_pinned_source':True,'source_sha256':result['source_sha256'],'audio_correlation':corr,'text_visible_ratio':result['text_visible_ratio'],'seconds_to_render_and_verify':round(time.time()-start,3),'cache_file':str(file),'physical_android_tested':False}
 reports.append(row);results[name]=(result,file);print('REAL_FX_MP4',name,row['bytes'],row['seconds_to_render_and_verify'],flush=True)
 return row

def frame(name,t):
 raw=e.run_checked(['-ss',str(t),'-i',str(results[name][1]),'-frames:v','1','-f','image2pipe','-vcodec','png','pipe:1']);return np.array(Image.open(BytesIO(raw)).convert('RGB'),np.float32)
def distance(a,b,region=None):
 diff=np.abs(a-b).mean(axis=2)
 if region is not None:x1,y1,x2,y2=region;diff=diff[y1:y2,x1:x2]
 flat=diff.reshape(-1);return {'mean_abs_rgb':float(flat.mean()),'top_1024_mean_abs_rgb':float(np.sort(flat)[-min(1024,len(flat)):].mean()),'maximum':float(flat.max())}
make('disabled')
for group in ['verse','scene','camera']:
 for item in EFFECTS_CATALOG[group]:
  kind=item['id'];fx={group:{'enabled':True,'kind':kind,'intensity':1,'duration':1.2 if group=='verse' else 0}}
  if kind=='glow':fx[group]['duration']=3
  row=make(group+'-'+kind,fx)
  scores=[]
  for t in [.16,.55,1.1,1.8]:
   a,b=frame('disabled',t),frame(row['case'],t);region=(50,170,490,800) if group=='verse' else None;scores.append(distance(a,b,region))
  row['pixel_differences_to_disabled']=scores;row['peak_top_pixel_difference']=max(x['top_1024_mean_abs_rgb'] for x in scores)
  assert row['peak_top_pixel_difference']>.5,(row['case'],scores)
  print('PIXELS_CONFIRMED',row['case'],row['peak_top_pixel_difference'],flush=True)
make('transition-fade-control',transition='fade')
for kind in ['light','mist']:
 row=make('transition-'+kind,transition=kind);result=results[row['case']][0];point=result['timeline']['clips'][1]['start']+result['timeline']['clips'][0]['transition_seconds']/2
 row['peak_transition_frame']=point;score=distance(frame(row['case'],point),frame('transition-fade-control',point));row['pixel_difference_to_same_fade']=score;assert score['top_1024_mean_abs_rgb']>.5
low=make('rain-low',{'scene':{'enabled':True,'kind':'rain','intensity':.15,'duration':0}})
low_score=distance(frame('rain-low',1.1),frame('disabled',1.1));high_score=distance(frame('scene-rain',1.1),frame('disabled',1.1));assert high_score['top_1024_mean_abs_rgb']>low_score['top_1024_mean_abs_rgb'];low['strength_control']={'low':low_score,'high':high_score}
short=make('rain-short',{'scene':{'enabled':True,'kind':'rain','intensity':1,'duration':.65}})
short['duration_control']={'early':distance(frame('rain-short',.3),frame('disabled',.3)),'after_end':distance(frame('rain-short',1.8),frame('disabled',1.8))};assert short['duration_control']['early']['top_1024_mean_abs_rgb']>short['duration_control']['after_end']['top_1024_mean_abs_rgb']
off=make('all-selected-but-disabled',{'verse':{'enabled':False,'kind':'reveal','intensity':1},'scene':{'enabled':False,'kind':'rain','intensity':1},'camera':{'enabled':False,'kind':'depth','intensity':1}});off['disabled_control']=distance(frame(off['case'],1.1),frame('disabled',1.1));assert off['disabled_control']['mean_abs_rgb']<.05
make('combined-fullhd',{'verse':{'enabled':True,'kind':'glow','intensity':.4,'duration':3},'scene':{'enabled':True,'kind':'dust','intensity':.35},'camera':{'enabled':True,'kind':'zoom_in','intensity':.3}},transition='mist',quality='fullhd')
make('warsh-reveal',{'verse':{'enabled':True,'kind':'reveal','intensity':1,'duration':1.2}},reciter='suhaim')
make('verse-switch-between-ayahs',{'verse':{'enabled':True,'kind':'verse_switch','intensity':.8,'duration':.6}},from_ayah=1,to_ayah=2)
make('licensed-mosques-with-fog',{'scene':{'enabled':True,'kind':'fog','intensity':.5}},transition='mist',scene_ids=['haram_night','umayyad_mosque'])
report={'version':'1.6.0','actual_mp4_cases':len(reports),'all_modes_exported':True,'quiet_overlay_groups_mutually_exclusive':True,'word_effects_are_visual_not_audio_alignment':True,'depth_is_optical_not_3d':True,'source_texts_unmodified':True,'reports':reports,'temporary_test_outputs_only':True,'physical_android_tested':False,'real_arena_download_issue_resolved':False}
(R/'tests/effects-real-mp4-matrix-v16.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
# A compact frame record, not a substitute for the actual MP4 validation above.
names=['disabled','verse-reveal','verse-highlight','scene-rain','scene-sunrays','scene-dust','scene-stars','camera-depth','transition-light','transition-mist','combined-fullhd','warsh-reveal'];tiles=[]
for name in names:
 t=results[name][0]['duration']*.25
 if name.startswith('transition-'):t=results[name][0]['timeline']['clips'][1]['start']+results[name][0]['timeline']['clips'][0]['transition_seconds']/2
 im=Image.fromarray(np.uint8(frame(name,t))).resize((180,320));tiles.append((name,im))
from PIL import ImageDraw
sheet=Image.new('RGB',(180*6,345*2),'#f4f1e5');d=ImageDraw.Draw(sheet)
for i,(name,im) in enumerate(tiles):x=(i%6)*180;y=(i//6)*345;d.text((x+4,y+3),name,fill='#244538');sheet.paste(im,(x,y+25))
sheet.save(R/'tests/effects-real-frames-v16.jpg',quality=79)
print('REAL_MP4_EFFECT_MATRIX_COMPLETE',len(reports),flush=True)
