"""Refresh the bundled offline catalog after editing backend library metadata (stdlib only)."""
from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'backend'))
from catalog import SCENES,RECITERS,TEMPLATES,QUALITIES
from quran import SURAHS,source_info
from visual_effects import EFFECTS_CATALOG
from version import APP_VERSION
ids={s['id'] for s in SCENES}
for scene in SCENES:
 video=ROOT/'backend/media'/(scene['id']+'.mp4')
 if scene.get('availability')=='on-demand':
  assert len(scene['remote_source']['sha256'])==64 and scene['remote_source']['bytes']>1000 and scene['motion_difference']>.5,scene['id']
 else:assert video.exists() and hashlib.sha256(video.read_bytes()).hexdigest()==scene['sha256'],scene['id']
 assert (ROOT/'backend/media'/(scene['id']+'.jpg')).exists()
for template in TEMPLATES:assert all(s in ids for s in template['scene_ids']),template['id']
value={'app_version':APP_VERSION,'effects':EFFECTS_CATALOG,'surahs':SURAHS,'reciters':RECITERS,'scenes':SCENES,'templates':TEMPLATES,'qualities':list(QUALITIES.values()),'source':source_info(),'sources':{k:source_info(k) for k in ['hafs','warsh']},'fonts':[{'id':'amiri_quran','name':'أميري قرآن'},{'id':'amiri','name':'أميري'}]}
(ROOT/'frontend/public/catalog.json').write_text(json.dumps(value,ensure_ascii=False,indent=2))
print('CATALOG_SYNCED',len(SCENES),'videos',len(TEMPLATES),'templates',len(RECITERS),'readers')
