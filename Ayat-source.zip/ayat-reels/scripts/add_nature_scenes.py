"""Add 16 actual CC0 nature videos, keep originals in excluded cache, bundle compact moving MP4s."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import requests,json,hashlib,subprocess,html,re,shutil,time
import numpy as np
import imageio_ffmpeg
ROOT=Path(__file__).resolve().parents[1];MEDIA=ROOT/'backend/media';CACHE=Path.home()/'.cache/ayat-nature-originals';CACHE.mkdir(parents=True,exist_ok=True)
FF=imageio_ffmpeg.get_ffmpeg_exe();UA={'User-Agent':'AyatReels/1.1 (media source and CC0 attribution verification)'}
# Stable Commons titles, curated for nature; no third-party stock-platform redistribution restrictions.
SPECS=[
 ('waterfall','اندفاع الشلال','مياه',['طبيعة','سكينة'],'File:Watagataki Falls (Video).webm'),
 ('river_gorge','نهر بين الجبال','مياه',['طبيعة','سكينة'],'File:Tedori River Gorge (Video).webm'),
 ('forest_stream','جدول الغابة','غابات',['طبيعة','سكينة'],'File:Overlooking a forest creek in the Tsimpsean Peninsula.webm'),
 ('beach','أمواج الشاطئ','بحر',['طبيعة','سكينة'],'File:Black Head Beach, New South Wales.webm'),
 ('sunrise_sea','فجر البحر','بحر',['طبيعة','نور'],'File:Sunrise Glow Over Surf Beach with Pink Horizon and Vibrant Sand Tones.webm'),
 ('golden_sunset','غروب ذهبي','غروب',['طبيعة','نور','سكينة'],'File:Golden sunset filmed in January.webm'),
 ('clouds','سحب عابرة','سماء',['طبيعة','نور'],'File:All4sounds - Cloud Time lapse.webm'),
 ('rain_leaves','مطر الطبيعة','مطر',['طبيعة','سكينة'],'File:Rain in the Netherlands (2026 autumn).webm'),
 ('blue_flowers','زهر أزرق','زهور',['طبيعة','نور'],'File:Close-up View Of Blue Flowers.webm'),
 ('garden_bees','حياة البستان','زهور',['طبيعة','نور'],'File:Bees on Hibiscus syriacus.webm'),
 ('snow_forest','ثلج الصنوبر','ثلوج',['طبيعة','سكينة'],'File:Snow falls on evergreens protected by a rocky outcrop.webm'),
 ('winter_lake','بحيرة شتوية','ثلوج',['طبيعة','سكينة'],'File:Snow Dusted Lake Shore of Okanagan Centre on a Late Winter Morning.webm'),
 ('misty_river','ضباب النهر','مياه',['طبيعة','سكينة'],'File:Misty river 47 seconds.webm'),
 ('real_dunes','رمال الطبيعة','رمال',['طبيعة','نور'],'File:Teri 20221223 152103.webm'),
 ('mountain_clouds','سماء الجبال','جبال',['طبيعة','نور','سكينة'],'File:Timelapse of Clouds over Bellevue Canyon.webm'),
 ('real_moon','قمر الليل','سماء',['ليل','سكينة'],'File:Flower Moon May 2nd 2024.webm'),
]
metadata_file=ROOT/'docs/sources/nature-source-metadata.json'
if metadata_file.exists():data=json.loads(metadata_file.read_text())
else:
 r=requests.get('https://commons.wikimedia.org/w/api.php',params={'action':'query','format':'json','titles':'|'.join(x[4] for x in SPECS),'prop':'videoinfo|revisions','viprop':'url|size|extmetadata|derivatives','rvprop':'ids|timestamp'},headers=UA,timeout=60);r.raise_for_status();data=r.json();metadata_file.write_text(json.dumps(data,ensure_ascii=False,indent=2))
pages={p['title']:p for p in data['query']['pages'].values()}

def checked(args):
 p=subprocess.run([FF,'-hide_banner','-y','-v','error',*args],capture_output=True);p.check_returncode();return p.stdout
def build(spec):
 sid,name,category,moods,title=spec;p=pages[title];v=p['videoinfo'][0];m=v['extmetadata'];assert m['LicenseShortName']['value']=='CC0',title
 source=v['url'].split('?')[0];original=CACHE/(sid+'.webm');source_record=CACHE/(sid+'.source.json')
 if source_record.exists():source=json.loads(source_record.read_text())['url']
 elif not original.exists() and v['size']>5_000_000:
  # Prefer provider-published VP9 transcodes: lower bandwidth, same licensed footage.
  variants=[d for d in v.get('derivatives',[]) if d.get('transcodekey','').endswith('vp9.webm') and d.get('height',0)>=480 and d.get('width',0)>=270]
  small=[d for d in variants if d.get('bandwidth',0)*v['duration']/8<=12_000_000]
  if small:source=max(small,key=lambda d:min(d['width'],d['height']))['src'].split('?')[0]
  elif variants:source=min(variants,key=lambda d:d.get('bandwidth',10**12))['src'].split('?')[0]

 if not original.exists():
  cooldown=CACHE/'retry-after.json'
  if cooldown.exists():
   remaining=max(0,json.loads(cooldown.read_text())['not_before']-time.time())
   if remaining:print('PROVIDER_COOLDOWN',round(remaining),flush=True);time.sleep(remaining)
  for attempt in range(6):
   with requests.get(source,headers=UA,stream=True,timeout=120) as response:
    if response.status_code==429 and attempt<5:
     delay=max(15,int(response.headers.get('Retry-After','15')))*(attempt+1)
     print('RATE_LIMIT_BACKOFF',sid,delay,flush=True);(CACHE/'retry-after.json').write_text(json.dumps({'not_before':time.time()+delay}));response.close();time.sleep(delay);continue
    response.raise_for_status();part=original.with_suffix('.part')
    with part.open('wb') as f:
     for chunk in response.iter_content(128*1024):
      f.write(chunk);time.sleep(.3)
    expected=response.headers.get('Content-Length')
    if expected and part.stat().st_size!=int(expected):raise RuntimeError('Incomplete nature source download')
    part.replace(original);source_record.write_text(json.dumps({'url':source}));break
  time.sleep(5)
 dest=MEDIA/(sid+'.mp4');poster=MEDIA/(sid+'.jpg');source_start=24 if sid=='garden_bees' else 0
 if not dest.exists():
  # Compact real motion, not Ken Burns on a still. Audio from sources is deliberately removed.
  checked(['-stream_loop','-1','-ss',str(source_start),'-i',str(original),'-t','6','-vf','scale=540:960:force_original_aspect_ratio=increase,crop=540:960,setsar=1,fps=24','-an','-c:v','libx264','-preset','fast','-b:v','360k','-maxrate','430k','-bufsize','720k','-pix_fmt','yuv420p','-threads','1','-movflags','+faststart',str(dest)])
 checked(['-ss','1.2','-i',str(dest),'-frames:v','1','-q:v','5',str(poster)])
 frames=[np.frombuffer(checked(['-ss',str(t),'-i',str(dest),'-frames:v','1','-vf','scale=90:160','-f','rawvideo','-pix_fmt','rgb24','pipe:1']),np.uint8).astype(float) for t in [1,3]]
 motion=float(np.abs(frames[0]-frames[1]).mean());assert motion>.15,(sid,motion)
 checked(['-i',str(dest),'-f','null','-'])
 author=html.unescape(re.sub('<[^>]+>','',m.get('Artist',{}).get('value','Wikimedia Commons contributor'))).strip()
 record={'id':sid,'name':name,'category':category,'moods':moods,'duration':6,'width':540,'height':960,'fps':24,'kind':'real-footage','license':'CC0-1.0','license_url':'https://creativecommons.org/publicdomain/zero/1.0/','author':author,'source_url':v['descriptionurl'],'source_title':title,'download_url':source,'source_revision':p.get('revisions',[{}])[0].get('revid'),'source_start':source_start,'source_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'video':f'/api/media/{sid}.mp4','poster':f'/api/media/{sid}.jpg','motion_difference':round(motion,6),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'adaptation':f'6-second excerpt beginning at {source_start}s, silent, cropped to 9:16, scaled and encoded as H.264. Not AI-generated footage.'}
 print('NATURE_VERIFIED',sid,dest.stat().st_size,'motion',round(motion,3),flush=True);return record
with ThreadPoolExecutor(max_workers=1) as pool:new=list(pool.map(build,SPECS))
old=json.loads((MEDIA/'catalog.json').read_text());new_ids={x['id'] for x in new};catalog=[x for x in old if x['id'] not in new_ids]+new
(MEDIA/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2));third=[s for s in catalog if s.get('source_url')];(MEDIA/'THIRD_PARTY_SCENES.json').write_text(json.dumps(third,ensure_ascii=False,indent=2))
credits='Recorded footage; licenses are PER SOURCE, not all CC0. Required CC BY credits must be retained. No source audio retained.\n\n'+'\n\n'.join(f"{x['name']} / {x['source_title']}\nAuthor: {x['author']}\nLicense: {x['license_url']}\nSource: {x['source_url']}\nChanges: {x['adaptation']}" for x in third)
(MEDIA/'SCENE_CREDITS.txt').write_text(credits);(ROOT/'frontend/public/SCENE_CREDITS.txt').write_text(credits)
(ROOT/'tests/nature-assets.json').write_text(json.dumps(new,ensure_ascii=False,indent=2));print('SCENE_LIBRARY',len(catalog),flush=True)
