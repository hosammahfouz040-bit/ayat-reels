"""License-first discovery; no source files added or mislabeled by this script."""
from pathlib import Path
import requests,json,time,html,re
R=Path(__file__).resolve().parents[1];C=Path.home()/'.cache/ayat-library-v17';C.mkdir(parents=True,exist_ok=True)
UA={'User-Agent':'AyatReels/1.7 (educational video editor; license verification)'}
queries=[
 ('mosques','filetype:video intitle:mosque'),('islamic','filetype:video ("mosque" OR "islamic architecture")'),
 ('waterfalls','filetype:video ("waterfall" OR "Svartifoss")'),('mountains','filetype:video ("mountain" OR "Alps") 4K'),
 ('sea','filetype:video ("ocean" OR "sea waves") 4K'),('rain','filetype:video intitle:rain'),
 ('sky','filetype:video "clouds" 4K'),('sunrise','filetype:video intitle:sunrise'),('sunset','filetype:video intitle:sunset')]
rows={}
for category,query in queries:
 cache=C/('discovery-'+category+'.json')
 if cache.exists():data=json.loads(cache.read_text())
 else:
  response=requests.get('https://commons.wikimedia.org/w/api.php',params={'action':'query','format':'json','generator':'search','gsrsearch':query,'gsrnamespace':6,'gsrlimit':30,'prop':'videoinfo|revisions','viprop':'url|size|extmetadata|derivatives','rvprop':'ids|timestamp'},headers=UA,timeout=60)
  if response.status_code==429:raise RuntimeError('Provider rate-limited discovery; stop and respect Retry-After, do not evade.')
  response.raise_for_status();data=response.json();cache.write_text(json.dumps(data,ensure_ascii=False,indent=2));time.sleep(1.5)
 for p in data.get('query',{}).get('pages',{}).values():
  if not p.get('videoinfo'):continue
  v=p['videoinfo'][0];m=v.get('extmetadata',{});license=m.get('LicenseShortName',{}).get('value','')
  if license not in ['CC0','CC BY 3.0','CC BY 4.0','Public domain']:continue
  if v.get('width',0)<1080 or v.get('height',0)<720:continue
  author=html.unescape(re.sub('<[^>]+>','',m.get('Artist',{}).get('value',''))).strip()
  rows[p['title']]={'title':p['title'],'category':category,'width':v.get('width'),'height':v.get('height'),'bytes':v.get('size'),'license':license,'author':author,'description':html.unescape(re.sub('<[^>]+>','',m.get('ImageDescription',{}).get('value','')))[:800],'pageid':p['pageid'],'metadata':p}
 print('DISCOVERY',category,len(rows),flush=True)
(C/'discovered-candidates.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
for row in rows.values():print('CANDIDATE',row['category'],row['title'],row['width'],row['height'],row['bytes'],row['license'],row['author'][:55],flush=True)
