"""Restore the exact 48 licensed background MP4s from the accompanying Ayat APK.
Used by the thin source archive to avoid shipping a third duplicate of the videos.
Never installs/executes the APK. Every video is SHA-256 checked against catalog.json.
Existing correct files are left untouched; existing different files are not overwritten.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,zipfile
ROOT=Path(__file__).resolve().parents[1]

def restore(apk:Path,destination:Path):
 catalog=json.loads((ROOT/'backend/media/catalog.json').read_text())
 destination.mkdir(parents=True,exist_ok=True);restored=existing=0
 with zipfile.ZipFile(apk) as archive:
  for scene in catalog:
   ident=scene['id']
   if not re.fullmatch(r'[a-z0-9_]+',ident):raise ValueError('Invalid scene ID.')
   target=destination/(ident+'.mp4')
   if target.exists():
    if hashlib.sha256(target.read_bytes()).hexdigest()!=scene['sha256']:raise ValueError('Existing video differs; refusing to replace: '+ident)
    existing+=1;continue
   member='assets/public/scenes/'+ident+'.mp4';info=archive.getinfo(member)
   if info.file_size<1000 or info.file_size>50_000_000:raise ValueError('Unexpected video size: '+ident)
   temp=target.with_suffix('.restore.tmp');digest=hashlib.sha256()
   try:
    with archive.open(member) as source,temp.open('wb') as out:
     while block:=source.read(1024*1024):digest.update(block);out.write(block)
    if digest.hexdigest()!=scene['sha256']:raise ValueError('Video checksum mismatch: '+ident)
    os.replace(temp,target);restored+=1
   finally:temp.unlink(missing_ok=True)
 return {'restored':restored,'already_correct':existing,'total':len(catalog),'all_sha256_verified':True}

if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--apk',type=Path,required=True,help='Path to the accompanying Ayat-debug.apk');parser.add_argument('--media-dir',type=Path,default=ROOT/'backend/media',help='Default: backend/media; optional isolated verification destination')
 args=parser.parse_args();print(json.dumps(restore(args.apk,args.media_dir),indent=2))
