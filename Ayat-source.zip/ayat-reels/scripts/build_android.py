"""Build a real debug APK on Linux. Optional --lint needs additional memory."""
from pathlib import Path
import argparse,os,json,subprocess,shutil
parser=argparse.ArgumentParser();parser.add_argument('--lint',action='store_true',help='Also run Android Lint; allow additional RAM/time.');args=parser.parse_args()
ROOT=Path(__file__).resolve().parents[1];FRONT=ROOT/'frontend';ANDROID=FRONT/'android'
env=os.environ.copy();cache=Path.home()/'.cache';cached=cache/'ayat-android/env.json'
if cached.exists():
 for key,value in json.loads(cached.read_text()).items():env.setdefault(key,value)
if not env.get('ANDROID_HOME'):raise SystemExit('Set ANDROID_HOME to your Android SDK (API 35).')
env['ANDROID_SDK_ROOT']=env['ANDROID_HOME']
# Keep downloaded Gradle dependencies and project caches out of source snapshots.
env.setdefault('GRADLE_USER_HOME',str(cache/'ayat-gradle'))
if env.get('JAVA_HOME'):env['PATH']=str(Path(env['JAVA_HOME'])/'bin')+os.pathsep+env['PATH']
(ANDROID/'local.properties').write_text('sdk.dir='+env['ANDROID_HOME'].replace('\\','\\\\')+'\n')
for cmd in [['npm','run','build'],['npx','cap','sync','android']]:subprocess.run(cmd,cwd=FRONT,env=env,check=True)
(ANDROID/'gradlew').chmod(0o755)
cmd=['./gradlew','--no-daemon','--max-workers=1','--project-cache-dir='+str(cache/'ayat-gradle-project'),'-Dorg.gradle.jvmargs='+env.get('AYAT_GRADLE_JVM_ARGS','-Xmx512m -XX:MaxMetaspaceSize=192m'),'assembleDebug']
if args.lint:cmd+=[':app:lintDebug']
subprocess.run(cmd,cwd=ANDROID,env=env,check=True)
apk=ANDROID/'app/build/outputs/apk/debug/app-debug.apk';dest=ROOT/'deliverables/Ayat-debug.apk';dest.parent.mkdir(exist_ok=True)
shutil.copyfile(apk,dest)
print('APK_BUILT',dest,dest.stat().st_size,flush=True)
