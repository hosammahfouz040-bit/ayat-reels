"""Import the UNCHANGED official KFGQPC Warsh text/font, verify archive + two formats.
The large original distribution stays in .cache; its published SHA and inner hashes persist.
"""
from pathlib import Path
from io import BytesIO
import requests,hashlib,zipfile,json,gzip,xml.etree.ElementTree as ET
from fontTools.ttLib import TTFont
R=Path(__file__).resolve().parents[1]
URL='https://download.qurancomplex.gov.sa/resources_dev/kfgqpc_warsh_v30.zip'
PUBLISHED='d79b0e9d71696e6967a8f9051e62da87e3ad797e76c6b9d931d66fcf7739bbda'
p=Path.home()/'.cache/ayat-requested-readers/kfgqpc_warsh_v30.zip';p.parent.mkdir(parents=True,exist_ok=True)
if not p.exists():
 response=requests.get(URL,timeout=90);response.raise_for_status();p.write_bytes(response.content)
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(p.read_bytes())==PUBLISHED,'Official published archive checksum mismatch: do not import.'
with zipfile.ZipFile(p) as z:
 raw=z.read('kfgqpc_warsh_v30-data/kfgqpc_warsh_v30.json');xml=z.read('kfgqpc_warsh_v30-data/kfgqpc_warsh_v30.xml');font=z.read('kfgqpc_warsh_v30-font/kfgqpc_warsh_v30.ttf')
 rows=json.loads(raw);from_json={f"{r['sura_no']}:{r['aya_no']}":r['aya_text_unicode'] for r in rows}
 from_xml={f"{int(r.findtext('sura_no'))}:{int(r.findtext('aya_no'))}":r.findtext('aya_text_unicode') for r in ET.fromstring(xml).findall('ROW')}
 assert from_json==from_xml and len(from_json)==6214
 assert len({r['sura_no'] for r in rows})==114
 for surah in range(1,115):
  nums=[r['aya_no'] for r in rows if r['sura_no']==surah];assert nums==list(range(1,len(nums)+1))
 d=R/'backend/data';d.mkdir(exist_ok=True)
 # Gzip is a storage wrapper; decompression yields every byte of the official JSON.
 (d/'quran-warsh-source.json.gz').write_bytes(gzip.compress(raw,mtime=0))
 (R/'backend/fonts/KFGQPCWarsh.ttf').write_bytes(font)
 f=TTFont(BytesIO(font));names={n.nameID:n.toUnicode() for n in f['name'].names}
 license=names[0]+'\n\n'+names[13]+'\n\nOriginal source: '+URL+'\nPublisher: https://qurancomplex.gov.sa/quran-dev/\nFont distributed UNMODIFIED. Not OFL/CC0.\n'
 (R/'backend/fonts/KFGQPCWarsh-LICENSE.txt').write_text(license)
 meta={'narration':'warsh','narration_name':'ورش عن نافع','publisher':'مجمع الملك فهد لطباعة المصحف الشريف','edition':'مصحف المدينة النبوية · ورش عن نافع · إصدار الناشر 8.0 (2026-10-01)','sha256':sha(raw),'verse_count':6214,'surah_count':114,'source_url':'https://qurancomplex.gov.sa/quran-dev/','text_source':URL,'license_url':'https://qurancomplex.gov.sa/quran-dev/','notice':'نص رواية ورش عن نافع من النسخة الرقمية الرسمية لمجمع الملك فهد لطباعة المصحف الشريف. النص محفوظ كما ورد، بما فيه الضبط وعلامات نهاية الآيات، دون تطبيع أو توليد. خط KFGQPC Warsh مرفق دون تعديل وفق ترخيصه الأصلي؛ ليس OFL ولا CC0. المصدر: https://qurancomplex.gov.sa/quran-dev/','font_family':'KFGQPCWarsh','font_file':'KFGQPCWarsh.ttf','font_sha256':sha(font),'embedded_ayah_markers':True,'source_archive_sha256':PUBLISHED,'source_json_member':'kfgqpc_warsh_v30-data/kfgqpc_warsh_v30.json','cross_checked_xml_member':'kfgqpc_warsh_v30-data/kfgqpc_warsh_v30.xml','cross_checked_xml_sha256':sha(xml),'published_archive_hash_url':'https://qurancomplex.gov.sa/quran-dev/','all_6214_text_fields_match_official_xml':True}
 (d/'warsh-source-info.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
 (R/'tests/warsh-source-verification.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
 print('OFFICIAL_WARSH_IMPORTED',len(from_json),'exact verses',sha(raw),'FONT',len(font),sha(font))
