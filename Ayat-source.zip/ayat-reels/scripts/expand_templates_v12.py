"""Add 40 actual text/timeline presets; preserve all original template IDs."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
# Each preset uses a deliberately chosen sequence, not an inert gallery thumbnail.
SPECS=[
 ('haram_sakinah','سكينة الحرم','سكينة',['haram_night','haram_day','haram_close_tawaf']),
 ('haram_tawaf','إيقاع المطاف','سكينة',['haram_close_tawaf','haram_ramadan_tawaf','haram_night_bridge']),
 ('haram_gold','مهابة البيت','نور',['haram_day','haram_day_wide','haram_ramadan']),
 ('haram_nights','أمسيات مكة','ليل',['haram_night','haram_night_bridge','haram_day']),
 ('haram_ramadan_light','أنوار رمضان','نور',['haram_ramadan','haram_ramadan_tawaf','haram_courtyard']),
 ('haram_black_white','وقار','سكينة',['haram_day_wide','haram_night','haram_day']),
 ('haram_quiet','حول البيت','سكينة',['haram_night_bridge','haram_close_tawaf','haram_ramadan']),
 ('haram_daylight','نور المطاف','نور',['haram_day','haram_ramadan','haram_day_wide']),
 ('mosque_journey','رحلة المآذن','سكينة',['haram_night','umayyad_mosque','putra_mosque']),
 ('dome_rock_light','أروقة القدس','نور',['dome_rock_inside','aqsa_courtyard','clouds']),
 ('aqsa_stillness','ساحات القدس','سكينة',['aqsa_courtyard','dome_rock_inside','winter_clouds']),
 ('putra_reflection','قبة وماء','طبيعة',['putra_mosque','putra_mosque_water','winter_lake']),
 ('bursa_arcades','أروقة بورصة','ليل',['bursa_mosque','mihrab','haram_night_bridge']),
 ('umayyad_light','نور دمشق','نور',['umayyad_mosque','qolsharif_mosque','dome_rock_inside']),
 ('minarets_at_dusk','ظلال المآذن','ليل',['qolsharif_mosque','bursa_mosque','putra_mosque_water']),
 ('stone_and_sky','ساحات ومآذن','سكينة',['kondotty_mosque','umayyad_mosque','aqsa_courtyard']),
 ('mosque_waterway','نقاء المساجد','طبيعة',['putra_mosque_water','river_gorge','putra_mosque']),
 ('haram_to_nature','من البيت إلى الأفق','نور',['haram_day','open_sea','green_mountains']),
 ('sacred_night','ليل وطمأنينة','ليل',['haram_night','bursa_mosque','stars']),
 ('tranquil_arches','أقواس السكينة','سكينة',['dome_rock_inside','umayyad_mosque','kondotty_mosque']),
 ('lake_reflection','مرآة البحيرة','طبيعة',['skaha_lake','winter_lake','mountain_clouds']),
 ('autumn_whisper','همس الخريف','نور',['autumn_reeds','golden_sunset','stream_grasses']),
 ('lavender_notes','نفحات اللافندر','طبيعة',['lavender_field','wildflowers_bee','blue_flowers']),
 ('forest_breeze','نسيم الغابات','سكينة',['stream_grasses','forest_stream','snow_forest']),
 ('alpine_horizon','أفق جديد','نور',['green_mountains','winter_clouds','river_gorge']),
 ('blue_distance','امتداد أزرق','طبيعة',['open_sea','beach','sunrise_sea']),
 ('winter_silence_v12','صمت الشتاء','سكينة',['winter_clouds','snow_forest','winter_lake']),
 ('blossom_garden','بساتين الورد','نور',['wildflowers_bee','blue_flowers','lavender_field','garden_bees']),
 ('shore_mist','ضفاف وضباب','سكينة',['skaha_lake','misty_river','forest_stream']),
 ('golden_reeds','قصب ذهبي','نور',['autumn_reeds','real_dunes','golden_sunset']),
 ('gentle_current','خيط من الماء','طبيعة',['stream_grasses','river_gorge','waterfall']),
 ('mountain_wings','فوق القمم','طبيعة',['green_mountains','mountain_clouds','winter_clouds']),
 ('moon_over_water','قمر وماء','ليل',['real_moon','skaha_lake','ocean']),
 ('rain_lavender','مطر ولافندر','سكينة',['rain_leaves','lavender_field','blue_flowers']),
 ('turquoise_flow','سريان','طبيعة',['open_sea','waterfall','river_gorge']),
 ('last_sunbeam','آخر الضوء','نور',['autumn_reeds','golden_sunset','sunrise_sea']),
 ('sky_breath','متسع للسكينة','سكينة',['winter_clouds','mountain_clouds','clouds']),
 ('deep_green_stream','نبض أخضر','طبيعة',['forest_stream','stream_grasses','skaha_lake']),
 ('dunes_and_clouds','رمل وسحاب','نور',['real_dunes','winter_clouds','green_mountains']),
 ('night_to_dawn','من الليل للفجر','ليل',['real_moon','haram_night_bridge','sunrise_sea']),
]
PALETTES=[
 ('#FFF5D9','#091E19','#BFA470'),('#FFFFFF','#09231D','#8FAF9A'),
 ('#F6E4B5','#2A2013','#CFA964'),('#EEF1FF','#111A2D','#A5B8D9'),
 ('#FFF7ED','#291F20','#D9AB88'),('#FFFFFF','#151C1B','#AFB8B0'),
 ('#E6F2E4','#0F261F','#8AB59D'),('#FFEDCE','#302515','#D9BB87'),
 ('#EEEAD8','#182C26','#B6B890'),('#F4E8D8','#292321','#C9B2A1'),
 ('#E2F4F3','#082D32','#7FB4B7'),('#F1E7F7','#251C2D','#B59BCA'),
]
ids={s['id'] for s in json.loads((ROOT/'backend/media/catalog.json').read_text())}
new=[]
for i,(tid,name,mood,scenes) in enumerate(SPECS):
 assert all(s in ids for s in scenes),(tid,[s for s in scenes if s not in ids])
 color,box,accent=PALETTES[i%len(PALETTES)]
 new.append({'id':tid,'name':name,'tag':'الحرم المكي' if tid.startswith('haram_') else ('مساجد' if i<20 else 'طبيعة مصوَّرة'),'description':('حركة مصوَّرة، ونص قرآني واضح بألوان '+('دافئة.' if i%2 else 'هادئة.')),'mood':mood,'scene_ids':scenes,'color':color,'box_color':box,'box_opacity':round(.28+.04*(i%5),2),'font':'amiri' if i%3==1 else 'amiri_quran','size':[76,80,84,78,82][i%5],'y':[.47,.50,.52,.49,.51][i%5],'accent':accent,'transition':['fade','fade','wipeleft','slideup','cut'][i%5],'transition_duration':[.45,.6,.4,.5,.05][i%5],'durations':[[6,5,6],[5,7,5],[7,5,6],[6,6,5]][i%4]+([5] if len(scenes)==4 else []),'x':[.5,.5,.48,.52][i%4],'max_width':[.79,.82,.84,.80][i%4],'alignment':'right' if i%6==4 else 'center'})
p=ROOT/'backend/data/templates-extra.json';old=json.loads(p.read_text());new_ids={t['id'] for t in new}
# New collection is discoverable first; every previous ID/preset remains available unchanged.
result=new+[t for t in old if t['id'] not in new_ids];p.write_text(json.dumps(result,ensure_ascii=False,indent=2))
print('TEMPLATES_READY',len(result)+6,'including',len(new),'new functional presets')
