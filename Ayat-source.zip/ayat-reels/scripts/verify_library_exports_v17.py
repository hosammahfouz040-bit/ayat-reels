"""Actual MP4 matrix: all 24 new scenes, all 12 new real readers, legacy rights and Warsh.
Temporary encodes remain in excluded cache. No DB/user project mutation or fabricated audio.
"""
from pathlib import Path
from io import BytesIO
import sys,json,time,hashlib,subprocess
import numpy as np,soundfile as sf
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'backend'))
import media_engine as e
from models import ProjectConfig,SceneClip
from catalog import SCENES,RECITERS,SCENE_MAP
C=Path.home()/'.cache/ayat-library-v17/real-exports';C.mkdir(parents=True,exist_ok=True);e.EXPORTS=C
new_scenes=[s for s in SCENES if s.get('availability')=='on-demand'];readers=[r for r in RECITERS if r.get('provider')=='publisher-timed'];assert len(new_scenes)==24 and len(readers)==12
reports=[];results={}
def make(name,reciter,scene_ids,quality='draft',effects=None,transition='fade'):
 p=e.prepare_audio(112,2,2,reciter);clips=[SceneClip(scene_id=ident,source_out=min(6,SCENE_MAP[ident]['duration']),transition=transition,transition_duration=.5,transition_intensity=.35) for ident in scene_ids]
 cfg=ProjectConfig(title='QA v17 library matrix '+name,surah=112,from_ayah=2,to_ayah=2,reciter=reciter,quality=quality,clips=clips,effects=effects or {})
 started=time.time();result=e.render(cfg,p,name,lambda *a:None,lambda:False,lambda process:None);file=C/name/'result.mp4';audit=json.loads((file.parent/'audit.json').read_text())
 assert audit['all_cues_match_source'] and result['text_visible_ratio']>.52 and result['visual_attribution_burned']
 full=subprocess.run([e.FFMPEG,'-v','error','-i',str(file),'-map','0:v:0','-map','0:a:0','-f','null','-'],capture_output=True);assert full.returncode==0
 expected,sr=sf.read(e.AUDIO/p['id']/'combined.wav',dtype='float32');actual=np.frombuffer(e.run_checked(['-i',str(file),'-vn','-ac','1','-ar','48000','-f','f32le','pipe:1']),np.float32);n=min(len(actual),len(expected));corr=float(np.corrcoef(expected[:n],actual[:n])[0,1]);assert sr==48000 and corr>.95,(name,corr)
 assert audit['cues'][0]['text']==e.get_verses(112,2,2,cfg.narration)[0]['text']
 row={'case':name,'reciter':reciter,'narration':cfg.narration,'scene_ids':scene_ids,'effects':cfg.effects.model_dump(),'transition':transition,'quality':quality,'width':result['width'],'height':result['height'],'fps':result['fps'],'duration':result['duration'],'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'full_decode_exit':0,'source_sha256':result['source_sha256'],'source_quran_exact':True,'audio_correlation_to_genuine_recording':corr,'visual_attribution_burned':result['visual_attribution_burned'],'text_visible_ratio':result['text_visible_ratio'],'seconds_to_render_and_verify':round(time.time()-started,3),'temporary_cache_file':str(file)}
 reports.append(row);results[name]=(result,file);(R/'tests/library-real-mp4-matrix-v17.json').write_text(json.dumps({'version':'1.7.0','completed_cases':len(reports),'all_requested_cases_completed':False,'reports':reports,'physical_android_tested':False,'real_arena_download_issue_resolved':False},ensure_ascii=False,indent=2));print('GENUINE_LIBRARY_MP4',name,row['bytes'],'bytes',row['seconds_to_render_and_verify'],'seconds','audio_corr',round(corr,6),flush=True);return row
for i,reader in enumerate(readers):make('reader-'+reader['id'],reader['id'],[s['id'] for s in new_scenes[i*2:i*2+2]])
make('mixed-license-control','idrees_abkar',['haram_night','v17_pine_mist'])
make('mixed-license-effects','idrees_abkar',['haram_night','v17_pine_mist'],effects={'verse':{'enabled':True,'kind':'glow','intensity':.3,'duration':1.2},'scene':{'enabled':True,'kind':'rain','intensity':.2},'camera':{'enabled':True,'kind':'pan','intensity':.2}},transition='light')
make('unchanged-warsh-with-new-nature','suhaim',['v17_rainbow_mist','v17_summer_clouds'])
make('new-reader-fullhd-30fps','wadee_yamani',['v17_deer_falls','v17_snowy_river'],quality='fullhd',effects={'scene':{'enabled':True,'kind':'fog','intensity':.15}},transition='mist')
def frame(name,t):
 raw=e.run_checked(['-ss',str(t),'-i',str(results[name][1]),'-frames:v','1','-f','image2pipe','-vcodec','png','pipe:1']);return np.array(Image.open(BytesIO(raw)).convert('RGB'),np.float32)
a=frame('mixed-license-control',.45);b=frame('mixed-license-effects',.45);diff=np.abs(a-b).mean(axis=2);pixel_difference={'mean_abs_rgb':float(diff.mean()),'top_1024_mean_abs_rgb':float(np.sort(diff.reshape(-1))[-1024:].mean())};assert pixel_difference['top_1024_mean_abs_rgb']>1
covered_scenes={s for row in reports for s in row['scene_ids']};assert {s['id'] for s in new_scenes}<=covered_scenes;assert {r['id'] for r in readers}<={row['reciter'] for row in reports}
report={'version':'1.7.0','completed_cases':len(reports),'all_requested_cases_completed':True,'new_scene_count_actual_mp4_exported':24,'new_reader_count_actual_mp4_exported':12,'source_audio_removed_from_backgrounds':True,'audio_matches_real_recordings':True,'source_quran_texts_unmodified':True,'legacy_cc_by_and_nps_credits_retained':True,'unchanged_separate_warsh_text_tested':True,'fullhd_1080x1920_30fps_tested':True,'effects_pixel_difference_to_control':pixel_difference,'reports':reports,'physical_android_tested':False,'real_arena_download_issue_resolved':False}
(R/'tests/library-real-mp4-matrix-v17.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
# Inspectable frames from actual encoded MP4s, not generated substitutes.
sheet=Image.new('RGB',(180*4,345*4),'#f4f1e5');d=ImageDraw.Draw(sheet)
for i,row in enumerate(reports):
 name=row['case'];pixels=frame(name,min(.8,row['duration']*.4));im=Image.fromarray(pixels.astype(np.uint8)).resize((180,320));x=(i%4)*180;y=(i//4)*345;d.text((x+4,y+3),name.replace('reader-','')[:26],fill='#244538');sheet.paste(im,(x,y+25))
sheet.save(C/'actual-mp4-frames.jpg',quality=84)
print('REAL_LIBRARY_MATRIX_COMPLETE',len(reports),'all 24 scenes and 12 readers',flush=True)
