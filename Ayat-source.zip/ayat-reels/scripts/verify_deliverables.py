"""Independent full decode, APK signature/assets and source checks; no device-test claims."""
from pathlib import Path
import os,json,hashlib,subprocess,zipfile,re,sys,gzip
import imageio_ffmpeg
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'deliverables';T=ROOT/'tests';T.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'backend'))
from version import APP_VERSION
gradle=(ROOT/'frontend/android/app/build.gradle').read_text();APK_CODE=int(re.search(r'versionCode\s+(\d+)',gradle).group(1));APK_NAME=re.search(r'versionName\s+"([^"]+)"',gradle).group(1)
TAG='v'+APP_VERSION.replace('.','')
sha=lambda b:hashlib.sha256(b).hexdigest()
xml=ROOT/'backend/data/quran-uthmani.xml';assert sha(xml.read_bytes())=='203f0f1bf3158b1e5be4ab9f8f6870e570aab6d9a626fe6192a70b75d4afe0fd'
results={}
video_paths=[(p,p.name) for p in OUT.glob('*.mp4')]
proof_file=T/'mosques-flow.json'
if proof_file.exists():
 proof=ROOT/json.loads(proof_file.read_text())['canonical_file']
 if proof.exists():video_paths.append((proof,'ayat_mosques_update.mp4'))
reader_proof=T/'requested-readers-flow.json'
if reader_proof.exists():
 for proof in json.loads(reader_proof.read_text())['proofs']:
  p=ROOT/proof['canonical_file']
  if p.exists():video_paths.append((p,'ayat_'+proof['reciter']+'_v13.mp4'))
library_proof=T/'scene-library-ui-v17.json'
if library_proof.exists():
 for proof in json.loads(library_proof.read_text()).get('proofs',[]):
  if proof.get('canonical_file') and (ROOT/proof['canonical_file']).exists():video_paths.append((ROOT/proof['canonical_file'],'Ayat-library-demo-v17.mp4'))
composition_proof=T/'composition-ui-v172.json'
if composition_proof.exists():
 for proof in json.loads(composition_proof.read_text()).get('proofs',[]):
  if proof.get('canonical_file') and (ROOT/proof['canonical_file']).exists():video_paths.append((ROOT/proof['canonical_file'],'composition-ui-api.mp4'))
video_paths=list({str(p):(p,label) for p,label in video_paths}.values())
for p,label in video_paths:
 r=subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-hide_banner','-i',str(p),'-map','0:v:0','-map','0:a:0','-f','null','-'],capture_output=True,text=True);r.check_returncode();meta={}
 for key,pattern in [('duration',r'Duration: ([\d:.]+)'),('video',r'Stream #0:0[^\n]+'),('audio',r'Stream #0:1[^\n]+')]:
  m=re.search(pattern,r.stderr);meta[key]=m.group(1) if m and key=='duration' else m.group(0) if m else None
 results[label]={'workspace_file':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'full_decode_exit':r.returncode,**meta}
(T/('final-mp4-validation-'+TAG+'.json')).write_text(json.dumps(results,indent=2))
apk=OUT/'Ayat-debug.apk';assert apk.exists()
with zipfile.ZipFile(apk) as z:
 assert z.testzip() is None
 assert z.read('assets/public/quran.json')==(ROOT/'backend/data/quran.json').read_bytes()
 warsh_raw=gzip.decompress((ROOT/'backend/data/quran-warsh-source.json.gz').read_bytes())
 assert sha(warsh_raw)=='1afd0c853e29ddfa0111731f45d46792d42d850f571b10931c31eeec9ebd8ce3'
 warsh=json.loads(z.read('assets/public/quran-warsh.json'));official=json.loads(warsh_raw)
 assert len(warsh['verses'])==6214 and warsh['sha256']=='1afd0c853e29ddfa0111731f45d46792d42d850f571b10931c31eeec9ebd8ce3'
 assert warsh['verses']=={f"{v['sura_no']}:{v['aya_no']}":v['aya_text_unicode'] for v in official}
 assert z.read('assets/public/fonts/KFGQPCWarsh.ttf')==(ROOT/'backend/fonts/KFGQPCWarsh.ttf').read_bytes()
 assert z.read('assets/public/fonts/KFGQPCWarsh-LICENSE.txt')==(ROOT/'backend/fonts/KFGQPCWarsh-LICENSE.txt').read_bytes()

 js=list((ROOT/'frontend/dist/assets').glob('*.js'));assert len(js)==1
 assert z.read('assets/public/assets/'+js[0].name)==js[0].read_bytes()
 assert b'copy-post-all' in js[0].read_bytes() and b'publication-panel' in js[0].read_bytes()
 assert any(b'copyText' in z.read(n) for n in z.namelist() if re.fullmatch(r'classes\d*\.dex',n))
 for p in (ROOT/'backend/fonts').glob('*.txt'):assert z.read('assets/public/fonts/'+p.name)==p.read_bytes()
 local_scenes=json.loads((ROOT/'backend/media/catalog.json').read_text());remote_scenes=json.loads((ROOT/'backend/media/catalog-on-demand.json').read_text());assert len(local_scenes)==48 and len(remote_scenes)==24
 assert len([n for n in z.namelist() if n.startswith('assets/public/scenes/') and n.endswith('.mp4')])==48
 assert len([n for n in z.namelist() if n.startswith('assets/public/scenes/') and n.endswith('.jpg')])==72
 bundle=json.loads(z.read('assets/public/catalog.json'))
 assert len(bundle['scenes'])==72 and len(bundle['templates'])==80 and len(bundle['reciters'])==54
 assert bundle['app_version']==APP_VERSION
 assert len(bundle['effects']['verse'])==5 and len(bundle['effects']['scene'])==6 and len(bundle['effects']['camera'])==4
 assert {x['id'] for x in bundle['effects']['transitions']}=={'cut','fade','wipeleft','slideup','light','mist'}
 assert b'scene-effects-canvas' in js[0].read_bytes() and b'fx-word-timing-warning' in js[0].read_bytes()
 assert len(bundle['effects']['verse'])==5 and len(bundle['effects']['scene'])==6 and len(bundle['effects']['camera'])==4
 assert {x['id'] for x in bundle['effects']['transitions']}=={'cut','fade','wipeleft','slideup','light','mist'}
 assert b'scene-effects-canvas' in js[0].read_bytes() and b'fx-word-timing-warning' in js[0].read_bytes()
 assert bundle['reciters']==json.loads((ROOT/'frontend/public/catalog.json').read_text())['reciters']
 requested=[r for r in bundle['reciters'] if r.get('provider')=='curated-surah']
 assert len(requested)==2 and sum(len(r['available_ranges']) for r in requested)==18
 assert len(next(r for r in requested if r['id']=='mossad')['verification_samples'])==8
 assert len(next(r for r in requested if r['id']=='suhaim')['verification_samples'])==5

 assert bundle['scenes']==local_scenes+remote_scenes
 assert all(x in js[0].read_bytes() for x in [b'scene-history-panel',b'reset-scene-history',b'scene-library-v17',b'publisher-timing-v1',b'scene-cache-button',b'composition-preview',b'compact-ink-v1',b'composition-verse-block',b'export-recovery',b'reconnect-export',b'X-Ayat-Request-Id',b'ayat.activeJobSnapshot.v1'])
 assert len([r for r in bundle['reciters'] if r.get('provider')=='publisher-timed'])==12
 assert all(x['kind'] in ['real-footage','original-motion-video'] for x in bundle['scenes'])
 assert z.read('assets/public/SCENE_CREDITS.txt')==(ROOT/'backend/media/SCENE_CREDITS.txt').read_bytes()
 for scene in bundle['scenes']:
  name='assets/public/scenes/'+scene['id']+'.mp4'
  if scene.get('availability')=='on-demand':
   assert name not in z.namelist() and sha(z.read('assets/public/scenes/'+scene['id']+'.jpg'))==scene['poster_sha256']
  else:assert sha(z.read(name))==scene['sha256']
 assert not any(n.endswith('.mp3') for n in z.namelist())
 assert any(b'Lorg/ayat/reels/VideoFilesPlugin;' in z.read(n) for n in z.namelist() if re.fullmatch(r'classes\d*\.dex',n))
 assert z.read('assets/public/THIRD_PARTY_NOTICES.txt')==(ROOT/'frontend/public/THIRD_PARTY_NOTICES.txt').read_bytes()
env=os.environ.copy();cached=Path.home()/'.cache/ayat-android/env.json'
if cached.exists():env.update(json.loads(cached.read_text()))
if env.get('JAVA_HOME'):env['PATH']=str(Path(env['JAVA_HOME'])/'bin')+os.pathsep+env['PATH']
if env.get('ANDROID_HOME'):
 sdk=Path(env['ANDROID_HOME'])
 for tool,args,name in [('apksigner',['verify','--verbose','--print-certs',str(apk)],'apk-signature.txt'),('aapt',['dump','badging',str(apk)],'apk-badging.txt')]:
  r=subprocess.run([str(sdk/'build-tools/35.0.0'/tool),*args],env=env,capture_output=True,text=True);r.check_returncode();(T/name).write_text(r.stdout+r.stderr)
  if tool=='apksigner':assert 'bd992a4a44969b018a1c7b469d2225e5cfb711284a5b93a4f83f3ed3ff8d3db5' in r.stdout
  if tool=='aapt':assert f"versionCode='{APK_CODE}'" in r.stdout and f"versionName='{APK_NAME}'" in r.stdout
report={'apk_bytes':apk.stat().st_size,'apk_sha256':sha(apk.read_bytes()),'embedded_web_js':js[0].name,'embedded_js_sha256':sha(js[0].read_bytes()),'quran_bundle_matches':True,'separate_warsh_6214_exact_verses':True,'official_warsh_font_unmodified':True,'native_plugin_class_present':True,'publication_panel_bundled':True,'native_clipboard_method_present':True,'visual_effects_library_bundled':True,'verse_fx_modes':5,'scene_fx_modes':6,'camera_fx_modes':4,'transition_modes':6,'visual_effects_library_bundled':True,'verse_fx_modes':5,'scene_fx_modes':6,'camera_fx_modes':4,'transition_modes':6,'version':APP_VERSION,'version_code':APK_CODE,'compact_composition_preview_bundled':True,'composition_version':'compact-ink-v1','connection_recovery_ui_bundled':True,'local_export_snapshot_bundled':True,'single_flight_job_monitor_bundled':True,'motion_files':48,'registered_scenes':len(bundle['scenes']),'bundled_background_videos':48,'on_demand_recorded_videos':24,'scene_posters':72,'scene_history_and_nondestructive_reset_bundled':True,'publisher_timed_new_readers':12,'recorded_mosque_files':sum(s.get('subject')=='mosque' for s in bundle['scenes']),'real_nature_files':sum(s['kind']=='real-footage' and s.get('subject')!='mosque' for s in bundle['scenes']),'catalog_templates':80,'catalog_readers':54,'curated_recordings':13,'curated_verse_clips':124,'curated_available_ranges':18,'complete_font_notices':True,'no_reciter_mp3_bundled':True,'physical_android_tested':False,'lint_completed':False}
(T/('apk-verification-'+TAG+'.json')).write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));print('FULL_DECODED_MP4S',len(results))
