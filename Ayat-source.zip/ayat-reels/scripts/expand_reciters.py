"""Verify official EveryAyah directories and actual MP3 decoding before adding 24 readers."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import requests,json,hashlib,subprocess
import numpy as np
import imageio_ffmpeg
R=Path(__file__).resolve().parents[1];FF=imageio_ffmpeg.get_ffmpeg_exe();C=Path.home()/'.cache/ayat-reader-probes';C.mkdir(parents=True,exist_ok=True)
source=json.loads((R/'docs/sources/everyayah-recitations.js').read_text());official={v['subfolder']:v for v in source.values() if isinstance(v,dict) and 'subfolder' in v}
rows=[
 ('alafasy','مشاري العفاسي','Alafasy_128kbps'),('husary','محمود خليل الحصري','Husary_128kbps'),('minshawi','محمد صديق المنشاوي','Minshawy_Murattal_128kbps'),
 ('abdulbasit','عبد الباسط عبد الصمد','Abdul_Basit_Murattal_192kbps'),('sudais','عبد الرحمن السديس','Abdurrahmaan_As-Sudais_192kbps'),('shuraym','سعود الشريم','Saood_ash-Shuraym_128kbps'),('maher','ماهر المعيقلي','MaherAlMuaiqly128kbps'),('yasser','ياسر الدوسري','Yasser_Ad-Dussary_128kbps'),('qatami','ناصر القطامي','Nasser_Alqatami_128kbps'),('ghamdi','سعد الغامدي','Ghamadi_40kbps'),('ajamy','أحمد العجمي','ahmed_ibn_ali_al_ajamy_128kbps'),('shaatri','أبو بكر الشاطري','Abu_Bakr_Ash-Shaatree_128kbps'),('hani','هاني الرفاعي','Hani_Rifai_192kbps'),('hudhaify','علي الحذيفي','Hudhaify_128kbps'),('ayyoub','محمد أيوب','Muhammad_Ayyoub_128kbps'),('jibreel','محمد جبريل','Muhammad_Jibreel_128kbps'),('basfar','عبد الله بصفر','Abdullah_Basfar_192kbps'),('matroud','عبد الله المطرود','Abdullah_Matroud_128kbps'),('bukhatir','صلاح بوخاطر','Salaah_AbdulRahman_Bukhatir_128kbps'),('juhany','عبد الله الجهني','Abdullaah_3awwaad_Al-Juhaynee_128kbps'),('budair','صلاح البدير','Salah_Al_Budair_128kbps'),('banna','محمود علي البنا','mahmoud_ali_al_banna_32kbps'),('ali_jaber','علي عبد الله جابر','Ali_Jaber_64kbps'),('fares_abbad','فارس عباد','Fares_Abbad_64kbps'),('tablawy','محمد محمود الطبلاوي','Mohammad_al_Tablaway_128kbps'),('qasim','عبد المحسن القاسم','Muhsin_Al_Qasim_192kbps'),('neana','أحمد نعينع','Ahmed_Neana_128kbps'),('abdulkareem','محمد عبد الكريم','Muhammad_AbdulKareem_128kbps'),('tunaiji','خليفة الطنيجي','khalefa_al_tunaiji_64kbps'),('qahtani','خالد عبد الله القحطاني','Khaalid_Abdullaah_al-Qahtaanee_192kbps'),('suesy','علي حجاج السويسي','Ali_Hajjaj_AlSuesy_128kbps'),('sahl','سهل ياسين','Sahl_Yassin_128kbps'),('salama','ياسر سلامة','Yaser_Salamah_128kbps'),('akram','أكرم العلاقمي','Akram_AlAlaqimy_128kbps'),('sowaid','أيمن سويد','Ayman_Sowaid_64kbps'),('mansoori','كريم منصوري','Karim_Mansoori_40kbps'),('aziz','عزيز عليلي','aziz_alili_128kbps'),('mustafa','مصطفى إسماعيل','Mustafa_Ismail_48kbps'),('parhizgar','شهريار برهيزكار','Parhizgar_48kbps'),('akhdar','إبراهيم الأخضر','Ibrahim_Akhdar_32kbps')]
def verify(row):
 ident,name,folder=row;assert folder in official,folder;assert 'warsh' not in folder.lower() and 'translations' not in folder.lower()
 probes=[]
 for filename in ['001001','112001']:
  url=f'https://everyayah.com/data/{folder}/{filename}.mp3';path=C/(ident+'_'+filename+'.mp3')
  if not path.exists():response=requests.get(url,timeout=45);response.raise_for_status();path.write_bytes(response.content)
  assert path.stat().st_size>1000
  p=subprocess.run([FF,'-v','error','-i',str(path),'-f','f32le','-ac','1','-ar','16000','pipe:1'],capture_output=True);p.check_returncode();audio=np.frombuffer(p.stdout,np.float32);assert len(audio)>1600 and np.max(np.abs(audio))>.001
  probes.append({'url':url,'bytes':path.stat().st_size,'duration':len(audio)/16000,'peak':float(np.max(np.abs(audio))),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'full_decode_exit':p.returncode})
 bitrate=official[folder]['bitrate'];result={'id':ident,'name':name,'detail':'تلاوة آية بآية · '+bitrate,'folder':folder,'bitrate':bitrate,'source':'https://everyayah.com/recitations_ayat.html','verification_samples':probes}
 print('READER_VERIFIED',ident,name,flush=True);return result
with ThreadPoolExecutor(max_workers=4) as pool:readers=list(pool.map(verify,rows))
(R/'backend/data/reciters.json').write_text(json.dumps(readers,ensure_ascii=False,indent=2));(R/'tests/reader-verification.json').write_text(json.dumps(readers,ensure_ascii=False,indent=2));print('READERS_READY',len(readers))
