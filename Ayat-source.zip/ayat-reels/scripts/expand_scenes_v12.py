"""Curated recorded footage only. Fetch published derivatives politely; retain provenance.
No AI footage, generated mosque substitutes, animated photographs, source audio, or CC BY-SA.
"""
from pathlib import Path
import sys,json,hashlib,html,re,time,subprocess,requests
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'backend'))
import imageio_ffmpeg
FF=imageio_ffmpeg.get_ffmpeg_exe();MEDIA=ROOT/'backend/media'
CACHE=Path('/home/user/.cache/ayat-scenes-v12');CACHE.mkdir(parents=True,exist_ok=True)
UA={'User-Agent':'AyatReels/1.2 (curated educational video editor; source/license verification)'}
SPECS=[
 ('haram_night','الطواف ليلًا','الحرم المكي',['ليل','سكينة'],'File:Kaaba at Night (video) - Sep 28, 2016.webm',6,'Kaaba at Night (2016)'),
 ('haram_night_bridge','الحرم من الجسر','الحرم المكي',['ليل','سكينة'],'File:Kaaba at Night (video) - Sep 28, 2016.webm',30,'Kaaba at Night (2016)'),
 ('haram_ramadan','الحرم في رمضان','الحرم المكي',['نور','سكينة'],'File:Makkah Al-Mukarramah -Kaaba- Ramadan 2016.webm',10,'Makkah / Kaaba, Ramadan 2016'),
 ('haram_ramadan_tawaf','حركة المطاف','الحرم المكي',['نور','سكينة'],'File:Makkah Al-Mukarramah -Kaaba- Ramadan 2016.webm',52,'Makkah / Kaaba, Ramadan 2016'),
 ('haram_close_tawaf','إيقاع الطواف','الحرم المكي',['نور','سكينة'],'File:Great Mosque of Mecca (video) - Mar 18, 2015.webm',12,'Great Mosque of Mecca (2015)'),
 ('haram_courtyard','ساحات الحرم','الحرم المكي',['نور','سكينة'],'File:Great Mosque of Mecca (video) - Mar 18, 2015.webm',65,'Great Mosque of Mecca (2015)'),
 ('haram_day','الكعبة نهارًا','الحرم المكي',['نور','سكينة'],'File:Great Mosque of Mecca (4k video) - May 27, 2014.webm',7,'Great Mosque of Mecca (2014)'),
 ('haram_day_wide','نور البيت العتيق','الحرم المكي',['نور','سكينة'],'File:Great Mosque of Mecca (4k video) - May 27, 2014.webm',35,'Great Mosque of Mecca (2014)'),
 ('aqsa_courtyard','ساحات الأقصى','المسجد الأقصى',['سكينة','نور'],'File:Rare Indoor footage Dome of Rock Mosque, Old City, Jerusalem.webm',46,'Dome of Rock (2013)'),
 ('dome_rock_inside','داخل قبة الصخرة','قبة الصخرة',['سكينة','نور'],'File:Rare Indoor footage Dome of Rock Mosque, Old City, Jerusalem.webm',82,'Dome of Rock (2013)'),
 ('putra_mosque','مسجد بُترا','مساجد العالم',['سكينة','نور'],'File:Masjidputra4k.webm',3,'Putra Mosque'),
 ('putra_mosque_water','بُترا والماء','مساجد العالم',['سكينة','طبيعة'],'File:Masjidputra4k.webm',17,'Putra Mosque'),
 ('kondotty_mosque','مسجد كوندوتي','مساجد العالم',['سكينة','نور'],'File:Kondotty Pazhangadi Juma Masjid.ogv',0,'Kondotty Pazhangadi Juma Masjid'),
 ('bursa_mosque','جامع بورصة الكبير','مساجد العالم',['سكينة','ليل'],'File:Bursa Ulucamii (Grand Mosque) Timelapse.webm',12,'Bursa Grand Mosque Timelapse'),
 ('qolsharif_mosque','مسجد قول شريف','مساجد العالم',['سكينة','نور'],'File:Drone Kremlin Kazan - Qolsharif Mosque - DJI Inspire 1 Drone (Казань).webm',25,'Qolsharif Mosque, Kazan'),
 ('umayyad_mosque','الجامع الأموي','مساجد العالم',['سكينة','نور'],'File:Umayyad Mosque of Damascus, Syria (2009).webm',25,'Umayyad Mosque, Damascus (2009)'),
 ('skaha_lake','صفاء بحيرة سكاها','بحيرات',['سكينة','طبيعة'],'File:Lake Skaha on a Calm Winter Afternoon.webm',2,'Lake Skaha on a Calm Winter Afternoon'),
 ('autumn_reeds','قصب الخريف','غروب',['نور','طبيعة'],'File:Autumn Cattails at Sunset in East Kelowna, British Columbia, Canada.webm',2,'Autumn Cattails at Sunset'),
 ('winter_clouds','سحب فوق الجبل','جبال',['سكينة','طبيعة'],'File:Winter Timelapse of Clouds Roiling over Rimrock on Okanagan Mountain.webm',12,'Winter Clouds over Okanagan Mountain'),
 ('open_sea','موج البحر المفتوح','بحر',['سكينة','طبيعة'],'File:Ocean in Sommaroy.webm',2,'Ocean in Sommaroy, Norway'),
 ('stream_grasses','نسيم الجدول','غابات',['سكينة','طبيعة'],'File:The wind plays with grasses by a stream in Nickel Plate Park.webm',2,'Grasses by a stream in Nickel Plate Park'),
 ('lavender_field','لافندر ونسيم','زهور',['نور','طبيعة'],'File:Lavender - 17156.webm',2,'Lavender'),
 ('wildflowers_bee','أزهار البرية','زهور',['نور','طبيعة'],'File:Bumblebee on flowers.webm',1,'Bumblebee on flowers'),
 ('green_mountains','آفاق الجبال الخضراء','جبال',['نور','طبيعة'],'File:Chorla ghat sep 2020.ogv',2,'Chorla Ghat, September 2020'),
]
META=ROOT/'docs/sources/scenes-v12-source-metadata.json'
if META.exists():data=json.loads(META.read_text())
else:
 response=requests.get('https://commons.wikimedia.org/w/api.php',params={'action':'query','format':'json','titles':'|'.join(dict.fromkeys(s[4] for s in SPECS)),'prop':'videoinfo|revisions','viprop':'url|size|extmetadata|derivatives','rvprop':'ids|timestamp'},headers=UA,timeout=60)
 response.raise_for_status();data=response.json();META.write_text(json.dumps(data,ensure_ascii=False,indent=2))
PAGES={p['title']:p for p in data['query']['pages'].values()}
OVERRIDES=ROOT/'docs/sources/scenes-v12-curation.json'
curation=json.loads(OVERRIDES.read_text()) if OVERRIDES.exists() else {}

def checked(args):
 r=subprocess.run([FF,'-hide_banner','-y','-v','error',*args],capture_output=True,timeout=180)
 if r.returncode:raise RuntimeError(r.stderr.decode('utf8','replace')[-1500:])
 return r.stdout

def source_file(title,page,video):
 key=hashlib.sha256(title.encode()).hexdigest()[:16];local=CACHE/(key+'.webm');record=CACHE/(key+'.source.json')
 if local.exists() and record.exists():return local,json.loads(record.read_text())['url']
 source=video['url'].split('?')[0]
 variants=[d for d in video.get('derivatives',[]) if d.get('transcodekey','').endswith('vp9.webm') and d.get('height',0)>=480 and d.get('width',0)>=270]
 if variants:source=min(variants,key=lambda d:d.get('bandwidth',10**12))['src'].split('?')[0]
 cool=CACHE/'retry-after.json'
 if cool.exists():
  wait=max(0,json.loads(cool.read_text())['not_before']-time.time())
  if wait:print('RESPECTING_PROVIDER_COOLDOWN',round(wait),flush=True);time.sleep(wait)
 for attempt in range(6):
  with requests.get(source,headers=UA,stream=True,timeout=120) as r:
   if r.status_code in (429,503) and attempt<5:
    try:retry=int(r.headers.get('Retry-After','30'))
    except ValueError:retry=60
    delay=max(retry,30*(attempt+1));cool.write_text(json.dumps({'not_before':time.time()+delay}))
    print('PROVIDER_BACKOFF',r.status_code,delay,title,flush=True);r.close();time.sleep(delay);continue
   r.raise_for_status();part=local.with_suffix('.part')
   with part.open('wb') as output:
    for chunk in r.iter_content(128*1024):
     output.write(chunk);time.sleep(.32)
   expected=r.headers.get('Content-Length')
   if expected and part.stat().st_size!=int(expected):raise RuntimeError('Incomplete source footage')
   part.replace(local);record.write_text(json.dumps({'url':source}));break
 else:raise RuntimeError('Provider download not completed')
 print('SOURCE_READY',title,local.stat().st_size,flush=True);time.sleep(4)
 return local,source

def build(spec):
 sid,name,category,moods,title,start,credit_title=spec
 opts=curation.get(sid,{})
 if opts.get('exclude'):print('CURATION_REJECTED',sid,opts.get('reason'),flush=True);return None
 start=opts.get('source_start',start);name=opts.get('name',name);category=opts.get('category',category)
 p=PAGES[title];v=p['videoinfo'][0];m=v['extmetadata'];lic=m['LicenseShortName']['value']
 assert lic in ['CC0','CC BY 3.0'],(title,lic)
 assert not any(x in m.get('Categories',{}).get('value','').lower() for x in ['ai-generated','computer-generated','animated photographs']),title
 original,source=source_file(title,p,v)
 dest=MEDIA/(sid+'.mp4');poster=MEDIA/(sid+'.jpg');signature=hashlib.sha256(json.dumps([title,start,opts],sort_keys=True).encode()).hexdigest()
 marker=CACHE/(sid+'.encode.json')
 if not (dest.exists() and marker.exists() and json.loads(marker.read_text()).get('signature')==signature):
  focus=opts.get('focus',[.5,.5]);vf=f'scale=540:960:force_original_aspect_ratio=increase,crop=540:960:(iw-ow)*{focus[0]}:(ih-oh)*{focus[1]},setsar=1,fps=24'
  checked(['-stream_loop','-1','-ss',str(start),'-i',str(original),'-t','6','-vf',vf,'-an','-c:v','libx264','-preset','fast','-b:v','320k','-maxrate','420k','-bufsize','640k','-pix_fmt','yuv420p','-threads','1','-movflags','+faststart',str(dest)])
  marker.write_text(json.dumps({'signature':signature}))
 checked(['-ss','1.2','-i',str(dest),'-frames:v','1','-q:v','5',str(poster)])
 frames=[np.frombuffer(checked(['-ss',str(t),'-i',str(dest),'-frames:v','1','-vf','scale=90:160','-f','rawvideo','-pix_fmt','rgb24','pipe:1']),np.uint8).astype(float) for t in [1,3]]
 motion=float(np.abs(frames[0]-frames[1]).mean())
 if motion<=.15:print('REQUIRES_MOTION_REVIEW',sid,round(motion,4),flush=True)
 checked(['-i',str(dest),'-f','null','-'])
 author=html.unescape(re.sub('<[^>]+>','',m.get('Artist',{}).get('value','Wikimedia Commons contributor'))).strip();author=re.sub(r'\s*\[\d+\]\s*$','',author)
 record={'id':sid,'name':name,'category':category,'moods':moods,'duration':6,'width':540,'height':960,'fps':24,'kind':'real-footage','subject':'mosque' if SPECS.index(spec)<16 else 'nature','license':'CC0-1.0' if lic=='CC0' else 'CC-BY-3.0','license_url':m['LicenseUrl']['value'],'requires_attribution':lic!='CC0','copyright_notice':opts.get('copyright_notice'),'author':author,'source_url':v['descriptionurl'],'source_short_url':f'https://commons.wikimedia.org/?curid={p["pageid"]}','source_title':title,'source_credit_title':credit_title,'download_url':source,'source_revision':p.get('revisions',[{}])[0].get('revid'),'source_start':start,'source_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'video':f'/api/media/{sid}.mp4','poster':f'/api/media/{sid}.jpg','motion_difference':round(motion,6),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'adaptation':f'6-second excerpt beginning at {start}s, source audio removed, cropped to 9:16, scaled and encoded as H.264. Recorded footage, not animated photographs or AI generation.','curation':opts.get('review','Pending visual review before shipping')}
 print('SCENE_ENCODED',sid,dest.stat().st_size,'motion',round(motion,3),flush=True)
 return record

def main():
 records=[]
 for spec in SPECS:
  record=build(spec)
  if record:records.append(record)
 new_ids={s[0] for s in SPECS};old=json.loads((MEDIA/'catalog.json').read_text());retired={'haram_timelapse','haram_timelapse_wide','quinault_lake','mountain_aerial'};catalog=[s for s in old if s['id'] not in new_ids|retired]+records
 for sid in retired:
  for ext in ['mp4','jpg']:(MEDIA/(sid+'.'+ext)).unlink(missing_ok=True)
 (MEDIA/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2))
 third=[s for s in catalog if s.get('source_url')]
 (MEDIA/'THIRD_PARTY_SCENES.json').write_text(json.dumps(third,ensure_ascii=False,indent=2))
 credits='Curated moving footage. NOT all assets are CC0. Each record specifies its own license.\nCC BY 3.0 footage requires attribution; the renderer burns credits into exported videos, includes MP4 metadata and writes a NOTICE.txt.\nNo source video audio retained. No animated photographs or generated substitutes for real sacred sites.\n\n'+'\n\n'.join(f"{x['name']} / {x['source_title']}\nAuthor: {x['author']}\nCopyright notice: {x.get('copyright_notice') or ''}\nLicense: {x['license']} — {x['license_url']}\nSource: {x['source_url']}\nChanges: {x['adaptation']}" for x in third)
 (MEDIA/'SCENE_CREDITS.txt').write_text(credits);(ROOT/'frontend/public/SCENE_CREDITS.txt').write_text(credits)
 (ROOT/'tests/scenes-v12-assets.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
 print('SCENE_LIBRARY_READY',len(catalog),'total;',len(records),'new recorded clips',flush=True)
if __name__=='__main__':main()
