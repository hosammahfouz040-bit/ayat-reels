"""Development-only acoustic timing probes. Never supplies or rewrites Quran text.
Requires optional faster-whisper; runtime uses only reviewed, pinned timing records.
Recognition output is scratch-only under .cache and is NEVER a Quran text source.
"""
from pathlib import Path
import os,json,hashlib,zipfile,re,unicodedata,subprocess,time
from difflib import SequenceMatcher
import requests,numpy as np,imageio_ffmpeg
ROOT=Path(__file__).resolve().parents[1]
CACHE=Path.home()/'.cache/ayat-requested-readers';CACHE.mkdir(parents=True,exist_ok=True)
os.environ.setdefault('HF_HOME',str(CACHE/'hf'))
from faster_whisper import WhisperModel
FF=imageio_ffmpeg.get_ffmpeg_exe()
HAFS=json.loads((ROOT/'backend/data/quran.json').read_text())['verses']
with zipfile.ZipFile(CACHE/'kfgqpc_warsh_v30.zip') as z:
 WARSH={f"{r['sura_no']}:{r['aya_no']}":r['aya_text_unicode'] for r in json.loads(z.read('kfgqpc_warsh_v30-data/kfgqpc_warsh_v30.json'))}
TRACKS=[
 ('mossad',112,'hafs','https://media.way2quran.com/abdul-rahman-musaad/hafs-an-asim/112.mp3'),
 ('mossad',113,'hafs','https://media.way2quran.com/abdul-rahman-musaad/hafs-an-asim/113.mp3'),
 ('mossad',114,'hafs','https://media.way2quran.com/abdul-rahman-musaad/hafs-an-asim/114.mp3'),
 ('mossad',100,'hafs','https://media.way2quran.com/abdul-rahman-musaad/hafs-an-asim/100.mp3'),
 ('mossad',107,'hafs','https://media.way2quran.com/abdul-rahman-musaad/hafs-an-asim/107.mp3'),
 ('suhaim',1,'warsh','https://cdn.mp3quran.net/audio/abdelaziz-sheim/r1/001.mp3'),
 ('suhaim',112,'warsh','https://cdn.mp3quran.net/audio/abdelaziz-sheim/r1/112.mp3'),
 ('suhaim',87,'warsh','https://cdn.mp3quran.net/audio/abdelaziz-sheim/r1/087.mp3'),
]
def norm(s):
 # Analysis-only transliteration for matching acoustic words. Stored source stays byte-exact.
 s=s.split('۝')[0].replace('ٰ','ا').translate(str.maketrans({chr(n):'ا' for n in range(0x870,0x87a)}))
 s=s.translate(str.maketrans({'ٱ':'ا','ى':'ي','ے':'ي','ی':'ي','ؤ':'و','ئ':'ي','أ':'ا','إ':'ا','آ':'ا'}))
 s=''.join(c for c in unicodedata.normalize('NFKD',s) if not unicodedata.category(c).startswith('M'))
 return re.sub('[^ء-ي]','',s)
print('LOADING_ACOUSTIC_MODEL_NOT_A_TEXT_SOURCE',flush=True)
model=WhisperModel('small',device='cpu',compute_type='int8',cpu_threads=2,num_workers=1,download_root=str(CACHE/'models'))
print('ACOUSTIC_MODEL_READY',flush=True)
for ident,surah,narration,url in TRACKS:
 name=f'{ident}-{surah:03}';mp3=CACHE/(name+'.mp3');wave=CACHE/(name+'.wav');report=CACHE/(name+'-recognition.json')
 if not mp3.exists():
  r=requests.get(url,timeout=60);r.raise_for_status();assert len(r.content)>1000;mp3.write_bytes(r.content)
 subprocess.run([FF,'-v','error','-y','-i',str(mp3),'-ac','1','-ar','16000','-c:a','pcm_s16le',str(wave)],check=True)
 if not report.exists():
  import soundfile as sf
  samples,sample_rate=sf.read(wave,dtype='float32');assert sample_rate==16000
  segments,info=model.transcribe(samples,language='ar',beam_size=5,word_timestamps=True,vad_filter=False,condition_on_previous_text=False,temperature=0)
  words=[{'word':w.word,'start':w.start,'end':w.end,'probability':w.probability} for s in segments for w in s.words or []]
  report.write_text(json.dumps({'words':words},ensure_ascii=False,indent=2))
 else:words=json.loads(report.read_text())['words']
 source=WARSH if narration=='warsh' else HAFS
 keys=[k for k in source if k.startswith(str(surah)+':')];keys.sort(key=lambda k:int(k.split(':')[1]))
 reference='';by_verse={}
 for key in keys:
  text=norm(source[key]);by_verse[key]=(len(reference),len(reference)+len(text));reference+=text
 hypothesis='';char_words=[]
 for i,w in enumerate(words):
  n=norm(w['word']);hypothesis+=n;char_words.extend([i]*len(n))
 pairs={}
 for a,b,size in SequenceMatcher(None,reference,hypothesis,autojunk=False).get_matching_blocks():
  for j in range(size):pairs[a+j]=char_words[b+j]
 spans=[]
 for key,(a,b) in by_verse.items():
  found=[pairs[j] for j in range(a,b) if j in pairs];coverage=len(found)/(b-a)
  spans.append({'key':key,'coverage':coverage,'start':words[min(found)]['start'] if found else None,'end':words[max(found)]['end'] if found else None,'first_word_index':min(found) if found else None,'last_word_index':max(found) if found else None})
 result={'id':ident,'surah':surah,'narration':narration,'url':url,'sha256':hashlib.sha256(mp3.read_bytes()).hexdigest(),'bytes':mp3.stat().st_size,'character_match_ratio':len(pairs)/len(reference),'spans':spans,'method':'Acoustic recognition matched against immutable official reference solely to propose verse boundaries; not a text source; review required before registration.'}
 (CACHE/(name+'-proposed-timing.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print('TIMING_PROPOSAL',name,json.dumps(result,ensure_ascii=False),flush=True)
print('TIMING_PROBES_COMPLETED',flush=True)
