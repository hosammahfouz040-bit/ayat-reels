"""Two-phase real server interruption test. Start API, run 'begin'; stop/restart it, run 'verify'."""
from pathlib import Path
import json,sys,time,uuid,requests
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'backend'))
from models import ProjectConfig
FILE=ROOT/'tests/interruption-integration.json';BASE='http://127.0.0.1:8000/api'
if sys.argv[1]=='begin':
 ws=str(uuid.uuid4());headers={'X-Workspace-Id':ws}
 config=ProjectConfig(to_ayah=4,reciter='husary',quality='fullhd').model_dump()
 r=requests.post(BASE+'/jobs',headers=headers,json={'config':config,'one_click':True},timeout=30);r.raise_for_status();j=r.json();begin=time.monotonic()
 while time.monotonic()-begin<90:
  r=requests.get(BASE+'/jobs/'+j['id'],headers=headers,timeout=15);r.raise_for_status();j=r.json()
  if j['state']=='rendering' and j['progress']>=65:
   FILE.write_text(json.dumps({'workspace':ws,'original_job':j,'observed_during_actual_encoding':True},ensure_ascii=False,indent=2));print('STOP_API_NOW',j['id'],j['progress'],j['stage'],flush=True);break
  if j['state'] in ['failed','completed','canceled']:raise RuntimeError(j)
  time.sleep(.15)
 else:raise TimeoutError('The job did not reach actual encoding.')
elif sys.argv[1]=='verify':
 data=json.loads(FILE.read_text());headers={'X-Workspace-Id':data['workspace']};jid=data['original_job']['id']
 r=requests.get(BASE+'/jobs/'+jid,headers=headers,timeout=30);r.raise_for_status();j=r.json();data['after_restart']=j;assert j['state']=='interrupted',j
 r=requests.get(BASE+'/projects/'+j['project_id'],headers=headers,timeout=30);r.raise_for_status();assert r.json()['config']==j['config'];data['project_restored']=True
 partial=ROOT/'backend/runtime/exports'/jid/'result.partial.mp4';assert not partial.exists();data['partial_cleaned']=True
 r=requests.post(BASE+'/jobs/'+jid+'/retry',headers=headers,timeout=30);r.raise_for_status();retry=r.json();start=time.monotonic()
 while time.monotonic()-start<180:
  r=requests.get(BASE+'/jobs/'+retry['id'],headers=headers,timeout=30);r.raise_for_status();retry=r.json()
  if retry['state']=='completed':break
  if retry['state'] in ['failed','interrupted','canceled']:raise RuntimeError(retry)
  time.sleep(.6)
 assert retry['state']=='completed',retry
 r=requests.get(BASE+'/jobs/'+retry['id']+'/file',headers=headers,timeout=60);r.raise_for_status();assert len(r.content)>5000 and r.content[4:8]==b'ftyp'
 data['successful_retry']=retry;data['download_bytes']=len(r.content);FILE.write_text(json.dumps(data,ensure_ascii=False,indent=2));print('INTERRUPTION_RETRY_PASSED',retry['id'],len(r.content))
else:raise SystemExit('Choose begin or verify.')
