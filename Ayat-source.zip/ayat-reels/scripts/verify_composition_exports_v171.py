"""Validate real MP4 composition pixels, not only layout JSON or frontend CSS.
Genuine recordings + unchanged Quran. Temporary encodes stay in excluded cache.
Pre-fix engine snapshot is optional and used only for an actual before/after control.
"""
from pathlib import Path
from io import BytesIO
import sys,json,time,hashlib,subprocess,importlib.util
import numpy as np,soundfile as sf
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'backend'))
import media_engine as e
from models import ProjectConfig,SceneClip
from catalog import TEMPLATES
from quran import QURAN
C=Path.home()/'.cache/ayat-layout-171/real-matrix';C.mkdir(parents=True,exist_ok=True);e.EXPORTS=C
reports=[];exports={}

def frame(path,t):
 data=e.run_checked(['-ss',str(t),'-i',str(path),'-frames:v','1','-f','image2pipe','-vcodec','png','pipe:1']);return Image.open(BytesIO(data)).convert('RGB')

def visible_ratio(image,mask,color,tolerance=90):
 a=np.asarray(image,dtype=float);alpha=np.asarray(mask);probe=e.glyph_mask_probe(mask)
 if not probe:return 0
 m=alpha>probe['alpha_threshold'];foreground=np.array(e.rgb(color));worst=float(np.linalg.norm(np.maximum(foreground,255-foreground)));allowed=tolerance+np.maximum(0,245-alpha[m].astype(float))/255*worst
 return float(np.mean(np.linalg.norm(a[m]-foreground,axis=1)<allowed)) if m.sum() else 0

def expected_masks(config,page,w,h):
 data=page['layout'];masks={key:e.metadata_graphics(config,data,w,h,component=key,opaque=False).getchannel('A') for key in ['surah','reader','source']}
 cue={'number':config.from_ayah,'text':' '.join(r['text'] for r in data['verse']['lines']),'render_font_size':data['verse']['font_size'],'layout':data}
 masks['verse']=e.text_graphics(config,cue,[r['text'] for r in data['verse']['lines']],w,h,data)[2]
 return masks

def run(name,config):
 started=time.time();p=e.prepare_audio(config.surah,config.from_ayah,config.to_ayah,config.reciter);file=C/name/'result.mp4'
 if '--verify-existing' in sys.argv:
  audit=json.loads((file.parent/'audit.json').read_text())
  def comparable(data):
   data=json.loads(json.dumps(data))
   for clip in data['clips']:clip.pop('id',None)
   return data
  assert comparable(audit['config'])==comparable(config.model_dump()),'Saved encode does not match the requested test.'
  result=audit['result']
 else:
  result=e.render(config,p,name,lambda *args:None,lambda:False,lambda proc:None);audit=json.loads((file.parent/'audit.json').read_text())
 assert result['text_layout_version']=='compact-ink-v1' and audit['all_cues_match_source']
 decoded=subprocess.run([e.FFMPEG,'-v','error','-i',str(file),'-map','0:v:0','-map','0:a:0','-f','null','-'],capture_output=True);assert decoded.returncode==0
 expected,sr=sf.read(e.AUDIO/p['id']/'combined.wav',dtype='float32');actual=np.frombuffer(e.run_checked(['-i',str(file),'-vn','-ac','1','-ar','48000','-f','f32le','pipe:1']),np.float32);n=min(len(expected),len(actual));corr=float(np.corrcoef(expected[:n],actual[:n])[0,1]);assert sr==48000 and corr>.95
 pixel_pages=[]
 for page in audit['text_composition']['pages']:
  data=page['layout'];t=page['start']+(page['end']-page['start'])*.65;image=frame(file,t);w,h=image.size;masks=expected_masks(config,page,w,h);scores={key:visible_ratio(image,mask,config.text_style.color) for key,mask in masks.items()};assert min(scores['verse'],scores['surah'],scores['reader'])>.60,(name,page['page'],scores)
  assert data['surah']['ink_bbox'][3]<data['verse_box'][1]<data['verse_box'][3]<data['reader']['ink_bbox'][1]<data['source']['ink_bbox'][1]
  assert data['group_bbox'][1]>=h*.105-.1 and data['group_bbox'][3]<=h*.875+.1
  pixel_pages.append({'verse_key':page['key'],'page':page['page'],'sample_time':t,'actual_mp4_component_visible_ratios':scores,'group_bbox':data['group_bbox'],'reader_gap_from_box':data['reader']['ink_bbox'][1]-data['verse_box'][3],'surah_gap_from_box':data['verse_box'][1]-data['surah']['ink_bbox'][3],'font_sizes':{k:data[k]['font_size'] for k in ['verse','surah','reader','source']}})
  if len(pixel_pages)<=4:image.resize((270,480)).save(file.parent/f'actual-page-{len(pixel_pages)}.jpg',quality=90)
 row={'case':name,'reciter':config.reciter,'surah':config.surah,'range':[config.from_ayah,config.to_ayah],'narration':config.narration,'quality':config.quality,'template_id':config.template_id,'alignment':config.text_style.alignment,'font':e.quran_font(config),'font_size_requested':config.text_style.size,'line_height_requested':config.text_style.line_height,'duration':result['duration'],'width':result['width'],'height':result['height'],'fps':result['fps'],'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'full_decode_exit':0,'source_quran_exact':True,'source_quran_sha256':result['source_sha256'],'original_recording_audio_correlation':corr,'animated_overlay':audit['animated_overlay_stream'],'pixel_checks':pixel_pages,'page_count':len(pixel_pages),'cache_file':str(file),'seconds':round(time.time()-started,3),'existing_genuine_encode_rechecked':'--verify-existing' in sys.argv}
 reports.append(row);exports[name]=(config,p,result,file,audit);(R/'tests/composition-real-mp4-v171.json').write_text(json.dumps({'version':'1.7.1','all_cases_completed':False,'cases':reports},ensure_ascii=False,indent=2));print('REAL_COMPACT_MP4',name,'pages',len(pixel_pages),'bytes',row['bytes'],'seconds',row['seconds'],flush=True);return row

run('short-static-dark',ProjectConfig(surah=112,from_ayah=2,to_ayah=2,reciter='idrees_abkar',quality='hd',clips=[SceneClip(scene_id='orbit')]))
run('short-animated-dark',ProjectConfig(surah=112,from_ayah=2,to_ayah=2,reciter='idrees_abkar',quality='hd',clips=[SceneClip(scene_id='orbit')],effects={'verse':{'enabled':True,'kind':'glow','intensity':.6}}))
# Re-export identical source/config from the prior UI proof, without touching the old file/project.
old_audit=R/'backend/runtime/exports/c5c947d9-bb72-41cc-8f5a-7d8c35438519/audit.json'
if old_audit.exists():run('same-existing-reel-recomposed',ProjectConfig.model_validate(json.loads(old_audit.read_text())['config']))
style={'font':'amiri','size':88,'max_width':.79,'alignment':'right','x':.48,'y':.5,'line_height':1.8,'box_opacity':.28}
run('long-ayah-static',ProjectConfig(surah=2,from_ayah=255,to_ayah=255,reciter='qahtani',quality='draft',text_style=style,clips=[SceneClip(scene_id='orbit')]))
run('long-ayah-paginated-animated',ProjectConfig(surah=2,from_ayah=255,to_ayah=255,reciter='qahtani',quality='draft',text_style={'size':130,'max_width':.45,'line_height':2.3,'y':.46},clips=[SceneClip(scene_id='orbit')],effects={'verse':{'enabled':True,'kind':'reveal','intensity':.7,'duration':1.2}}))
run('warsh-labels-and-right-alignment',ProjectConfig(surah=1,from_ayah=3,to_ayah=4,reciter='suhaim',quality='hd',text_style={'size':86,'alignment':'right','max_width':.79,'y':.51},clips=[SceneClip(scene_id='haram_night',transition='light',transition_intensity=.3),SceneClip(scene_id='v17_pine_mist')]))
run('fullhd-large-font-safe-bottom',ProjectConfig(surah=112,from_ayah=2,to_ayah=2,reciter='hassan_saleh',quality='fullhd',text_style={'size':130,'max_width':.45,'x':.88,'y':.82,'alignment':'right'},clips=[SceneClip(scene_id='orbit')]))
run('multi-verse-switch-with-shared-column',ProjectConfig(surah=112,from_ayah=1,to_ayah=4,reciter='alafasy',quality='draft',text_style={'size':76,'max_width':.45,'x':.3,'y':.49,'alignment':'right','box_opacity':.2},clips=[SceneClip(scene_id='orbit')],effects={'verse':{'enabled':True,'kind':'verse_switch','intensity':1,'duration':.8}}))
run('minimum-user-size-hierarchy',ProjectConfig(surah=112,from_ayah=2,to_ayah=2,reciter='mossad',quality='draft',text_style={'size':28},clips=[SceneClip(scene_id='orbit')]))

# A real old-engine MP4 control demonstrates that the newly measured regions actually moved.
comparison={};before=Path.home()/'.cache/ayat-layout-171/before/media_engine.py'
if before.exists():
 spec=importlib.util.spec_from_file_location('ayat_layout_before',before);old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old);old.ROOT=e.ROOT;old.AUDIO=e.AUDIO;old.EXPORTS=C;old.RENDER_SLOT=e.RENDER_SLOT
 config,p,after_result,after_file,after_audit=exports['short-static-dark'];old_result=old.render(config,p,'control-before-fixed-gaps',lambda *a:None,lambda:False,lambda p:None);old_file=C/'control-before-fixed-gaps/result.mp4';old_frame=frame(old_file,1);new_frame=frame(after_file,1);page=after_audit['text_composition']['pages'][0];masks=expected_masks(config,page,720,1280)
 before_scores={k:visible_ratio(old_frame,m,config.text_style.color) for k,m in masks.items()};after_scores={k:visible_ratio(new_frame,m,config.text_style.color) for k,m in masks.items()};assert before_scores['surah']<.25 and before_scores['reader']<.25 and after_scores['surah']>.8 and after_scores['reader']>.8,(before_scores,after_scores)
 comparison={'real_old_engine_control_mp4':str(old_file),'before_at_new_positions':before_scores,'after_at_new_positions':after_scores,'source_audio_unchanged':True,'only_composition_changed':True,'old_fixed_surah_y':.115,'old_fixed_reader_y':.86,'new_group_bbox':page['layout']['group_bbox']}
 old_frame.resize((270,480)).save(C/'before-layout-frame.jpg',quality=90);new_frame.resize((270,480)).save(C/'after-layout-frame.jpg',quality=90)
report={'version':'1.7.1','layout_version':'compact-ink-v1','all_cases_completed':True,'actual_mp4_cases':len(reports),'tested_actual_mp4_pages':sum(r['page_count'] for r in reports),'cases':reports,'real_before_after_control':comparison,'source_quran_and_recordings_unchanged':True,'static_and_animated_pipeline_tested':True,'actual_component_pixels_checked':True,'physical_android_tested':False,'real_arena_download_issue_resolved':False}
(R/'tests/composition-real-mp4-v171.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('COMPOSITION_REAL_MP4_MATRIX_COMPLETE',len(reports),'cases',report['tested_actual_mp4_pages'],'pages',flush=True)
