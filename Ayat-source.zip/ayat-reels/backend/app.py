from pathlib import Path
from contextlib import asynccontextmanager
from concurrent.futures import ThreadPoolExecutor
import os,json,threading,uuid,subprocess,shutil,re,time,hashlib
from fastapi import FastAPI,Header,HTTPException,Request
from fastapi.responses import FileResponse,JSONResponse,HTMLResponse
from html import escape
from urllib.parse import quote
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool
from PIL import features
import storage
from visual_effects import EFFECTS_CATALOG
from quran import QURAN,SURAHS,SURAH_MAP,get_verses,source_info,quran_source
from catalog import SCENES,RECITERS,TEMPLATES,TEMPLATE_MAP,QUALITIES,reciter_narration,SCENE_MAP
from version import APP_VERSION
from models import AudioRequest,SaveProject,ExportRequest,ProjectConfig,SceneClip,PublicationWrite,SceneSuggestionRequest
from scene_selection import select_scenes,SELECTION_LOCK,SceneSelectionError
from scene_assets import asset_path,asset_status,request_scene_asset,asset_ready
from media_engine import FFMPEG,AUDIO,EXPORTS,EngineError,Canceled,prepare_audio,render,timing_and_clips,cleanup_orphaned_exports,RENDER_RESOURCE_POLICY

ROOT=Path(__file__).resolve().parent
EXECUTOR=ThreadPoolExecutor(max_workers=1,thread_name_prefix='ayat-export')
ACTIVE={};ACTIVE_LOCK=threading.RLock();SHUTTING_DOWN=False
SERVER_INSTANCE_ID=str(uuid.uuid4());SERVER_STARTED_AT=time.time()

@asynccontextmanager
async def lifespan(app):
 global SHUTTING_DOWN
 SHUTTING_DOWN=False
 storage.init_db();storage.backfill_scene_usage();count=storage.recover_interrupted()
 cleaned=cleanup_orphaned_exports()
 print(f'Ayat ready: {len(SURAHS)} surahs, {len(QURAN["verses"])} exact source ayahs; {count} interrupted jobs recovered; {cleaned} orphan temporary files removed.',flush=True)
 yield
 SHUTTING_DOWN=True
 with ACTIVE_LOCK:
  for jid,active in list(ACTIVE.items()):
   active['cancel'].set()
   if active.get('process'):
    try:active['process'].terminate()
    except Exception:pass
   storage.update_job(jid,state='interrupted',stage='انقطع محرك التصدير',error='توقف الخادم قبل اكتمال التصدير. مشروعك محفوظ؛ أعد المحاولة.',error_code='INTERRUPTED')

app=FastAPI(title='Ayat — Quran Reels',version=APP_VERSION,lifespan=lifespan)
origins=os.getenv('AYAT_CORS_ORIGINS','*').split(',')
app.add_middleware(CORSMiddleware,allow_origins=origins,allow_methods=['GET','POST','PUT','DELETE','OPTIONS'],allow_headers=['Content-Type','X-Workspace-Id','X-Ayat-Capabilities','X-Ayat-Request-Id'],expose_headers=['Content-Disposition','Content-Length'],allow_credentials=False)

@app.middleware('http')
async def current_export_status(request,call_next):
 response=await call_next(request)
 path=request.url.path
 if path in ['/api/health','/api/jobs'] or re.fullmatch(r'/api/jobs/(?:[0-9a-f-]+|by-request/[0-9a-f-]+)',path):response.headers['Cache-Control']='no-store'
 return response


@app.exception_handler(EngineError)
async def engine_error(request,exc):
 return JSONResponse(status_code=400,content={'error':str(exc),'code':exc.code,'retryable':exc.code not in ['INVALID_AUDIO_TRIM','INVALID_TIMINGS','EMPTY_TIMELINE']})

@app.exception_handler(RequestValidationError)
async def validation_error(request,exc):
 items=[]
 for e in exc.errors():
  items.append({'field':'.'.join(str(x) for x in e['loc']),'message':e['msg'].replace('Value error, ','')})
 return JSONResponse(status_code=422,content={'error':'راجع البيانات المحددة: '+items[0]['message'],'code':'VALIDATION','details':items,'retryable':False})

def workspace(request:Request):
 value=request.headers.get('X-Workspace-Id') or request.query_params.get('workspace')
 try:return str(uuid.UUID(value))
 except Exception:raise HTTPException(400,'معرّف مساحة العمل غير صحيح.')

def job_client_view(job):
 if job is not None:
  job=dict(job)
  if job['state']=='completed':job['file_available']=(EXPORTS/job['id']/'result.mp4').is_file()
 return job


def require_job(ws,jid):
 job=storage.get_job(ws,jid)
 if not job:raise HTTPException(404,'لم يُعثر على التصدير في مساحة العمل الحالية.')
 return job_client_view(job)


def export_request_key(request):
 value=request.headers.get('X-Ayat-Request-Id')
 if value is None:return None
 try:return str(uuid.UUID(value))
 except (ValueError,TypeError,AttributeError):raise HTTPException(400,'معرّف طلب التصدير غير صحيح.')


def prior_export_request(ws,key,fingerprint=None):
 if not key:return None
 record=storage.get_export_request(ws,key)
 if not record:return None
 if fingerprint is not None and record['request_sha256']!=fingerprint:raise HTTPException(409,'استُخدم معرّف الطلب نفسه لبيانات مختلفة. ابدأ طلبًا جديدًا.')
 return require_job(ws,record['job_id'])

def worker(job):
 jid=job['id']
 with ACTIVE_LOCK:
  state=ACTIVE.setdefault(jid,{'cancel':threading.Event(),'process':None})
 def canceled():return state['cancel'].is_set()
 def audio_progress(value,message):
  if canceled():raise Canceled()
  storage.update_job(jid,progress=5+value*24,stage=message,state='preparing')
 def progress(value,message):
  if canceled():raise Canceled()
  storage.update_job(jid,progress=value,stage=message,state='validating' if value>=95 else 'rendering')
 def on_process(proc):
  with ACTIVE_LOCK:state['process']=proc
 try:
  if canceled():raise Canceled()
  config=ProjectConfig.model_validate(job['config'])
  storage.update_job(jid,state='preparing',progress=3,stage='مراجعة النص وتحميل التلاوة')
  plan=prepare_audio(config.surah,config.from_ayah,config.to_ayah,config.reciter,audio_progress,canceled)
  result=render(config,plan,jid,progress,canceled,on_process)
  storage.complete_job_with_scene_usage(jid,result)
 except Canceled as exc:
  storage.update_job(jid,state='interrupted' if SHUTTING_DOWN else 'canceled',stage='توقف التصدير — المشروع محفوظ',error=str(exc),error_code='INTERRUPTED' if SHUTTING_DOWN else exc.code)
 except OSError as exc:
  storage.update_job(jid,state='failed',stage='لم يكتمل التصدير',error='نفدت المساحة. حرّر مساحة وأعد المحاولة.' if exc.errno==28 else 'تعذر الوصول إلى ملفات المشروع. أعد المحاولة.',error_code='NO_SPACE' if exc.errno==28 else 'FILE_ERROR')
 except Exception as exc:
  storage.update_job(jid,state='failed',stage='لم يكتمل التصدير',error=str(exc) if isinstance(exc,EngineError) else 'حدث خطأ غير متوقع في محرك التصدير. المشروع محفوظ؛ أعد المحاولة.',error_code=getattr(exc,'code','INTERNAL_ERROR'))
  import traceback;traceback.print_exc()
 finally:
  with ACTIVE_LOCK:ACTIVE.pop(jid,None)

def enqueue(ws,pid,config,request_id=None,request_fingerprint=None):
 if len([j for j in storage.jobs(ws) if j['state'] in ['queued','preparing','rendering','validating']])>=2:raise HTTPException(429,'يوجد تصديران قيد التنفيذ. انتظر اكتمالهما أو أوقف أحدهما.')
 job=storage.create_job(ws,pid,config,request_id,request_fingerprint) if request_id else storage.create_job(ws,pid,config)
 with ACTIVE_LOCK:ACTIVE[job['id']]={'cancel':threading.Event(),'process':None}
 try:EXECUTOR.submit(worker,job)
 except Exception:
  with ACTIVE_LOCK:ACTIVE.pop(job['id'],None)
  storage.update_job(job['id'],state='failed',stage='تعذر بدء عامل التصدير',error='محرك التصدير غير متاح حاليًا. المشروع محفوظ؛ أعد الاتصال ثم المحاولة.',error_code='WORKER_UNAVAILABLE')
  raise HTTPException(503,'تعذر بدء عامل التصدير؛ المشروع محفوظ.')
 return job

@app.get('/api/health')
def health():
 ff=subprocess.run([FFMPEG,'-version'],capture_output=True,text=True).stdout.splitlines()[0]
 usage=shutil.disk_usage(storage.RUNTIME)
 return {'ok':True,'app_version':APP_VERSION,'engine':'FFmpeg / server-side CPU','ffmpeg_version':ff,'quran_verified':True,'quran_sha256':QURAN['sha256'],'arabic_shaping':features.check('raqm'),'scene_count':len(SCENES),'storage_free_bytes':usage.free,'android_export_mode':'HTTPS backend; native MediaStore save/share plugin','phone_hardware_tested':False,'render_backend':RENDER_RESOURCE_POLICY['backend'],'render_resource_policy':RENDER_RESOURCE_POLICY,'server_instance_id':SERVER_INSTANCE_ID,'server_started_at':SERVER_STARTED_AT,'environment':os.getenv('AYAT_ENVIRONMENT','self-hosted'),'features':{'export_request_recovery':True,'job_file_availability':True}}

def legacy_client(request:Request):
 # Older shipped UIs identify their workspace, but cannot render the new narration.
 # Do not offer new voices to them or silently pair Warsh audio with Hafs preview text.
 return bool(request.headers.get('X-Workspace-Id')) and 'warsh' not in request.headers.get('X-Ayat-Capabilities','').split(',')

def require_narration_capability(request:Request,reciter):
 if reciter_narration(reciter)=='warsh' and legacy_client(request):
  raise HTTPException(409,'حدّث التطبيق إلى 1.3 أو أحدث لتفعيل صوت ورش مع نصه الصحيح. لن يُشغّل صوت ورش فوق نص حفص في نسخة قديمة.')

@app.get('/api/catalog')
def catalog(request:Request):
 readers=[r for r in RECITERS if r.get('provider') not in ['curated-surah','publisher-timed']] if legacy_client(request) else RECITERS
 caps=request.headers.get('X-Ayat-Capabilities','').split(',')
 if request.headers.get('X-Workspace-Id') and 'publisher-timing-v1' not in caps:readers=[r for r in readers if r.get('provider')!='publisher-timed']
 scenes=[s for s in SCENES if s.get('availability')!='on-demand' or 'scene-library-v17' in caps or not request.headers.get('X-Workspace-Id')]
 return {'app_version':APP_VERSION,'effects':EFFECTS_CATALOG,'surahs':SURAHS,'reciters':readers,'scenes':scenes,'templates':TEMPLATES,'qualities':list(QUALITIES.values()),'source':source_info(),'sources':{n:source_info(n) for n in ['hafs','warsh']},'fonts':[{'id':'amiri_quran','name':'أميري قرآن'},{'id':'amiri','name':'أميري'}]}

@app.get('/api/quran/{surah}')
def quran_surah(surah:int,narration:str='hafs'):
 try:source=quran_source(narration)
 except ValueError:raise HTTPException(422,'الرواية غير متاحة.')
 surahs={s['id']:s for s in source['surahs']}
 if surah not in surahs:raise HTTPException(404,'السورة غير موجودة.')
 return {'surah':surahs[surah],'verses':get_verses(surah,1,surahs[surah]['count'],narration),'basmala':source.get('basmalas',{}).get(str(surah)),'source':source_info(narration)}

@app.post('/api/audio/prepare')
async def audio_prepare(body:AudioRequest,request:Request):
 require_narration_capability(request,body.reciter)
 return await run_in_threadpool(prepare_audio,body.surah,body.from_ayah,body.to_ayah,body.reciter)

@app.get('/api/audio/plans/{plan_id}/preview.m4a')
def audio_preview(plan_id:str):
 if not re.fullmatch('[a-f0-9]{24}',plan_id):raise HTTPException(404)
 file=AUDIO/plan_id/'preview.m4a'
 if not file.exists():raise HTTPException(404,'التلاوة غير محضّرة. اضغط تجهيز التلاوة.')
 return FileResponse(file,media_type='audio/mp4',headers={'Cache-Control':'private, max-age=86400'})

@app.get('/api/audio/verse/{reciter}/{filename}')
def audio_verse(reciter:str,filename:str):
 if reciter not in {r['id'] for r in RECITERS} or not re.fullmatch(r'\d{6}\.mp3',filename):raise HTTPException(404)
 file=AUDIO/'verses'/reciter/filename
 if not file.exists():raise HTTPException(404,'حضّر التلاوة أولًا.')
 return FileResponse(file,media_type='audio/mpeg')

@app.get('/api/media/{filename}')
def media(filename:str):
 if filename not in {f"{s['id']}.{ext}" for s in SCENES for ext in ['mp4','jpg']}:raise HTTPException(404)
 file=asset_path(filename[:-4]) if filename.endswith('.mp4') else ROOT/'media'/filename
 if filename.endswith('.mp4') and not asset_ready(filename[:-4]):raise HTTPException(409,'المشهد الإضافي لم يُجهّز بعد أو يحتاج إعادة تحقق. استخدم زر تنزيل المشهد أولًا.')
 if not file.is_file():raise HTTPException(409,'ملف المشهد غير متاح. استخدم زر تنزيل المشهد أو راجع حزمة الوسائط.')
 return FileResponse(file,media_type='video/mp4' if filename.endswith('.mp4') else 'image/jpeg',headers={'Cache-Control':'public, max-age=604800'})

@app.get('/api/scenes/history')
def get_scene_history(request:Request):return storage.scene_usage(workspace(request))

@app.post('/api/scenes/history/reset')
def reset_scene_history(request:Request):return storage.reset_scene_usage(workspace(request))

@app.post('/api/scenes/suggest')
def suggest_scenes(body:SceneSuggestionRequest,request:Request):
 try:return select_scenes(workspace(request),**body.model_dump(),include_remote='scene-library-v17' in request.headers.get('X-Ayat-Capabilities','').split(','))
 except SceneSelectionError as exc:raise HTTPException(422,str(exc))

@app.get('/api/scenes/availability')
def scene_availability():return {'scenes':{s['id']:asset_status(s['id']) for s in SCENES}}

@app.get('/api/scenes/{ident}/availability')
def one_scene_availability(ident:str):
 if ident not in SCENE_MAP:raise HTTPException(404,'المشهد غير موجود.')
 return asset_status(ident)

@app.post('/api/scenes/{ident}/prepare')
def prepare_scene(ident:str):
 if ident not in SCENE_MAP:raise HTTPException(404,'المشهد غير موجود.')
 return request_scene_asset(ident)

@app.get('/api/projects')
def projects(request:Request):return storage.projects(workspace(request))

@app.post('/api/projects')
def save_project(body:SaveProject,request:Request):return storage.save_project(workspace(request),body.config.model_dump())

@app.get('/api/projects/{pid}')
def project(pid:str,request:Request):
 p=storage.get_project(workspace(request),pid)
 if not p:raise HTTPException(404,'المشروع غير موجود.')
 return p

@app.put('/api/projects/{pid}')
def update_project(pid:str,body:SaveProject,request:Request):
 if not storage.get_project(workspace(request),pid):raise HTTPException(404,'المشروع غير موجود.')
 return storage.save_project(workspace(request),body.config.model_dump(),pid)

@app.delete('/api/projects/{pid}')
def delete_project(pid:str,request:Request):
 ws=workspace(request)
 try:storage.delete_project(ws,pid)
 except ValueError as e:raise HTTPException(409,str(e))
 return {'deleted':True}

@app.get('/api/jobs')
def jobs(request:Request):return [job_client_view(job) for job in storage.jobs(workspace(request))]

@app.post('/api/jobs')
def new_export(body:ExportRequest,request:Request):
 ws=workspace(request);config=body.config
 require_narration_capability(request,config.reciter)
 key=export_request_key(request);fingerprint=hashlib.sha256(json.dumps(body.model_dump(),sort_keys=True,ensure_ascii=False).encode()).hexdigest()
 with SELECTION_LOCK:
  existing=prior_export_request(ws,key,fingerprint)
  if existing:return existing
  if body.one_click:
   template=TEMPLATE_MAP[config.template_id]
   try:selection=select_scenes(ws,3,mood=config.mood,preferred=template['scene_ids'],include_remote='scene-library-v17' in request.headers.get('X-Ayat-Capabilities','').split(','))
   except SceneSelectionError as exc:raise HTTPException(422,str(exc))
   config=config.model_copy(update={'clips':[SceneClip(scene_id=sid,source_out=min(6,SCENE_MAP[sid]['duration']),transition=template.get('transition','fade'),transition_duration=template.get('transition_duration',.5),duration=(template.get('durations') or [6,6,6])[i%3]) for i,sid in enumerate(selection['scene_ids'])],'auto_fit':True})
  pid=body.project_id
  if pid and not storage.get_project(ws,pid):raise HTTPException(404,'احفظ المشروع في هذه المساحة أولًا.')
  p=storage.save_project(ws,config.model_dump(),pid)
  return enqueue(ws,p['id'],config.model_dump(),key,fingerprint) if key else enqueue(ws,p['id'],config.model_dump())

@app.get('/api/jobs/by-request/{request_id}')
def export_by_request(request_id:str,request:Request):
 try:key=str(uuid.UUID(request_id))
 except (ValueError,AttributeError):raise HTTPException(400,'معرّف طلب التصدير غير صحيح.')
 existing=prior_export_request(workspace(request),key)
 if not existing:return JSONResponse(status_code=404,content={'error':'لم يُسجّل هذا الطلب في الخادم المتصل. المسودة المحلية لا تزال متاحة.','code':'EXPORT_REQUEST_NOT_FOUND'},headers={'Cache-Control':'no-store'})
 return existing

@app.get('/api/jobs/{jid}')
def get_job(jid:str,request:Request):return require_job(workspace(request),jid)

def require_publication_job(request,jid):
 ws=workspace(request);job=require_job(ws,jid)
 if job['state']!='completed' or not job.get('result'):
  raise HTTPException(409,'تجهيز المنشور متاح بعد اكتمال الريلز فقط.')
 return ws,job

def publication_context_hash(job):
 # Caption metadata is separate from the immutable Quran text and render config.
 result=job.get('result') or {}
 value={'job':job['id'],'config':job['config'],'timeline':result.get('timeline'),'source':result.get('source_sha256')}
 return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True).encode()).hexdigest()

@app.get('/api/jobs/{jid}/publication')
def get_publication(jid:str,request:Request):
 ws,job=require_publication_job(request,jid)
 return {'publication':storage.get_publication(ws,jid),'context_sha256':publication_context_hash(job)}

@app.put('/api/jobs/{jid}/publication')
def put_publication(jid:str,body:PublicationWrite,request:Request):
 ws,job=require_publication_job(request,jid)
 try:post=storage.save_publication(ws,jid,body.model_dump())
 except storage.PublicationConflict as exc:
  return JSONResponse(status_code=409,content={'error':'توجد نسخة أحدث محفوظة؛ اختر الاحتفاظ بتعديلاتك أو استخدام النسخة المحفوظة.','code':'PUBLICATION_CONFLICT','publication':exc.current})
 return {'publication':post,'context_sha256':publication_context_hash(job)}

@app.post('/api/jobs/{jid}/retry')
def retry(jid:str,request:Request):
 ws=workspace(request);key=export_request_key(request);fingerprint=hashlib.sha256(('retry:'+jid).encode()).hexdigest()
 with SELECTION_LOCK:
  existing=prior_export_request(ws,key,fingerprint)
  if existing:return existing
  job=require_job(ws,jid)
  require_narration_capability(request,job['config']['reciter'])
  if job['state'] not in ['failed','canceled','interrupted']:raise HTTPException(409,'إعادة المحاولة متاحة فقط للتصدير المتوقف أو غير المكتمل.')
  if not storage.get_project(ws,job['project_id']):raise HTTPException(404,'المشروع الأصلي غير موجود.')
  return enqueue(ws,job['project_id'],job['config'],key,fingerprint) if key else enqueue(ws,job['project_id'],job['config'])

@app.post('/api/jobs/{jid}/cancel')
def cancel(jid:str,request:Request):
 ws=workspace(request);job=require_job(ws,jid)
 if job['state'] not in ['queued','preparing','rendering','validating']:raise HTTPException(409,'التصدير ليس قيد التنفيذ.')
 with ACTIVE_LOCK:
  active=ACTIVE.get(jid)
  if active:
   active['cancel'].set()
   if active.get('process'):
    try:active['process'].terminate()
    except ProcessLookupError:pass
 storage.update_job(jid,state='canceled',stage='أُلغي التصدير — المشروع محفوظ',error='يمكنك تعديل المشروع أو إعادة المحاولة.',error_code='CANCELED')
 return require_job(ws,jid)

def job_file(jid,request,filename,media_type,download=False,inline=False):
 ws=workspace(request);job=require_job(ws,jid)
 if job['state']!='completed':raise HTTPException(409,'الفيديو لم يكتمل بعد. لا يمكن تنزيل ملف جزئي.')
 file=EXPORTS/jid/filename
 if not file.exists():raise HTTPException(410,'الملف لم يعد موجودًا على الخادم. أعد التصدير من المشروع المحفوظ.')
 name=f"Ayat_{job['config']['surah']}_{job['config']['from_ayah']}-{job['config']['to_ayah']}.mp4" if download or inline else None
 return FileResponse(file,media_type=media_type,filename=name,content_disposition_type='inline' if inline else 'attachment',headers={'Cache-Control':'private, no-store' if download else 'private, max-age=3600','X-Content-Type-Options':'nosniff'})

@app.get('/api/jobs/{jid}/file')
def download(jid:str,request:Request):return job_file(jid,request,'result.mp4','video/mp4',True)

@app.get('/api/jobs/{jid}/stream')
def stream_video(jid:str,request:Request):return job_file(jid,request,'result.mp4','video/mp4',inline=True)

@app.get('/api/jobs/{jid}/open',response_class=HTMLResponse)
def download_page(jid:str,request:Request):
 ws=workspace(request);job=require_job(ws,jid)
 if job['state']!='completed':raise HTTPException(409,'لم يكتمل الفيديو بعد.')
 if not (EXPORTS/jid/'result.mp4').exists():raise HTTPException(410,'ملف الفيديو لم يعد موجودًا. أعد التصدير من المشروع المحفوظ.')
 base=f'/api/jobs/{quote(jid,safe="")}';query='?workspace='+quote(ws,safe='')
 title=escape(job['config']['title']);file_url=escape(base+'/file'+query,quote=True);stream_url=escape(base+'/stream'+query,quote=True);notice_url=escape(base+'/notice'+query,quote=True)
 # A navigation straight from a sandboxed frame to an attachment can remain
 # blocked even with target=_blank. First commit an HTML document in the new
 # context explicitly allowed by the parent; only that document requests its file.
 # Never auto-request from inside an iframe, or claim the file reached the phone.
 auto_start=request.query_params.get('start')=='1'
 preload='none' if auto_start else 'metadata'
 auto_script="""<script id="ayat-standalone-download">(()=>{if(window.self!==window.top)return;const link=document.querySelector('[data-testid="direct-mp4-download"]');if(link)window.location.assign(link.href)})();</script>""" if auto_start else ''
 auto_note='<p>تطلب هذه الصفحة بدء التنزيل تلقائيًا. إذا لم يبدأ، اضغط الزر أدناه. راقب قسم التنزيلات؛ فتح الصفحة لا يؤكد اكتمال الحفظ.</p>' if auto_start else ''
 page=f'''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><title>تنزيل MP4 — آيات</title><style>body{{margin:0;padding:24px;background:#f7f6ef;color:#173b2d;font:16px/1.9 system-ui,sans-serif}}main{{max-width:560px;margin:auto}}video{{display:block;width:min(100%,360px);max-height:58vh;background:#0c2118;margin:18px auto;border-radius:16px}}a{{display:block;border-radius:12px;padding:13px 18px;margin:12px 0;text-align:center;background:#174c37;color:white;text-decoration:none;font-weight:700}}.light{{background:#e5eddc;color:#234d39}}small{{display:block;color:#5d6d5a}}h1{{font-size:25px}}p{{margin:10px 0}}</style></head><body><main><h1>ملف الريلز جاهز للتنزيل</h1><p>{title}</p>{auto_note}<video src="{stream_url}" controls playsinline preload="{preload}"></video><a href="{file_url}" download data-testid="direct-mp4-download">تنزيل ملف MP4</a><small>هذا رابط ملف MP4 الأصلي، لا تنزيل Blob مؤجلًا داخل التطبيق. على أندرويد ابحث في «التنزيلات» أو تطبيق الملفات. إن فتح المتصفح الفيديو بدل حفظه، افتح قائمة الفيديو واختر التنزيل أو الحفظ.</small><a class="light" href="{stream_url}" target="_blank" rel="noopener noreferrer">فتح الفيديو مباشرة</a><a class="light" href="{notice_url}" target="_blank" rel="noopener noreferrer">مصادر النص والصوت ونسب المشاهد</a><small>حفظ الملف يتم بواسطة المتصفح؛ لا تدعي هذه الصفحة اكتماله قبل أن يظهر في التنزيلات. إن كانت الصفحة داخل إطار معاينة يمنع فتح التبويبات أو التنزيل، افتح المعاينة خارج الإطار من الخيار الذي تتيحه المنصة؛ لا يستطيع التطبيق منح صلاحية منعها الإطار.</small></main>{auto_script}</body></html>'''
 return HTMLResponse(page,headers={'Cache-Control':'private, no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff'})

@app.get('/api/jobs/{jid}/cover')
def cover(jid:str,request:Request):return job_file(jid,request,'cover.jpg','image/jpeg')

@app.get('/api/jobs/{jid}/audit')
def audit(jid:str,request:Request):return job_file(jid,request,'audit.json','application/json')

@app.get('/api/jobs/{jid}/notice')
def notice(jid:str,request:Request):return job_file(jid,request,'NOTICE.txt','text/plain')

# Production can serve the built web UI from the same origin. Dev uses Vite's /api proxy.
WEB=ROOT.parent/'frontend/dist'
if WEB.exists():app.mount('/',StaticFiles(directory=WEB,html=True),name='web')
