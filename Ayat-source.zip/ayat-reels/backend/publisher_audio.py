"""Genuine whole-surah recordings with the publisher's reader-bound verse timings.
Pairs are validated/pinned on first download, never substituted with another voice.
Canonical Quran text is not read from this API; only timestamps and original audio.
"""
from pathlib import Path
import hashlib,json,os,time
import httpx,soundfile as sf
from catalog import RECITER_MAP
from quran import quran_source

class PublisherAudioError(Exception):pass

def validate_intervals(data,count,duration):
 grouped={}
 for item in data:
  n=int(item['ayah']);a=float(item['start_time'])/1000;b=float(item['end_time'])/1000
  if not 1<=n<=count or not 0<=a<b:raise PublisherAudioError('توقيت آية غير صالح من الناشر.')
  if n in grouped:
   old=grouped[n]
   if abs(old['start']-a)>.001 or abs(old['end']-b)>.001:raise PublisherAudioError('تكرار غير متطابق لتوقيت الآية؛ أوقفنا التجهيز للمراجعة.')
  else:grouped[n]={'number':n,'start':a,'end':b}
 if sorted(grouped)!=list(range(1,count+1)):raise PublisherAudioError('توقيت الناشر لا يغطي آيات هذه السورة كاملة؛ لم يُستخدم قارئ بديل.')
 adjustments=[];last=0
 for n in range(1,count+1):
  item=grouped[n]
  if item['end']>duration:
   if n!=count or item['end']-duration>1 or item['start']>=duration:raise PublisherAudioError('توقيت الناشر خارج مدة التسجيل الأصلي؛ يلزم إعادة التحقق.')
   adjustments.append({'ayah':n,'publisher_end':item['end'],'decoded_end':duration});item['end']=duration
  if item['start']<last-.000001:raise PublisherAudioError('توقيتات الناشر متداخلة أو بترتيب غير صحيح.')
  last=item['end']
 return [grouped[n] for n in range(1,count+1)],adjustments

def get_publisher_recording(reciter,surah,audio_root:Path,run_checked,canceled=lambda:False):
 rec=RECITER_MAP[reciter]
 if rec.get('provider')!='publisher-timed' or rec.get('narration','hafs')!='hafs':raise PublisherAudioError('مصدر القارئ أو الرواية غير متوافق.')
 if surah not in rec['publisher_available_surahs']:raise PublisherAudioError('السورة غير متاحة لهذا القارئ في مصدر التوقيت.')
 manifests=audio_root/'publisher_manifests'/reciter;manifests.mkdir(parents=True,exist_ok=True);manifest=manifests/f'{surah:03}.json'
 if manifest.exists():
  row=json.loads(manifest.read_text())
  if row.get('publisher_read')==rec['publisher_timing_read']:return row
 read=rec['publisher_timing_read'];timing_url=f'https://mp3quran.net/api/v3/ayat_timing?read={read}&surah={surah}'
 url=rec['publisher_audio_base']+f'{surah:03}.mp3'
 if not url.startswith('https://cdn.mp3quran.net/audio/'):raise PublisherAudioError('عنوان التسجيل غير معتمد.')
 with httpx.Client(timeout=httpx.Timeout(75,connect=15),follow_redirects=True) as client:
  timing=client.get(timing_url);timing.raise_for_status();raw_timing=timing.content;data=timing.json()
  temporary=manifests/f'{surah:03}.download';h=hashlib.sha256();size=0
  with client.stream('GET',url) as response:
   response.raise_for_status()
   with temporary.open('wb') as out:
    for chunk in response.iter_bytes(128*1024):
     if canceled():raise PublisherAudioError('أُلغي تجهيز التلاوة.')
     size+=len(chunk)
     if size>256_000_000:raise PublisherAudioError('التسجيل أكبر من حد التنزيل الحالي للخادم.')
     h.update(chunk);out.write(chunk)
 if size<1000:temporary.unlink(missing_ok=True);raise PublisherAudioError('وصل تسجيل صوتي فارغ.')
 digest=h.hexdigest();timing_sha=hashlib.sha256(raw_timing).hexdigest()
 sample=next((s for s in rec['verification_samples'] if s['surah']==surah),None)
 if sample and (sample['sha256']!=digest or sample['publisher_timing_sha256']!=timing_sha):
  temporary.unlink(missing_ok=True);raise PublisherAudioError('تغيّر التسجيل أو توقيته عن العينة المتحقق منها؛ لم نطبق توقيتًا على ملف آخر.')
 folder=audio_root/'recordings'/reciter;folder.mkdir(parents=True,exist_ok=True);source=folder/(f'{surah:03}-'+digest[:16]+'.mp3');os.replace(temporary,source);decoded=source.with_suffix('.wav')
 if not decoded.exists():
  part=decoded.with_suffix('.part.wav');run_checked(['-i',str(source),'-ac','1','-ar','48000','-c:a','pcm_s16le',str(part)],timeout=180);os.replace(part,decoded)
 duration=sf.info(decoded).duration;count=next(s['count'] for s in quran_source('hafs')['surahs'] if s['id']==surah);intervals,adjustments=validate_intervals(data,count,duration)
 row={'url':url,'sha256':digest,'bytes':size,'narration':'hafs','surah':surah,'duration':duration,'verse_intervals':intervals,'source_page':rec['source'],'source_provider':'MP3Quran','publisher_read':read,'publisher_timing_url':timing_url,'publisher_timing_sha256':timing_sha,'timing_method':'Publisher reader-bound per-ayah timestamps; validated against canonical Hafs verse count and decoded source duration. No ASR-generated Quran text.','timing_validation':{'publisher_timings':True,'publisher_read':read,'canonical_verse_count_verified':count,'final_endpoint_bounded_to_decoded_eof':adjustments,'all_intervals_nonoverlapping':True,'human_auditory_review_performed':False},'full_decode_exit':0}
 part=manifest.with_suffix('.part');part.write_text(json.dumps(row,ensure_ascii=False,indent=2));os.replace(part,manifest);return row
