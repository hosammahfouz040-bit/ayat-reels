from pathlib import Path
import sqlite3,json,time,uuid,threading,os
RUNTIME=Path(os.getenv('AYAT_RUNTIME_DIR',str(Path(__file__).resolve().parent/'runtime'))).expanduser().resolve();RUNTIME.mkdir(parents=True,exist_ok=True)
DB=RUNTIME/'ayat.sqlite3'
LOCK=threading.RLock()

def connect():
 db=sqlite3.connect(DB,timeout=20);db.row_factory=sqlite3.Row
 db.execute('PRAGMA foreign_keys=ON')
 return db

def init_db():
 with LOCK,connect() as d:
  d.execute('PRAGMA journal_mode=WAL') # Once at startup, not a locking PRAGMA on every status GET.
  d.executescript('''CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY,workspace TEXT NOT NULL,title TEXT NOT NULL,config TEXT NOT NULL,created REAL NOT NULL,updated REAL NOT NULL,last_job TEXT);
CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,workspace TEXT NOT NULL,project_id TEXT NOT NULL,config TEXT NOT NULL,state TEXT NOT NULL,progress REAL NOT NULL,stage TEXT NOT NULL,error TEXT,error_code TEXT,created REAL NOT NULL,updated REAL NOT NULL,result TEXT);
CREATE INDEX IF NOT EXISTS project_workspace ON projects(workspace);
CREATE INDEX IF NOT EXISTS job_workspace ON jobs(workspace);
CREATE TABLE IF NOT EXISTS publications(job_id TEXT PRIMARY KEY,workspace TEXT NOT NULL,title TEXT NOT NULL,description TEXT NOT NULL,hashtags TEXT NOT NULL,platform TEXT NOT NULL,suggestion INTEGER NOT NULL,edited INTEGER NOT NULL,revision INTEGER NOT NULL,updated REAL NOT NULL);
CREATE INDEX IF NOT EXISTS publication_workspace ON publications(workspace);
CREATE TABLE IF NOT EXISTS scene_usage_state(workspace TEXT PRIMARY KEY,epoch INTEGER NOT NULL DEFAULT 0,reset_at REAL NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS scene_usage_jobs(workspace TEXT NOT NULL,job_id TEXT NOT NULL,PRIMARY KEY(workspace,job_id));
CREATE TABLE IF NOT EXISTS scene_usage_events(workspace TEXT NOT NULL,epoch INTEGER NOT NULL,job_id TEXT NOT NULL,scene_id TEXT NOT NULL,used REAL NOT NULL,PRIMARY KEY(workspace,job_id,scene_id));
CREATE INDEX IF NOT EXISTS scene_usage_epoch ON scene_usage_events(workspace,epoch,scene_id);
CREATE TABLE IF NOT EXISTS export_requests(workspace TEXT NOT NULL,request_id TEXT NOT NULL,request_sha256 TEXT NOT NULL,job_id TEXT NOT NULL,created REAL NOT NULL,PRIMARY KEY(workspace,request_id));
CREATE INDEX IF NOT EXISTS export_requests_job ON export_requests(job_id);
''')

def row(row):
 if row is None:return None
 x=dict(row)
 for key in ['config','result']:
  if x.get(key):x[key]=json.loads(x[key])
 return x

def save_project(workspace,config,pid=None):
 now=time.time();pid=pid or str(uuid.uuid4())
 with LOCK,connect() as d:
  old=d.execute('SELECT * FROM projects WHERE id=? AND workspace=?',(pid,workspace)).fetchone()
  if old:d.execute('UPDATE projects SET title=?,config=?,updated=? WHERE id=?',(config['title'],json.dumps(config,ensure_ascii=False),now,pid))
  else:
   if d.execute('SELECT id FROM projects WHERE id=?',(pid,)).fetchone():raise ValueError('المشروع غير متاح في هذه المساحة.')
   d.execute('INSERT INTO projects VALUES(?,?,?,?,?,?,?)',(pid,workspace,config['title'],json.dumps(config,ensure_ascii=False),now,now,None))
 return get_project(workspace,pid)

def get_project(workspace,pid):
 with connect() as d:return row(d.execute('SELECT * FROM projects WHERE id=? AND workspace=?',(pid,workspace)).fetchone())

def projects(workspace):
 with connect() as d:return [row(x) for x in d.execute('SELECT * FROM projects WHERE workspace=? ORDER BY updated DESC',(workspace,)).fetchall()]

def delete_project(workspace,pid):
 with LOCK,connect() as d:
  if d.execute("SELECT id FROM jobs WHERE project_id=? AND workspace=? AND state IN ('queued','preparing','rendering','validating')",(pid,workspace)).fetchone():raise ValueError('أوقف التصدير أولًا قبل حذف المشروع.')
  d.execute('DELETE FROM projects WHERE id=? AND workspace=?',(pid,workspace))

def create_job(workspace,pid,config,request_id=None,request_fingerprint=None):
 now=time.time();jid=str(uuid.uuid4())
 with LOCK,connect() as d:
  d.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(jid,workspace,pid,json.dumps(config,ensure_ascii=False),'queued',0,'في قائمة الانتظار',None,None,now,now,None))
  d.execute('UPDATE projects SET last_job=?,updated=? WHERE id=? AND workspace=?',(jid,now,pid,workspace))
  if request_id:d.execute('INSERT INTO export_requests VALUES(?,?,?,?,?)',(workspace,request_id,request_fingerprint,jid,now))
 return get_job(workspace,jid)

def get_export_request(workspace,request_id):
 with connect() as d:
  record=d.execute('SELECT * FROM export_requests WHERE workspace=? AND request_id=?',(workspace,request_id)).fetchone()
  return dict(record) if record else None


def get_job(workspace,jid):
 with connect() as d:return row(d.execute('SELECT * FROM jobs WHERE id=? AND workspace=?',(jid,workspace)).fetchone())

def jobs(workspace):
 with connect() as d:return [row(x) for x in d.execute('SELECT * FROM jobs WHERE workspace=? ORDER BY created DESC LIMIT 40',(workspace,)).fetchall()]

def update_job(jid,**fields):
 allowed={'state','progress','stage','error','error_code','result'}
 fields={k:v for k,v in fields.items() if k in allowed};fields['updated']=time.time()
 if 'result' in fields:fields['result']=json.dumps(fields['result'],ensure_ascii=False)
 with LOCK,connect() as d:d.execute('UPDATE jobs SET '+','.join(k+'=?' for k in fields)+' WHERE id=?',(*fields.values(),jid))

def recover_interrupted():
 with LOCK,connect() as d:
  count=d.execute("SELECT COUNT(*) FROM jobs WHERE state IN ('queued','preparing','rendering','validating')").fetchone()[0]
  d.execute("UPDATE jobs SET state='interrupted',stage='توقف محرك التصدير',error='انقطع التصدير قبل اكتماله. المشروع محفوظ؛ اضغط إعادة المحاولة.',error_code='INTERRUPTED',updated=? WHERE state IN ('queued','preparing','rendering','validating')",(time.time(),))
 return count


class PublicationConflict(Exception):
 def __init__(self,current):super().__init__('توجد نسخة أحدث محفوظة لهذا المنشور.');self.current=current

def publication_row(record):
 if record is None:return None
 data=dict(record);data['edited']=bool(data['edited']);return data

def get_publication(workspace,jid):
 with connect() as d:return publication_row(d.execute('SELECT * FROM publications WHERE job_id=? AND workspace=?',(jid,workspace)).fetchone())

def save_publication(workspace,jid,values):
 keys=['title','description','hashtags','platform','suggestion','edited']
 with LOCK,connect() as d:
  d.execute('BEGIN IMMEDIATE')
  old=publication_row(d.execute('SELECT * FROM publications WHERE job_id=? AND workspace=?',(jid,workspace)).fetchone())
  expected=values['revision']
  if old and all(old[k]==values[k] for k in keys):return old # Idempotent retry after a lost response.
  if expected!=(old['revision'] if old else 0):raise PublicationConflict(old)
  revision=(old['revision'] if old else 0)+1;now=time.time()
  d.execute('INSERT INTO publications(job_id,workspace,title,description,hashtags,platform,suggestion,edited,revision,updated) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(job_id) DO UPDATE SET title=excluded.title,description=excluded.description,hashtags=excluded.hashtags,platform=excluded.platform,suggestion=excluded.suggestion,edited=excluded.edited,revision=excluded.revision,updated=excluded.updated WHERE publications.workspace=excluded.workspace',(jid,workspace,values['title'],values['description'],values['hashtags'],values['platform'],values['suggestion'],int(values['edited']),revision,now))
  return publication_row(d.execute('SELECT * FROM publications WHERE job_id=? AND workspace=?',(jid,workspace)).fetchone())


def visible_scene_ids(config,result):
 timeline=(result or {}).get('timeline') or {};clips=timeline.get('clips') or [];duration=(result or {}).get('duration')
 return list(dict.fromkeys(c['scene_id'] for c in clips if c.get('scene_id') and (duration is None or ('start' not in c or (c['start']<duration and c.get('end',duration)>0)))))

def _record_usage_sql(d,job):
 ws,jid=job['workspace'],job['id']
 if d.execute('SELECT 1 FROM scene_usage_jobs WHERE workspace=? AND job_id=?',(ws,jid)).fetchone():return
 d.execute('INSERT OR IGNORE INTO scene_usage_state(workspace,epoch,reset_at) VALUES(?,0,0)',(ws,))
 state=d.execute('SELECT epoch,reset_at FROM scene_usage_state WHERE workspace=?',(ws,)).fetchone()
 config=json.loads(job['config']) if isinstance(job['config'],str) else job['config'];result=json.loads(job['result']) if isinstance(job.get('result'),str) else job.get('result')
 if job.get('updated',time.time())>=state['reset_at']:
  for scene in visible_scene_ids(config,result):d.execute('INSERT OR IGNORE INTO scene_usage_events VALUES(?,?,?,?,?)',(ws,state['epoch'],jid,scene,job.get('updated',time.time())))
 d.execute('INSERT OR IGNORE INTO scene_usage_jobs VALUES(?,?)',(ws,jid))

def backfill_scene_usage():
 with LOCK,connect() as d:
  d.execute('BEGIN IMMEDIATE')
  for row in d.execute("SELECT * FROM jobs WHERE state='completed' ORDER BY updated").fetchall():_record_usage_sql(d,dict(row))

def complete_job_with_scene_usage(jid,result):
 with LOCK,connect() as d:
  d.execute('BEGIN IMMEDIATE')
  d.execute("UPDATE jobs SET state='completed',progress=100,stage='اكتمل التصدير وحُفظ ملف MP4',result=?,error=NULL,error_code=NULL,updated=? WHERE id=?",(json.dumps(result,ensure_ascii=False),time.time(),jid))
  row=d.execute('SELECT * FROM jobs WHERE id=?',(jid,)).fetchone()
  if row:_record_usage_sql(d,dict(row))

def scene_usage(workspace):
 with connect() as d:
  state=d.execute('SELECT epoch,reset_at FROM scene_usage_state WHERE workspace=?',(workspace,)).fetchone();epoch=state['epoch'] if state else 0
  rows=d.execute('SELECT scene_id,COUNT(*) uses,MAX(used) last_used FROM scene_usage_events WHERE workspace=? AND epoch=? GROUP BY scene_id',(workspace,epoch)).fetchall()
  clips=d.execute('SELECT COUNT(DISTINCT job_id) FROM scene_usage_events WHERE workspace=? AND epoch=?',(workspace,epoch)).fetchone()[0]
  return {'epoch':epoch,'reset_at':state['reset_at'] if state else 0,'completed_clips':clips,'unique_scenes':len(rows),'scenes':{x['scene_id']:{'uses':x['uses'],'last_used':x['last_used']} for x in rows}}

def reset_scene_usage(workspace):
 with LOCK,connect() as d:
  d.execute('BEGIN IMMEDIATE');now=time.time()
  d.execute('INSERT INTO scene_usage_state(workspace,epoch,reset_at) VALUES(?,1,?) ON CONFLICT(workspace) DO UPDATE SET epoch=epoch+1,reset_at=excluded.reset_at',(workspace,now))
 return scene_usage(workspace)

def pending_scene_reservations(workspace):
 with connect() as d:
  result={}
  for row in d.execute("SELECT config FROM jobs WHERE workspace=? AND state IN ('queued','preparing','rendering','validating')",(workspace,)).fetchall():
   for ident in {c['scene_id'] for c in json.loads(row['config'])['clips']}:result[ident]=result.get(ident,0)+1
  return result
