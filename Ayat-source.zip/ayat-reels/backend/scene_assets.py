"""Lazy, integrity-checked recorded-scene cache. Original 48 bundled videos stay untouched.
Only reviewed, source-pinned catalog URLs; no arbitrary user-supplied URL downloading.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from filelock import FileLock,Timeout as FileLockTimeout
from contextlib import contextmanager
from urllib.parse import urlparse
import hashlib,json,os,threading,time,subprocess,email.utils
import httpx,imageio_ffmpeg
from catalog import SCENE_MAP
ROOT=Path(__file__).resolve().parent
CACHE=Path(os.getenv('AYAT_RUNTIME_DIR',str(ROOT/'runtime'))).expanduser().resolve()/'.cache/scene-library-v17';CACHE.mkdir(parents=True,exist_ok=True)
POOL=ThreadPoolExecutor(max_workers=1,thread_name_prefix='scene-library');LOCK=threading.RLock();TASKS={};VERIFIED={}
FFMPEG=os.getenv('AYAT_FFMPEG') or imageio_ffmpeg.get_ffmpeg_exe()
class SceneAssetError(Exception):pass

def sha_file(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()

def asset_path(ident):
 s=SCENE_MAP[ident]
 return CACHE/(ident+'.mp4') if s.get('availability')=='on-demand' else ROOT/'media'/(ident+'.mp4')

def recipe(scene):
 data={k:scene.get(k) for k in ['remote_source','portrait_crop','duration','width','height','fps']};data['pipeline']='portrait-muted-h264-crf22-v1'
 return hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()

def asset_ready(ident):
 scene=SCENE_MAP[ident];path=asset_path(ident)
 if scene.get('availability')!='on-demand':return path.is_file()
 try:
  stat=path.stat();receipt=path.with_suffix('.json');stamp=(stat.st_size,stat.st_mtime_ns,receipt.stat().st_mtime_ns,recipe(scene))
  with LOCK:
   if VERIFIED.get(ident)==stamp:return True
  data=json.loads(receipt.read_text())
  valid=(data['scene_id']==ident and data['recipe']==stamp[-1] and data['source_sha256']==scene['remote_source']['sha256'] and data['bytes']==stat.st_size and data['full_decode_exit']==0 and data['muted'] is True and sha_file(path)==data['sha256'])
  if valid:
   with LOCK:VERIFIED[ident]=stamp
  return valid
 except (OSError,ValueError,KeyError,TypeError):return False

def asset_status(ident):
 s=SCENE_MAP[ident]
 if asset_ready(ident):return {'scene_id':ident,'state':'ready','progress':100,'message':'المشهد المرفق جاهز' if s.get('availability')!='on-demand' else 'المشهد جاهز في ذاكرة الخادم المؤقتة','bundled':s.get('availability')!='on-demand','video_url':s['video']}
 with LOCK:state={k:v for k,v in TASKS.get(ident,{}).items() if k!='future'}
 if state.get('state')=='ready':state={'state':'failed','progress':0,'message':'تحتاج نسخة الخادم إعادة التحقق والتجهيز. اضغط التنزيل مجددًا.'}
 return {'scene_id':ident,'state':'not_downloaded','progress':0,'message':'يحتاج تنزيلًا من المصدر إلى الخادم أول مرة','bundled':False,**state}

def _update(ident,**values):
 with LOCK:TASKS.setdefault(ident,{}).update(values)

def _run(args,canceled=lambda:False,timeout=300):
 p=subprocess.Popen([FFMPEG,'-hide_banner','-nostdin','-y','-v','error',*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE);deadline=time.monotonic()+timeout
 try:
  while True:
   if canceled():raise SceneAssetError('أُلغي تجهيز المشهد أثناء معالجة الفيديو.')
   if time.monotonic()>deadline:raise SceneAssetError('انتهت مهلة تجهيز المشهد؛ أعد المحاولة.')
   try:_,err=p.communicate(timeout=.2);break
   except subprocess.TimeoutExpired:continue
  if p.returncode:raise SceneAssetError('تعذر تجهيز المشهد المصوّر: '+err.decode(errors='replace')[-500:])
 finally:
  if p.poll() is None:p.kill();p.communicate()

@contextmanager
def cancellable_lock(path,canceled):
 lock=FileLock(str(path))
 while True:
  if canceled():raise SceneAssetError('أُلغي تجهيز المشهد أثناء انتظار دوره.')
  try:lock.acquire(timeout=.25);break
  except FileLockTimeout:continue
 try:yield
 finally:lock.release()

def ensure_scene_asset(ident,canceled=lambda:False,progress=lambda *a:None):
 if ident not in SCENE_MAP:raise SceneAssetError('المشهد غير موجود.')
 if canceled():raise SceneAssetError('أُلغي تجهيز المشهد.')
 scene=SCENE_MAP[ident];target=asset_path(ident)
 if asset_ready(ident):return target
 if scene.get('availability')!='on-demand':raise SceneAssetError('ملف المشهد المحلي مفقود؛ أعد تثبيت حزمة الوسائط الأصلية.')
 with cancellable_lock(CACHE/(ident+'.lock'),canceled):
  if asset_ready(ident):return target
  source=scene['remote_source'];key=source['sha256'];sources=CACHE/'sources';sources.mkdir(exist_ok=True);original=sources/(key+'.media')
  with cancellable_lock(sources/(key+'.lock'),canceled):
   if original.exists() and sha_file(original)!=key:original.unlink()
   if not original.exists():
    if not source['url'].startswith(('https://upload.wikimedia.org/wikipedia/commons/','https://www.nps.gov/nps-audiovideo/')):raise SceneAssetError('عنوان مصدر المشهد غير معتمد.')
    host=urlparse(source['url']).hostname;cooldown=CACHE/('download-cooldown-'+host+'.json')
    with cancellable_lock(CACHE/('network-'+host+'.lock'),canceled):
     if cooldown.exists() and json.loads(cooldown.read_text())['resume_at']>time.time():raise SceneAssetError('مصدر الفيديو يطلب مهلة قبل التنزيل. أعد المحاولة لاحقًا؛ لم نتجاوز حد المصدر.')
     part=original.with_suffix('.download');h=hashlib.sha256();size=0
     _update(ident,state='downloading',progress=1,message='تنزيل التسجيل الأصلي إلى الخادم');progress(.01,'تنزيل '+scene['name'])
     try:
      with httpx.Client(timeout=httpx.Timeout(90,connect=15),follow_redirects=True) as client:
       with client.stream('GET',source['url'],headers={'User-Agent':'AyatReels/1.7 licensed scene cache'}) as response:
        if response.status_code==429:
         retry=response.headers.get('Retry-After','600')
         try:seconds=int(retry)
         except ValueError:
          try:seconds=email.utils.parsedate_to_datetime(retry).timestamp()-time.time()
          except Exception:seconds=600
         cooldown.write_text(json.dumps({'resume_at':time.time()+max(seconds,600),'retry_after':retry}));raise SceneAssetError('المصدر حدّ عدد التنزيلات مؤقتًا. أعد المحاولة بعد انتهاء المهلة.')
        response.raise_for_status()
        with part.open('wb') as f:
         for chunk in response.iter_bytes(1024*1024):
          if canceled():raise SceneAssetError('أُلغي تجهيز المشهد.')
          size+=len(chunk)
          if size>source['bytes'] or size>1_100_000_000:raise SceneAssetError('حجم المصدر لا يطابق السجل المتحقق منه.')
          h.update(chunk);f.write(chunk);p=min(.8,size/source['bytes']*.8);_update(ident,state='downloading',progress=round(p*100),message='تنزيل التسجيل الأصلي إلى الخادم');progress(p,'تنزيل '+scene['name'])
      if size!=source['bytes'] or h.hexdigest()!=key:raise SceneAssetError('بصمة الفيديو الأصلي تغيّرت؛ أوقفنا الاستيراد للمراجعة.')
      os.replace(part,original)
     except Exception:
      part.unlink(missing_ok=True);raise
  if canceled():raise SceneAssetError('أُلغي تجهيز المشهد.')
  _update(ident,state='preparing',progress=82,message='قص رأسي وكتم الصوت الأصلي والتحقق من MP4');progress(.82,'تجهيز '+scene['name'])
  part=target.with_suffix('.part.mp4');crop=scene['portrait_crop'];x=crop.get('x',.5);y=crop.get('y',.5)
  zoom=max(1,min(2,float(crop.get('zoom',1))));scaled_w=round(scene['width']*zoom/2)*2;scaled_h=round(scene['height']*zoom/2)*2
  vf=f"scale={scaled_w}:{scaled_h}:force_original_aspect_ratio=increase,crop={scene['width']}:{scene['height']}:(in_w-out_w)*{x}:(in_h-out_h)*{y},setsar=1,fps={scene['fps']},format=yuv420p"
  try:
   _run(['-ss',str(source['in']),'-i',str(original),'-t',str(scene['duration']),'-an','-vf',vf,'-c:v','libx264','-preset','fast','-crf','22','-threads','2','-movflags','+faststart',str(part)],canceled)
   if canceled():raise SceneAssetError('أُلغي تجهيز المشهد.')
   reader=imageio_ffmpeg.read_frames(str(part));probe=next(reader);reader.close()
   if probe['source_size']!=(scene['width'],scene['height']) or abs(probe['duration']-scene['duration'])>.085 or abs(probe['fps']-scene['fps'])>.02 or probe.get('audio_codec'):
    raise SceneAssetError('خصائص المشهد الناتج لا تطابق القص الرأسي الصامت الموثق.')
   _run(['-i',str(part),'-map','0:v:0','-f','null','-'],canceled)
   if canceled():raise SceneAssetError('أُلغي تجهيز المشهد.')
   metadata={'source_sha256':key,'scene_id':ident,'recipe':recipe(scene),'created':time.time(),'bytes':part.stat().st_size,'sha256':sha_file(part),'crop':crop,'muted':True,'width':probe['source_size'][0],'height':probe['source_size'][1],'duration':probe['duration'],'fps':probe['fps'],'full_decode_exit':0}
   receipt=target.with_suffix('.json');receipt_part=receipt.with_suffix('.json.tmp');receipt_part.write_text(json.dumps(metadata,ensure_ascii=False,indent=2));os.replace(part,target);os.replace(receipt_part,receipt)
  except Exception:
   part.unlink(missing_ok=True);raise
 if not asset_ready(ident):raise SceneAssetError('فشل التحقق النهائي من ملف المشهد.')
 _update(ident,state='ready',progress=100,message='المشهد جاهز');progress(1,'المشهد جاهز');return target

def request_scene_asset(ident):
 if asset_ready(ident):return asset_status(ident)
 with LOCK:
  existing=TASKS.get(ident,{}).get('future')
  if existing and not existing.done():return asset_status(ident)
  _update(ident,state='queued',progress=0,message='بانتظار تنزيل المشهد إلى الخادم')
  def work():
   try:ensure_scene_asset(ident)
   except Exception as exc:_update(ident,state='failed',message=str(exc)[:500],progress=0)
  TASKS[ident]['future']=POOL.submit(work)
 return asset_status(ident)
