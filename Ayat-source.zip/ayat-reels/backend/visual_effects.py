"""Quiet, deterministic visual effects. Never synthesizes or rewrites Quran text.
One verse mode + one atmosphere + one camera mode; old projects default to disabled.
The live preview implements the same clocks, amplitudes and procedural formulas.
"""
from collections import OrderedDict
import math
import numpy as np
from PIL import Image,ImageDraw,ImageFilter,ImageChops

EFFECTS_CATALOG={
 'verse':[
  {'id':'fade','name':'ظهور تدريجي','hint':'دخول وخروج هادئان للنص.'},
  {'id':'glow','name':'توهج ناعم','hint':'ضوء خافت خلف الحروف دون تغييرها.'},
  {'id':'reveal','name':'كتابة متتابعة','hint':'إظهار الكلمات تدريجيًا، مع بقاء وقت لعرض الآية كاملة. حركة بصرية لا مزامنة لفظية.'},
  {'id':'highlight','name':'إبراز الكلمات','hint':'إبراز بصري لطيف؛ ليس توقيتًا موثّقًا لكلمات التلاوة.'},
  {'id':'verse_switch','name':'تبديل أنيق للآيات','hint':'تلاشي وتحريك قصير دون تراكب آيتين.'},
 ],
 'scene':[
  {'id':'fog','name':'ضباب خفيف','hint':'سحب شفافة بطيئة تحت النص.'},
  {'id':'rain','name':'مطر هادئ','hint':'قطرات قليلة، بلا برق أو ومضات.'},
  {'id':'sunrays','name':'أشعة شمس','hint':'حزم ضوء دافئة وخافتة.'},
  {'id':'dust','name':'غبار مضيء','hint':'ذرات ضوء بطيئة قليلة الكثافة.'},
  {'id':'stars','name':'نجوم هادئة','hint':'نقاط ضوء بطيئة؛ أنسب للمشاهد الليلية.'},
  {'id':'bloom','name':'وهج سينمائي','hint':'معالجة ضوء وتمويه خفيف للمشهد نفسه، لا النص.'},
 ],
 'camera':[
  {'id':'zoom_in','name':'تقريب هادئ','hint':'تقريب محدود للحفاظ على التكوين.'},
  {'id':'zoom_out','name':'ابتعاد هادئ','hint':'ابتعاد تدريجي دون حواف سوداء.'},
  {'id':'pan','name':'تحريك بطيء','hint':'تحريك أفقي داخل مساحة اقتصاص آمنة.'},
  {'id':'depth','name':'عمق بصري','hint':'حدة مركز وتمويه محيط مع حركة محدودة؛ ليس إعادة بناء ثلاثية الأبعاد.'},
 ],
 'transitions':[
  {'id':'cut','name':'قطع مباشر','existing':True},
  {'id':'fade','name':'تلاشي ناعم','existing':True},
  {'id':'wipeleft','name':'مسح إلى اليسار','existing':True},
  {'id':'slideup','name':'انزلاق لأعلى','existing':True},
  {'id':'light','name':'انتقال إضاءة هادئ','hint':'ذروة ضوء محدودة، لا ومضة حادة.','existing':False},
  {'id':'mist','name':'انتقال ضبابي','hint':'تمويه وتلاشي وضباب خافت.','existing':False},
 ],
 'word_timing_notice':'الكتابة وإبراز الكلمات حركات بصرية داخل زمن الآية، وليسا مزامنة لفظية. النص والمصدر والتشكيل محفوظة.'
}

def enabled(effect):return bool(effect and effect.get('enabled') and effect.get('intensity',0)>0)
def clamp(x,lo=0,hi=1):return max(lo,min(hi,x))
def smooth(x):x=clamp(x);return x*x*(3-2*x)
def rnd(i,seed=0):return math.sin(i*12.9898+seed*.013)*43758.5453%1

def effect_envelope(t,duration,total):
 d=min(duration,total) if duration>0 else total
 if d<=0 or t<0 or t>d:return 0
 ramp=min(.65,d*.25)
 return smooth(t/max(.001,ramp))*smooth((d-t)/max(.001,ramp))

def transition_seconds(clip,limit):
 if clip.get('transition')=='cut' or not clip.get('transition_enabled',True) or clip.get('transition_intensity',1)<=0:return 0
 return min(clip['transition_duration']*clip.get('transition_intensity',1),limit)

def camera_values(effect,t,total):
 if not enabled(effect):return 1,.5,.5
 intensity=effect['intensity'];d=min(effect['duration'],total) if effect['duration']>0 else total;p=smooth(t/max(.01,d));kind=effect['kind']
 if kind=='zoom_in':return 1+.08*intensity*p,.5,.5
 if kind=='zoom_out':return 1+.08*intensity*(1-p),.5,.5
 if kind=='pan':return 1+.065*intensity,p,.5
 return 1+.04*intensity*p,.5+.12*intensity*math.sin(p*math.pi),.5

def scene_filter_graph(index,clip,timeline,config,width,height,fps,folder,input_index=None):
 """Camera/bloom/mist on real background frames; SIMD blending + frame commands.
 Spatial masks are computed once, not re-evaluated per pixel per output frame.
 """
 fx=config.effects.model_dump();cam=fx['camera'];atmo=fx['scene'];duration=clip['duration'];parts=[];tag=f'b{index}'
 source_index=index if input_index is None else input_index
 chain=f'[{source_index}:v]scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},setsar=1,fps={fps}'
 if enabled(cam):
  d=min(cam['duration'],duration) if cam['duration']>0 else duration;den=max(1,d*fps);p=f'min(on/{den:.8f},1)';ease=f'({p})*({p})*(3-2*({p}))';i=cam['intensity'];kind=cam['kind']
  z=f'1+{.08*i:.8f}*({ease})' if kind=='zoom_in' else f'1+{.08*i:.8f}*(1-({ease}))' if kind=='zoom_out' else f'1+{.065*i:.8f}' if kind=='pan' else f'1+{.04*i:.8f}*({ease})'
  px=f'({ease})' if kind=='pan' else f'(.5+{.12*i:.8f}*sin(({ease})*PI))' if kind=='depth' else '.5'
  chain+=f",zoompan=z='{z}':x='(iw-iw/zoom)*{px}':y='(ih-ih/zoom)*.5':d=1:s={width}x{height}:fps={fps}"
 chain+=f',trim=duration={duration:.9f},setpts=PTS-STARTPTS,format=yuv420p,settb=1/{fps}[{tag}]';parts.append(chain)
 def blurred(weight_fn,sigma,label,bright=0):
  nonlocal tag
  sharp=f'{label}a{index}';blur=f'{label}b{index}';soft=f'{label}c{index}';out=f'{label}o{index}';commanded=f'{label}d{index}';name=f'fx{label}{index}'
  commands=folder/f'fx_{label}_{index}.txt'
  commands.write_text('\n'.join(f'{n/fps:.9f} blend@{name} all_opacity {clamp(weight_fn(n/fps)):.8f};' for n in range(math.ceil(duration*fps)+1))+'\n')
  parts.append(f'[{tag}]split=2[{sharp}][{blur}]')
  parts.append(f'[{blur}]gblur=sigma={sigma:.5f}'+(f',eq=brightness={bright:.6f}' if bright else '')+f'[{soft}]')
  parts.append(f"[{sharp}]sendcmd=f='{commands.as_posix()}'[{commanded}]")
  parts.append(f'[{soft}][{commanded}]blend@{name}=all_mode=normal:all_opacity=0[{out}]');tag=out
 if enabled(cam) and cam['kind']=='depth':
  maskfile=folder/f'fx_depth_mask_{index}.png';yy,xx=np.mgrid[0:height,0:width];radial=np.sqrt((xx-width/2)**2+(yy-height/2)**2)/math.sqrt(width*width+height*height);mask=np.clip((radial-.12)/.38,0,1)*(.65*cam['intensity']);Image.fromarray(np.uint8(np.round(mask*255))).save(maskfile)
  sharp=f'depa{index}';blur=f'depb{index}';soft=f'depc{index}';masktag=f'depm{index}';out=f'depo{index}'
  parts.append(f'[{tag}]split=2[{sharp}][{blur}]');parts.append(f'[{blur}]gblur=sigma={1+4*cam["intensity"]:.5f}[{soft}]')
  parts.append(f"movie=filename='{maskfile.as_posix()}':loop=0,setpts=N/({fps}*TB),format=yuv420p[{masktag}]")
  parts.append(f'[{sharp}][{soft}][{masktag}]maskedmerge=planes=1[{out}]');tag=out
 if enabled(atmo) and atmo['kind']=='bloom':
  blurred(lambda t:.3*atmo['intensity']*effect_envelope(t+clip['start'],atmo['duration'],timeline['duration']),2+6*atmo['intensity'],'blo',.08*atmo['intensity'])
 incoming=timeline['clips'][index-1] if index>0 else None
 if (incoming and incoming['transition']=='mist' and incoming['transition_seconds']>0) or (clip['transition']=='mist' and clip['transition_seconds']>0):
  def mist_weight(t):
   value=0
   if incoming and incoming['transition']=='mist' and incoming['transition_seconds']>0 and 0<=t<=incoming['transition_seconds']:value+=.6*incoming.get('transition_intensity',1)*math.sin(math.pi*t/incoming['transition_seconds'])
   if clip['transition']=='mist' and clip['transition_seconds']>0 and duration-clip['transition_seconds']<=t<=duration:value+=.6*clip.get('transition_intensity',1)*math.sin(math.pi*(t-(duration-clip['transition_seconds']))/clip['transition_seconds'])
   return value
  blurred(mist_weight,6,'mist')
 parts.append(f'[{tag}]fps={fps},settb=1/{fps}[s{index}]');return parts


def raw_overlay_required(config,timeline):
 fx=config.effects.model_dump()
 return enabled(fx['verse']) or (enabled(fx['scene']) and fx['scene']['kind']!='bloom') or any(c['transition'] in ['light','mist'] and c['transition_seconds']>0 for c in timeline['clips'])

def atmosphere_layer(width,height,effect,t,total,seed=0):
 layer=Image.new('RGBA',(width,height),(0,0,0,0))
 if not enabled(effect) or effect['kind']=='bloom':return layer
 strength=effect['intensity']*effect_envelope(t,effect['duration'],total)
 if strength<=0:return layer
 kind=effect['kind'];draw=ImageDraw.Draw(layer);scale=width/540
 if kind=='fog':
  small=Image.new('RGBA',(max(1,width//4),max(1,height//4)),(0,0,0,0));d=ImageDraw.Draw(small);w,h=small.size
  for i in range(5):
   x=(rnd(i,seed)*1.4-.2+.13*math.sin(t*.17+i))*w;y=(.12+.76*rnd(i+20,seed)+.04*math.sin(t*.11+i))*h;radius=w*(.45+.3*rnd(i+40,seed))
   d.ellipse((x-radius,y-radius*.6,x+radius,y+radius*.6),fill=(210,220,217,round((10+12*rnd(i+60,seed))*strength)))
  return small.filter(ImageFilter.GaussianBlur(max(2,w*.07))).resize((width,height),Image.Resampling.BILINEAR)
 if kind=='rain':
  for i in range(68):
   x=((rnd(i,seed)+.025*t)%1)*width;y=((rnd(i+100,seed)+t*(.2+.09*rnd(i+180,seed)))%1.12-.06)*height;length=(.025+.025*rnd(i+240,seed))*height
   draw.line((x,y,x-.009*width,y+length),fill=(218,231,232,round((16+24*rnd(i+300,seed))*strength)),width=max(1,round(scale)))
 elif kind=='sunrays':
  small=Image.new('RGBA',(max(1,width//4),max(1,height//4)),(0,0,0,0));d=ImageDraw.Draw(small);w,h=small.size;origin=(-.08*w,-.05*h)
  for i in range(6):
   x=(.12+i*.21+.035*math.sin(t*.15+i))*w;spread=(.08+.025*rnd(i,seed))*w
   d.polygon([origin,(x-spread,h),(x+spread,h)],fill=(255,238,190,round((8+9*rnd(i+20,seed))*strength)))
  return small.filter(ImageFilter.GaussianBlur(max(2,w*.035))).resize((width,height),Image.Resampling.BILINEAR)
 elif kind in ['dust','stars']:
  for i in range(36):
   x=((rnd(i,seed)+(.009*t if kind=='dust' else 0))%1)*width;y=((rnd(i+80,seed)-(.018*t if kind=='dust' else 0))%1)*height;r=(.8+1.9*rnd(i+180,seed))*scale
   pulse=.4+.6*math.sin(t*.45+i)**2;alpha=round((30+50*rnd(i+220,seed))*strength*pulse);color=(246,224,164) if kind=='dust' else (231,240,255)
   draw.ellipse((x-r*2,y-r*2,x+r*2,y+r*2),fill=(*color,round(alpha*.2)));draw.ellipse((x-r,y-r,x+r,y+r),fill=(*color,alpha))
 return layer

class OverlayPainter:
 """Bounded-memory RGBA stream, no per-frame file pile or generated Quran text."""
 def __init__(self,engine,config,timeline,pages,width,height,fps):
  self.e=engine;self.config=config;self.timeline=timeline;self.pages=pages;self.w=width;self.h=height;self.fps=fps;self.fx=config.effects.model_dump();self.cache=OrderedDict()
  self.seed=config.surah*101+config.from_ayah*17
 def graphics(self,page):
  key=(page['key'],page['page'],page['start'])
  if key in self.cache:self.cache.move_to_end(key);return self.cache[key]
  layout=page.get('layout') or self.e.layout_for_page(self.config,page,page['lines'],self.w,self.h)
  metadata=self.e.metadata_graphics(self.config,layout,self.w,self.h)
  value=(metadata,*self.e.text_graphics(self.config,page,page['lines'],self.w,self.h,layout))
  self.cache[key]=value
  while len(self.cache)>3:self.cache.popitem(last=False)
  return value
 def frame(self,t):
  im=atmosphere_layer(self.w,self.h,self.fx['scene'],t,self.timeline['duration'],self.seed)
  for c in self.timeline['clips'][:-1]:
   duration=c['transition_seconds'];start=c['end']-duration
   if duration>0 and start<=t<=c['end'] and c['transition'] in ['light','mist']:
    p=clamp((t-start)/duration);a=math.sin(math.pi*p)**2*c.get('transition_intensity',1)
    if c['transition']=='light':im=Image.alpha_composite(im,Image.new('RGBA',im.size,(255,246,214,round(46*a))))
    else:
     fog=atmosphere_layer(self.w,self.h,{'enabled':True,'kind':'fog','intensity':a,'duration':0},max(.7,t),max(t+1,self.timeline['duration']),self.seed+7);im=Image.alpha_composite(im,fog)
  page=next((p for p in self.pages if p['start']<=t<p['end']),None)
  placement=page or next((p for p in reversed(self.pages) if p['start']<=t),self.pages[0] if self.pages else None)
  if placement:im=Image.alpha_composite(im,self.graphics(placement)[0])
  if page:
   _,box,glyph,mask,words=self.graphics(page);duration=page['end']-page['start'];local=t-page['start'];effect=self.fx['verse'];alpha=1.;dy=0
   if enabled(effect):
    i=effect['intensity'];kind=effect['kind'];d=min(effect['duration'],duration*(.6 if kind in ['reveal','highlight'] else .28));d=max(.001,d)
    if kind in ['fade','verse_switch']:
     envelope=smooth(local/d)*smooth((duration-local)/d);alpha=1-i*(1-envelope)
     if kind=='verse_switch':dy=self.h*.015*i*((1-smooth(local/d))-(1-smooth((duration-local)/d)))
    elif kind=='glow':
     pulse=(.7+.3*math.sin(local*.7)**2)*effect_envelope(local,effect['duration'],duration);glow=Image.new('RGBA',im.size,(*self.e.rgb(self.config.text_style.color),0));glow.putalpha(mask.filter(ImageFilter.GaussianBlur(max(1,self.w/540*6))).point(lambda a:round(a*i*.5*pulse)));im=Image.alpha_composite(im,glow)
    elif kind in ['reveal','highlight'] and words:
     progress=clamp(local/d);index=min(len(words)-1,int(progress*len(words)))
     if kind=='highlight':
      x1,y1,x2,y2=words[index];highlight=Image.new('RGBA',im.size,(0,0,0,0));ImageDraw.Draw(highlight).rounded_rectangle((x1-2,y1,x2+2,y2),radius=max(2,self.w/540*3),fill=(216,195,121,round(55*i)));im=Image.alpha_composite(im,highlight)
     elif progress<1:
      reveal=Image.new('L',im.size,round(255*(1-i)));dr=ImageDraw.Draw(reveal);count=progress*len(words)
      for k,(x1,y1,x2,y2) in enumerate(words):
       opacity=smooth(count-k);dr.rectangle((x1-3,y1-5,x2+3,y2+5),fill=round(255*((1-i)+i*opacity)))
      glyph=glyph.copy();glyph.putalpha(ImageChops.multiply(glyph.getchannel('A'),reveal))
   if alpha<.999:
    box=box.copy();box.putalpha(box.getchannel('A').point(lambda a:round(a*alpha)));glyph=glyph.copy();glyph.putalpha(glyph.getchannel('A').point(lambda a:round(a*alpha)))
   if dy:
    shifted=Image.new('RGBA',im.size,(0,0,0,0));shifted.alpha_composite(box,(0,round(dy)));shifted.alpha_composite(glyph,(0,round(dy)));im=Image.alpha_composite(im,shifted)
   else:im=Image.alpha_composite(Image.alpha_composite(im,box),glyph)
  self.e.draw_visual_credits(im,self.e.required_visual_sources(self.timeline,t),self.w,self.h)
  return im
 def stream(self,stream,canceled,stop):
  for n in range(math.ceil(self.timeline['duration']*self.fps)):
   if canceled() or stop.is_set():break
   stream.write(self.frame(n/self.fps).tobytes())
  stream.flush()
