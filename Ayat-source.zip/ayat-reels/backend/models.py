from pydantic import BaseModel,Field,field_validator,model_validator,ConfigDict
from typing import Literal
from uuid import uuid4
import re
from catalog import SCENE_MAP,RECITER_MAP,TEMPLATE_MAP,reciter_narration,ensure_recitation_range
from quran import get_verses

class Strict(BaseModel):
 model_config=ConfigDict(extra='forbid')

class VerseEffect(Strict):
 enabled:bool=False
 kind:Literal['fade','glow','reveal','highlight','verse_switch']='fade'
 intensity:float=Field(.45,ge=0,le=1)
 duration:float=Field(1.2,ge=.2,le=8)

class SceneEffect(Strict):
 enabled:bool=False
 kind:Literal['fog','rain','sunrays','dust','stars','bloom']='fog'
 intensity:float=Field(.3,ge=0,le=1)
 duration:float=Field(0,ge=0,le=120) # 0 = whole reel, with a soft envelope.

class CameraEffect(Strict):
 enabled:bool=False
 kind:Literal['zoom_in','zoom_out','pan','depth']='zoom_in'
 intensity:float=Field(.3,ge=0,le=1)
 duration:float=Field(0,ge=0,le=120) # 0 = whole scene; otherwise move then hold.

class VisualEffects(Strict):
 verse:VerseEffect=Field(default_factory=VerseEffect)
 scene:SceneEffect=Field(default_factory=SceneEffect)
 camera:CameraEffect=Field(default_factory=CameraEffect)

class TextStyle(Strict):
 font:Literal['amiri_quran','amiri']='amiri_quran'
 size:float=Field(80,ge=28,le=130)
 color:str='#F5E8C8'
 x:float=Field(.5,ge=.12,le=.88)
 y:float=Field(.49,ge=.15,le=.82)
 max_width:float=Field(.82,ge=.45,le=.9)
 line_height:float=Field(1.8,ge=1.45,le=2.3)
 alignment:Literal['center','right']='center'
 box_color:str='#071F1A'
 box_opacity:float=Field(.26,ge=0,le=.95)
 shadow:bool=True
 shadow_color:str='#000000'
 shadow_blur:float=Field(5,ge=0,le=18)
 @field_validator('color','box_color','shadow_color')
 @classmethod
 def color_valid(cls,value):
  if not re.fullmatch(r'#[0-9A-Fa-f]{6}',value):raise ValueError('لون غير صحيح؛ استخدم صيغة HEX.')
  return value

class SceneClip(Strict):
 id:str=Field(default_factory=lambda:str(uuid4()))
 scene_id:str='mihrab'
 source_in:float=Field(0,ge=0)
 source_out:float=Field(6,gt=0)
 duration:float=Field(6,ge=.5,le=1800)
 transition:Literal['cut','fade','wipeleft','slideup','light','mist']='fade'
 transition_enabled:bool=True
 transition_intensity:float=Field(1,ge=0,le=1)
 transition_duration:float=Field(.5,ge=.05,le=2)
 @model_validator(mode='after')
 def check(self):
  if self.scene_id not in SCENE_MAP:raise ValueError('المشهد غير موجود.')
  if self.source_in+.15>=self.source_out or self.source_out>SCENE_MAP[self.scene_id]['duration']+.001:raise ValueError('قص المشهد خارج مدة الملف الأصلي.')
  return self

class VerseTiming(Strict):
 key:str
 start:float=Field(ge=0)
 end:float=Field(gt=0)
 @model_validator(mode='after')
 def check(self):
  if self.start>=self.end:raise ValueError('نهاية الآية يجب أن تكون بعد بدايتها.')
  return self

class ProjectConfig(Strict):
 @model_validator(mode='before')
 @classmethod
 def derive_narration(cls,data):
  if isinstance(data,dict):
   data=dict(data);expected=reciter_narration(data.get('reciter','alafasy'))
   if 'narration' not in data:data['narration']=expected
   elif data['narration']!=expected:raise ValueError('رواية النص لا تطابق رواية تسجيل القارئ. لا يُسمح بخلط ورش وحفص.')
  return data
 title:str=Field('ريل قرآني',min_length=1,max_length=100)
 surah:int=Field(112,ge=1,le=114)
 from_ayah:int=Field(1,ge=1,le=286)
 to_ayah:int=Field(4,ge=1,le=286)
 reciter:str='alafasy'
 narration:Literal['hafs','warsh']='hafs'
 template_id:str='noor'
 mood:Literal['سكينة','نور','طبيعة','ليل']='سكينة'
 quality:Literal['draft','hd','fullhd']='hd'
 text_style:TextStyle=Field(default_factory=TextStyle)
 clips:list[SceneClip]=Field(default_factory=lambda:[SceneClip(scene_id='mihrab'),SceneClip(scene_id='garden'),SceneClip(scene_id='orbit')],min_length=1,max_length=12)
 auto_fit:bool=True
 audio_trim_start:float=Field(0,ge=0)
 audio_trim_end:float|None=Field(None,gt=0)
 timings:list[VerseTiming]|None=None
 text_reviewed:bool=False
 effects:VisualEffects=Field(default_factory=VisualEffects)
 @model_validator(mode='after')
 def check(self):
  get_verses(self.surah,self.from_ayah,self.to_ayah,self.narration)
  if self.reciter not in RECITER_MAP:raise ValueError('القارئ غير متاح.')
  if self.template_id not in TEMPLATE_MAP:raise ValueError('القالب غير متاح.')
  if self.audio_trim_end is not None and self.audio_trim_end<=self.audio_trim_start:raise ValueError('نهاية الصوت يجب أن تكون بعد بدايته.')
  return self

class AudioRequest(Strict):
 surah:int
 from_ayah:int
 to_ayah:int
 reciter:str
 @model_validator(mode='after')
 def check(self):
  get_verses(self.surah,self.from_ayah,self.to_ayah,reciter_narration(self.reciter))
  if self.reciter not in RECITER_MAP:raise ValueError('القارئ غير متاح.')
  ensure_recitation_range(self.reciter,self.surah,self.from_ayah,self.to_ayah)
  return self

class SaveProject(Strict):
 config:ProjectConfig

class ExportRequest(Strict):
 config:ProjectConfig
 project_id:str|None=None
 one_click:bool=False
 @model_validator(mode='after')
 def verified_recording_available(self):
  c=self.config;ensure_recitation_range(c.reciter,c.surah,c.from_ayah,c.to_ayah)
  return self


class PublicationWrite(Strict):
 title:str=Field('',max_length=140)
 description:str=Field('',max_length=4000)
 hashtags:str=Field('',max_length=1500)
 platform:Literal['all','tiktok','instagram','facebook','youtube_shorts']='all'
 suggestion:int=Field(0,ge=0,le=1000000)
 edited:bool=False
 revision:int=Field(0,ge=0)


class SceneSuggestionRequest(Strict):
 availability:Literal['on-demand','bundled']|None=None
 count:int=Field(3,ge=1,le=12)
 mood:Literal['سكينة','نور','طبيعة','ليل']|None=None
 category:str|None=Field(None,max_length=80)
 subject:Literal['mosque','nature','original','all']|None=None
 exclude:list[str]=Field(default_factory=list,max_length=100)
 avoid_repeat:bool=True
