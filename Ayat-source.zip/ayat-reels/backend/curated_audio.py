"""Pinned genuine recordings split at registered acoustic verse boundaries.
No TTS, voice cloning, model text, runtime ASR or alternate-reader fallback.
"""
from pathlib import Path
import hashlib,json,os
import httpx,numpy as np,soundfile as sf
from catalog import CURATED_RECORDINGS,ensure_recitation_range

class CuratedAudioError(Exception):pass

def prepare_curated_verse(reciter,surah,ayah,audio_root:Path,run_checked,canceled=lambda:False,recording=None):
 ensure_recitation_range(reciter,surah,ayah,ayah)
 row=recording if recording is not None else CURATED_RECORDINGS[reciter][str(surah)]
 interval=next(v for v in row['verse_intervals'] if v['number']==ayah)
 original=audio_root/'recordings'/reciter;original.mkdir(exist_ok=True,parents=True)
 source=original/(f'{surah:03}-'+row['sha256'][:16]+'.mp3');decoded=source.with_suffix('.wav')
 if canceled():raise CuratedAudioError('أُلغي تجهيز التلاوة.')
 if not source.exists():
  with httpx.Client(timeout=httpx.Timeout(75,connect=15),follow_redirects=True) as client:
   response=client.get(row['url']);response.raise_for_status();data=response.content
  if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:
   raise CuratedAudioError('تغيّر تسجيل المصدر أو بصمته. لم تُستخدم توقيتات قديمة على تسجيل مختلف؛ يلزم إعادة التحقق.')
  temp=source.with_suffix('.download');temp.write_bytes(data);os.replace(temp,source)
 if source.stat().st_size!=row['bytes'] or hashlib.sha256(source.read_bytes()).hexdigest()!=row['sha256']:
  source.unlink(missing_ok=True);decoded.unlink(missing_ok=True)
  raise CuratedAudioError('بصمة التسجيل لا تطابق النسخة المتحقق منها. أعد المحاولة.')
 if not decoded.exists():
  temp=decoded.with_suffix('.part.wav');run_checked(['-i',str(source),'-ac','1','-ar','48000','-c:a','pcm_s16le',str(temp)],timeout=150);os.replace(temp,decoded)
 info=sf.info(decoded)
 if abs(info.duration-row['duration'])>.12 or info.samplerate!=48000 or info.channels!=1:
  decoded.unlink(missing_ok=True);raise CuratedAudioError('مدة التسجيل المفكوك لا تطابق النسخة المتحقق منها.')
 cache=audio_root/'verses'/reciter;cache.mkdir(exist_ok=True,parents=True);stem=f'{surah:03}{ayah:03}'
 mp3=cache/(stem+'.mp3');wav=cache/(stem+'.wav');stamp=cache/(stem+'.source.json')
 digest=hashlib.sha256(json.dumps({'source':row['sha256'],'interval':interval,'sample_rate':48000},sort_keys=True).encode()).hexdigest()
 same=False
 if stamp.exists():
  try:same=json.loads(stamp.read_text()).get('stamp')==digest
  except Exception:pass
 if not (same and wav.exists() and mp3.exists()):
  with sf.SoundFile(decoded) as inp:
   start=round(interval['start']*inp.samplerate);end=min(inp.frames,round(interval['end']*inp.samplerate));inp.seek(start);samples=inp.read(end-start,dtype='float32')
  if len(samples)<4800 or not np.isfinite(samples).all() or float(np.max(np.abs(samples)))<.001:
   raise CuratedAudioError('حدود الآية لا تحتوي صوتًا صالحًا؛ لن يُنشأ تصدير صامت.')
  temp=wav.with_suffix('.part.wav');sf.write(temp,samples,48000,subtype='PCM_16');os.replace(temp,wav)
  temp=mp3.with_suffix('.part.mp3');run_checked(['-i',str(wav),'-c:a','libmp3lame','-b:a','160k',str(temp)]);os.replace(temp,mp3)
  stamp.write_text(json.dumps({'stamp':digest,'source_sha256':row['sha256'],'start':interval['start'],'end':interval['end']},indent=2))
 return mp3,wav,{'source_url':row['url'],'source_page':row['source_page'],'source_provider':row['source_provider'],'source_recording_sha256':row['sha256'],'source_start':interval['start'],'source_end':interval['end'],'derived_excerpt':True,'narration':row['narration'],'timing_method':row['timing_method'],'timing_validation':row['timing_validation']}
