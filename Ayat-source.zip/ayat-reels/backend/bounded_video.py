"""Bounded-memory portrait background composition.
One scene is encoded at a time; transitions decode two SHORT overlap windows only.
The final Quran/audio pass opens ONE concatenated video stream, not N scaled decoders.
No resolution/effect/template is removed. All intermediate media is regenerable cache.
"""
from pathlib import Path
import math,json,subprocess
from visual_effects import scene_filter_graph

POLICY={'backend':'bounded-background-v1','max_parallel_scene_decoders':2,'final_background_streams':1,'video_decoder_threads':1,'encoder_threads':2,'input_queue_packets':2,'encoder_lookahead_frames':8,'resolution_downgrade':False,'intermediate_crf':17}

def frame_number(seconds,fps):return int(math.floor(seconds*fps+.5))

def plan_parts(timeline,fps):
 total=max(1,int(math.ceil(timeline['duration']*fps-1e-7)));raw=timeline['clips'];scenes=[]
 for index,clip in enumerate(raw):
  start=max(0,frame_number(clip['start'],fps));end=min(total,frame_number(clip['end'],fps))
  if clip['end']>=timeline['duration']-.000001:end=total
  if start>=total:continue
  if end<=start:raise ValueError('A selected scene is shorter than one output frame; use fewer scenes or a longer recording.')
  scenes.append({'index':index,'scene_id':clip['scene_id'],'start_frame':start,'end_frame':end,'frames':end-start})
 if not scenes:raise ValueError('No visible scene frames.')
 parts=[]
 for pos,scene in enumerate(scenes):
  incoming=max(0,scenes[pos-1]['end_frame']-scene['start_frame']) if pos else 0
  outgoing=max(0,scene['end_frame']-scenes[pos+1]['start_frame']) if pos+1<len(scenes) else 0
  count=scene['frames']-incoming-outgoing
  if count<0:raise ValueError('Transition windows overlap inside a scene; shorten transitions or increase the scene weight.')
  scene.update(incoming_frames=incoming,outgoing_frames=outgoing)
  if count:parts.append({'kind':'body','index':scene['index'],'start_frame':incoming,'frames':count})
  if outgoing:parts.append({'kind':'transition','index':scene['index'],'next_index':scenes[pos+1]['index'],'start_frame':scene['frames']-outgoing,'frames':outgoing})
 if sum(p['frames'] for p in parts)!=total:raise ValueError('Background frame plan does not match the audio timeline.')
 return {'fps':fps,'frames':total,'scenes':scenes,'parts':parts}


def _encode(engine,args,logfile,canceled,on_process,progress,seconds):
 command=[engine.FFMPEG,'-hide_banner','-nostdin','-y','-loglevel','warning','-filter_complex_threads','1','-filter_threads','1',*args]
 command[-1:-1]=['-progress','pipe:1','-stats_period','0.5','-nostats']
 (logfile.parents[2]/'last-background-command.json').write_text(json.dumps(command,ensure_ascii=False,indent=2))
 with logfile.open('w') as log:
  proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=log,stdin=subprocess.DEVNULL,text=True,start_new_session=True);on_process(proc)
  try:
   for line in proc.stdout:
    if canceled():proc.terminate();proc.wait(timeout=8);raise engine.Canceled()
    if line.startswith('out_time_us='):
     try:t=int(line.split('=',1)[1])/1_000_000
     except ValueError:continue
     progress(max(0,min(1,t/max(.01,seconds))))
   rc=proc.wait()
   if canceled():raise engine.Canceled()
   if rc:
    if rc in [-9,137]:raise engine.EngineError('أوقف النظام عملية تجهيز الفيديو بسبب الموارد. لم تُحذف إعدادات الجودة؛ المشروع محفوظ.','RESOURCE_LIMIT')
    error=logfile.read_text(errors='replace');(logfile.parents[2]/'background-stage-error.log').write_text(error)
    raise engine.EngineError('تعذر تجهيز جزء الفيديو: '+error[-3000:],'BACKGROUND_STAGE')
  finally:
   if proc.poll() is None:proc.kill();proc.wait(timeout=8)
   on_process(None)
 return command


def _codec(fps):
 return ['-an','-c:v','libx264','-preset','veryfast','-crf',str(POLICY['intermediate_crf']),'-pix_fmt','yuv420p','-threads','2','-bf','0','-g',str(fps*2),'-sc_threshold','0','-x264-params','rc-lookahead=8:sync-lookahead=0','-video_track_timescale',str(fps*1000),'-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-movflags','+faststart']


def prepare_background(engine,config,timeline,sources,folder,width,height,fps,canceled,on_process,progress):
 try:plan=plan_parts(timeline,fps)
 except ValueError as exc:raise engine.EngineError('تعذر ترتيب المشاهد ضمن المدة الفعلية: '+str(exc),'SCENE_FRAME_PLAN')
 work=folder/'.cache/video-stages';work.mkdir(parents=True,exist_ok=True);records=[];encoded={};weight=sum(s['frames'] for s in plan['scenes']);completed=0
 for scene in plan['scenes']:
  if canceled():raise engine.Canceled()
  i=scene['index'];clip=timeline['clips'][i];dest=work/f'scene_{i:02}.mp4';graph=scene_filter_graph(i,clip,timeline,config,width,height,fps,work,input_index=0)
  keys=sorted({0,scene['incoming_frames'],scene['frames']-scene['outgoing_frames']});graph.append(f'[s{i}]scale=iw:ih:in_color_matrix=auto:out_color_matrix=bt709:in_range=auto:out_range=tv,setsar=1,setparams=range=limited:color_primaries=bt709:color_trc=bt709:colorspace=bt709,format=yuv420p[scene_out]')
  key_times=','.join(f'{v/fps:.9f}' for v in keys if v<scene['frames'])
  args=['-threads','1','-thread_queue_size','2','-stream_loop','-1','-i',str(sources[i]),'-filter_complex',';'.join(graph),'-map','[scene_out]','-frames:v',str(scene['frames']),*_codec(fps),'-force_key_frames',key_times,'-forced-idr','1',str(dest)]
  done_before=completed
  command=_encode(engine,args,work/f'scene_{i:02}.log',canceled,on_process,lambda value:progress(38+24*(done_before+scene['frames']*value)/max(1,weight),'تجهيز المشهد على حدة · '+str(i+1)),scene['frames']/fps)
  encoded[i]=dest;completed+=scene['frames'];records.append({'kind':'scene','index':i,'frames':scene['frames'],'command':command})
 entries=['ffconcat version 1.0'];processed=0
 for number,part in enumerate(plan['parts']):
  if canceled():raise engine.Canceled()
  i=part['index'];dest=work/f'part_{number:03}.mp4';seconds=part['frames']/fps
  if part['kind']=='body':
   # Exact forced-IDR boundaries + no B frames permit lossless packet copy of scene bodies.
   args=['-threads','1','-ss',f"{part['start_frame']/fps:.9f}",'-i',str(encoded[i]),'-map','0:v:0','-frames:v',str(part['frames']),'-an','-c:v','copy','-avoid_negative_ts','make_zero','-video_track_timescale',str(fps*1000),'-movflags','+faststart',str(dest)]
  else:
   clip=timeline['clips'][i];kind='fade' if clip['transition'] in ['light','mist'] else clip['transition']
   graph=f'[0:v]setpts=PTS-STARTPTS,format=yuv444p,fps={fps},settb=1/{fps}[a];[1:v]setpts=PTS-STARTPTS,format=yuv444p,fps={fps},settb=1/{fps}[b];[a][b]xfade=transition={kind}:duration={seconds:.9f}:offset=0,format=yuv420p,setsar=1,setparams=range=limited:color_primaries=bt709:color_trc=bt709:colorspace=bt709[out]'
   args=['-threads','1','-thread_queue_size','2','-ss',f"{part['start_frame']/fps:.9f}",'-t',f'{seconds:.9f}','-i',str(encoded[i]),'-threads','1','-thread_queue_size','2','-t',f'{seconds:.9f}','-i',str(encoded[part['next_index']]),'-filter_complex',graph,'-map','[out]','-frames:v',str(part['frames']),*_codec(fps),str(dest)]
  command=_encode(engine,args,work/f'part_{number:03}.log',canceled,on_process,lambda value:None,seconds);records.append({**part,'file':dest.name,'command':command});entries.append(f"file '{dest.as_posix()}'");processed+=part['frames'];progress(62+6*processed/max(1,plan['frames']),'تركيب الأجزاء والانتقالات القصيرة')
 manifest=work/'background.ffconcat';manifest.write_text('\n'.join(entries)+'\n');summary={'policy':POLICY,'frame_plan':plan,'stages':records};(folder/'background-plan.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));return manifest,summary
