from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
SCENES=json.loads((ROOT/'media/catalog.json').read_text())
# Keep the 48 original records intact; reviewed additional videos are downloaded lazily.
REMOTE_CATALOG=ROOT/'media/catalog-on-demand.json'
if REMOTE_CATALOG.exists():SCENES+=json.loads(REMOTE_CATALOG.read_text())
assert len({s['id'] for s in SCENES})==len(SCENES),'Scene ID collision; old projects must remain stable.'
SCENE_MAP={s['id']:s for s in SCENES}
RECITERS=json.loads((ROOT/'data/reciters.json').read_text())
RECITER_MAP={r['id']:r for r in RECITERS}
CURATED_RECORDINGS=json.loads((ROOT/'data/curated-recordings.json').read_text())
def recording_ranges(surah,recording):
 # Never advertise a range across an unverified gap in a curated recording.
 groups=[]
 for number in sorted({v['number'] for v in recording['verse_intervals']}):
  if groups and number==groups[-1][-1]+1:groups[-1].append(number)
  else:groups.append([number])
 return [{'surah':int(surah),'from_ayah':g[0],'to_ayah':g[-1]} for g in groups]

for reciter in RECITERS:
 if reciter.get('provider')=='curated-surah':
  reciter['available_ranges']=[part for s,row in sorted(CURATED_RECORDINGS.get(reciter['id'],{}).items(),key=lambda p:int(p[0])) for part in recording_ranges(s,row)]

def reciter_narration(reciter):
 return RECITER_MAP.get(reciter,{}).get('narration','hafs')

def ensure_recitation_range(reciter,surah,start,end):
 rec=RECITER_MAP.get(reciter)
 if rec is None:raise ValueError('القارئ غير متاح.')
 if rec.get('provider')=='publisher-timed':
  if surah not in rec['publisher_available_surahs']:raise ValueError('السورة غير متاحة لهذا القارئ في مصدر التوقيت.')
  return
 if rec.get('provider')!='curated-surah':return
 recording=CURATED_RECORDINGS.get(reciter,{}).get(str(surah))
 available={v['number'] for v in recording['verse_intervals']} if recording else set()
 if start>end or not recording or recording['narration']!=reciter_narration(reciter) or not all(a in available for a in range(start,end+1)):
  raise ValueError('تلاوة هذا المدى غير متاحة بتوقيت متحقق لهذا القارئ. اختر إحدى التلاوات الموثقة الظاهرة في القائمة؛ لن يُستخدم صوت قارئ آخر بدلاً منه.')

QUALITIES={
 'draft':{'id':'draft','label':'اقتصادية','description':'540p · ملفات أخف','width':540,'height':960,'fps':24,'crf':24,'preset':'veryfast'},
 'hd':{'id':'hd','label':'عالية','description':'720p · التوازن الأفضل','width':720,'height':1280,'fps':24,'crf':21,'preset':'fast'},
 'fullhd':{'id':'fullhd','label':'فائقة','description':'1080p · تفاصيل أوضح','width':1080,'height':1920,'fps':30,'crf':20,'preset':'fast'},
}
TEMPLATES=[
 {'id':'noor','name':'نور','tag':'الأكثر هدوءًا','description':'أخضر عميق، ضوء ذهبي ونص يتنفس.','mood':'سكينة','scene_ids':['mihrab','garden','orbit'],'color':'#F5E8C8','box_color':'#071F1A','box_opacity':0.26,'font':'amiri_quran','size':80,'y':0.49,'accent':'#BBA16C'},
 {'id':'bahr','name':'أثر الماء','tag':'طبيعة','description':'إيقاع البحر وأزرق يبعث على السكينة.','mood':'طبيعة','scene_ids':['ocean','rain','dawn'],'color':'#FFFFFF','box_color':'#07222B','box_opacity':0.20,'font':'amiri','size':78,'y':0.51,'accent':'#74A8B0'},
 {'id':'fajr','name':'بدايات','tag':'دافئ','description':'ألوان الفجر ورمال تتحرك مع الضوء.','mood':'نور','scene_ids':['dawn','dunes','garden'],'color':'#FFF8E7','box_color':'#251A17','box_opacity':0.34,'font':'amiri_quran','size':80,'y':0.50,'accent':'#DBB79A'},
 {'id':'layl','name':'طمأنينة','tag':'ليلي','description':'سماء هادئة ونص فضي واضح.','mood':'ليل','scene_ids':['stars','orbit','rain'],'color':'#E9EDF8','box_color':'#0B1125','box_opacity':0.28,'font':'amiri_quran','size':82,'y':0.48,'accent':'#9AA7CD'},
 {'id':'safa','name':'صفاء','tag':'بسيط','description':'مساحة واسعة للآيات دون زخارف زائدة.','mood':'سكينة','scene_ids':['garden','ocean','mihrab'],'color':'#F6F7E7','box_color':'#0C251C','box_opacity':0.10,'font':'amiri','size':85,'y':0.53,'accent':'#B1BD95'},
 {'id':'dhahab','name':'مِشكاة','tag':'هندسي','description':'مدارات هندسية، ذهب معتّق وإضاءة ناعمة.','mood':'نور','scene_ids':['orbit','mihrab','dunes'],'color':'#F3DFA8','box_color':'#152526','box_opacity':0.35,'font':'amiri_quran','size':80,'y':0.48,'accent':'#D4B87E'},
]
TEMPLATES=[TEMPLATES[0],*json.loads((ROOT/'data/templates-extra.json').read_text()),*TEMPLATES[1:]]
TEMPLATE_MAP={t['id']:t for t in TEMPLATES}
FONTS={'amiri_quran':'AmiriQuran-Regular.ttf','amiri':'Amiri-Regular.ttf'}
