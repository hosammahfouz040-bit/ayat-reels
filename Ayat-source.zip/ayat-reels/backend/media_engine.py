from pathlib import Path
from io import BytesIO
import hashlib,json,os,re,math,time,threading,subprocess,shutil,sys
import httpx,numpy as np,soundfile as sf
from PIL import Image,ImageDraw,ImageFont,ImageFilter,ImageColor
import imageio_ffmpeg
from filelock import FileLock,Timeout as FileLockTimeout
from catalog import RECITER_MAP,SCENE_MAP,QUALITIES,FONTS,reciter_narration,ensure_recitation_range,CURATED_RECORDINGS
from quran import QURAN,get_verses,SURAH_MAP,quran_source,source_info
from curated_audio import prepare_curated_verse
from publisher_audio import get_publisher_recording
from scene_assets import ensure_scene_asset,SceneAssetError
from visual_effects import OverlayPainter,raw_overlay_required,scene_filter_graph,transition_seconds
import composition_layout as composition
from bounded_video import prepare_background,POLICY as RENDER_RESOURCE_POLICY

ROOT=Path(__file__).resolve().parent
RUNTIME=Path(os.getenv('AYAT_RUNTIME_DIR',str(ROOT/'runtime'))).expanduser().resolve()
CACHE=RUNTIME/'.cache';CACHE.mkdir(parents=True,exist_ok=True)
AUDIO=CACHE/'audio'
# Preserve existing downloaded recordings while moving regenerable cache out of source snapshots.
if (RUNTIME/'audio').exists() and not AUDIO.exists():(RUNTIME/'audio').replace(AUDIO)
AUDIO.mkdir(parents=True,exist_ok=True)
EXPORTS=RUNTIME/'exports';EXPORTS.mkdir(parents=True,exist_ok=True)
FFMPEG=os.environ.get('AYAT_FFMPEG') or imageio_ffmpeg.get_ffmpeg_exe()
AUDIO_LOCK=threading.RLock()
RENDER_SLOT=FileLock(str(CACHE/'render.lock'))
MAX_DURATION=float(os.getenv('AYAT_MAX_DURATION','1800'))

class EngineError(Exception):
 def __init__(self,message,code='ENGINE_ERROR'):
  super().__init__(message);self.code=code

class Canceled(EngineError):
 def __init__(self):super().__init__('أُلغي التصدير. مشروعك محفوظ.','CANCELED')

def run_checked(args,timeout=90):
 try:r=subprocess.run([FFMPEG,'-hide_banner','-y','-v','error',*args],capture_output=True,timeout=timeout)
 except subprocess.TimeoutExpired:raise EngineError('استغرق محرك الوسائط وقتًا أطول من المتوقع. أعد المحاولة.','TIMEOUT')
 if r.returncode:
  msg=r.stderr.decode('utf-8','replace')[-2000:]
  if 'No space left' in msg:raise EngineError('المساحة المتاحة غير كافية. حرّر مساحة ثم أعد المحاولة.','NO_SPACE')
  raise EngineError('تعذر معالجة ملف الوسائط: '+msg[:500],'MEDIA_ERROR')
 return r.stdout

def free_space_check(duration,quality):
 # Includes temporary intermediates plus final encoded output; no free-space fiction.
 q=QUALITIES[quality]
 estimate=int(160_000_000+duration*q['width']*q['height']*.9)
 free=shutil.disk_usage(RUNTIME).free
 if free<estimate:raise EngineError(f'المساحة المتاحة غير كافية. يلزم نحو {math.ceil(estimate/1024/1024)} م.ب، والمتاح {math.floor(free/1024/1024)} م.ب.','NO_SPACE')
 return {'free_bytes':free,'estimated_required_bytes':estimate}

def audio_plan_id(surah,start,end,reciter,recording=None):
 source=quran_source(reciter_narration(reciter))
 key=f"{source['sha256']}:{surah}:{start}:{end}:{reciter}:pcm48-v1"
 if RECITER_MAP.get(reciter,{}).get('provider')=='publisher-timed':
  if recording is None:
   manifest=AUDIO/'publisher_manifests'/reciter/f'{surah:03}.json'
   recording=json.loads(manifest.read_text()) if manifest.exists() else {'publisher_read':RECITER_MAP[reciter]['publisher_timing_read']}
  key+=':publisher:'+hashlib.sha256(json.dumps(recording,sort_keys=True).encode()).hexdigest()
 if RECITER_MAP.get(reciter,{}).get('provider')=='curated-surah':
  recording=CURATED_RECORDINGS.get(reciter,{}).get(str(surah),{})
  key+=':pinned:'+hashlib.sha256(json.dumps(recording,sort_keys=True).encode()).hexdigest()
 return hashlib.sha256(key.encode()).hexdigest()[:24]

def prepare_audio(surah,start,end,reciter,progress=lambda *a:None,canceled=lambda:False):
 if reciter not in RECITER_MAP:raise EngineError('القارئ غير متاح.','RECITER_UNAVAILABLE')
 try:ensure_recitation_range(reciter,surah,start,end)
 except ValueError as exc:raise EngineError(str(exc),'RECITATION_RANGE')
 narration=reciter_narration(reciter);text_source=quran_source(narration)
 verses=get_verses(surah,start,end,narration)
 plan_id=audio_plan_id(surah,start,end,reciter);folder=AUDIO/plan_id
 with AUDIO_LOCK:
  publisher_recording=None
  if RECITER_MAP[reciter].get('provider')=='publisher-timed':
   try:publisher_recording=get_publisher_recording(reciter,surah,AUDIO,run_checked,canceled)
   except Exception as exc:
    if canceled():raise Canceled()
    raise EngineError('تعذر تجهيز تسجيل الناشر وتوقيت آياته: '+str(exc)[:350],'PUBLISHER_AUDIO')
   plan_id=audio_plan_id(surah,start,end,reciter,publisher_recording);folder=AUDIO/plan_id
  if canceled():raise Canceled()
  if (folder/'plan.json').exists() and (folder/'combined.wav').exists() and (folder/'preview.m4a').exists():
   data=json.loads((folder/'plan.json').read_text());progress(1,'التلاوة المحفوظة جاهزة');return data
  folder.mkdir(exist_ok=True,parents=True)
  records=[];position=0;rec=RECITER_MAP[reciter]
  curated=rec.get('provider') in ['curated-surah','publisher-timed']
  cache=AUDIO/'verses'/reciter;cache.mkdir(exist_ok=True,parents=True)
  for i,v in enumerate(verses):
   if canceled():raise Canceled()
   filename=f"{surah:03}{v['number']:03}";mp3=cache/(filename+'.mp3');wav=cache/(filename+'.wav');extra={}
   if curated:
    try:
     mp3,wav,extra=prepare_curated_verse(reciter,surah,v['number'],AUDIO,run_checked,canceled,recording=publisher_recording);url=extra.pop('source_url')
    except Exception as exc:
     if canceled():raise Canceled()
     raise EngineError('تعذر تجهيز التسجيل الأصلي المتحقق منه: '+str(exc)[:350],'CURATED_AUDIO')
   else:
    url=f"https://everyayah.com/data/{rec['folder']}/{filename}.mp3"
    if not wav.exists():
     if not mp3.exists():
      failure=None
      for attempt in range(2):
       try:
        with httpx.Client(timeout=httpx.Timeout(30,connect=12),follow_redirects=True) as client:
         response=client.get(url);response.raise_for_status()
        if len(response.content)<1000:raise ValueError('Empty recording')
        temp=mp3.with_suffix('.download');temp.write_bytes(response.content);os.replace(temp,mp3)
        failure=None;break
       except Exception as exc:failure=exc;time.sleep(.25)
      if failure:raise EngineError(f"تعذر تحميل تلاوة الآية {v['key']} للقارئ المحدد. تحقق من الاتصال أو اختر قارئًا آخر ثم أعد المحاولة.",'AUDIO_DOWNLOAD')
     try:
      run_checked(['-i',str(mp3),'-ac','1','-ar','48000','-c:a','pcm_s16le',str(wav)])
      audio,sr=sf.read(wav,dtype='float32')
      if len(audio)<4800 or not np.isfinite(audio).all() or float(np.max(np.abs(audio)))<.001:raise ValueError('No audible waveform')
     except Exception:
      wav.unlink(missing_ok=True);mp3.unlink(missing_ok=True)
      raise EngineError(f"ملف تلاوة الآية {v['key']} غير صالح للتشغيل. أعد المحاولة.",'AUDIO_DECODE')
   info=sf.info(wav);duration=info.frames/info.samplerate
   records.append({**v,'start':position,'end':position+duration,'duration':duration,'source_url':url,'audio_url':f'/api/audio/verse/{reciter}/{filename}.mp3','audio_sha256':hashlib.sha256(mp3.read_bytes()).hexdigest(),**extra})
   position+=duration
   if position>MAX_DURATION:raise EngineError(f'مدة المقطع تتجاوز حد الخادم الحالي ({int(MAX_DURATION/60)} دقيقة). اختر آيات أقل أو ارفع AYAT_MAX_DURATION في إعداد الخادم.','DURATION_LIMIT')
   progress((i+1)/len(verses),f"تجهيز التلاوة · الآية {i+1} من {len(verses)}")
  part=folder/'combined.part.wav'
  with sf.SoundFile(part,'w',samplerate=48000,channels=1,subtype='PCM_16',format='WAV') as output:
   for v in records:
    wav=cache/f"{surah:03}{v['number']:03}.wav"
    with sf.SoundFile(wav) as source:
     for block in source.blocks(blocksize=48000,dtype='float32'):output.write(block)
  os.replace(part,folder/'combined.wav')
  run_checked(['-i',str(folder/'combined.wav'),'-c:a','aac','-b:a','128k','-movflags','+faststart',str(folder/'preview.m4a')])
  method=('Publisher reader-bound verse timings validated against decoded source and canonical counts; not word-level timing.' if publisher_recording else 'Pinned full-surah source; acoustically aligned verse boundaries with energy refinement, not publisher timings; review is recommended; not word-level highlighting.' if curated else 'decoded per-ayah audio durations; not word-level alignment')
  plan={'id':plan_id,'surah':surah,'from_ayah':start,'to_ayah':end,'reciter':reciter,'reciter_name':rec['name'],'narration':narration,'narration_name':source_info(narration)['narration_name'],'duration':position,'verses':records,'audio_url':f'/api/audio/plans/{plan_id}/preview.m4a','source_sha256':text_source['sha256'],'timing_method':method}
  (folder/'plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
  return plan


def timing_and_clips(config,plan):
 start=config.audio_trim_start;end=config.audio_trim_end if config.audio_trim_end is not None else plan['duration']
 if start<0 or end>plan['duration']+.05 or end-start<.25:raise EngineError('بداية ونهاية الصوت خارج مدة التلاوة، أو المدى أقصر من ربع ثانية.','INVALID_AUDIO_TRIM')
 end=min(end,plan['duration']);duration=end-start
 timings=[{'key':v['key'],'start':v['start'],'end':v['end']} for v in plan['verses']]
 if config.timings is not None:
  proposed=[t.model_dump() for t in config.timings]
  if [t['key'] for t in proposed]!=[v['key'] for v in plan['verses']]:raise EngineError('التوقيتات لا تطابق الآيات المحددة. أعد التوقيت التلقائي.','INVALID_TIMINGS')
  last=0
  for t in proposed:
   if t['start']<last-.002 or t['end']>plan['duration']+.05:raise EngineError('توقيتات الآيات متداخلة أو خارج مدة الصوت.','INVALID_TIMINGS')
   last=t['end']
  timings=proposed
 cues=[]
 by_key={v['key']:v for v in plan['verses']}
 for t in timings:
  a=max(t['start'],start);b=min(t['end'],end)
  if b>a:
   cues.append({'key':t['key'],'number':by_key[t['key']]['number'],'text':by_key[t['key']]['text'],'start':a-start,'end':b-start})
 if not cues:raise EngineError('لا توجد آيات داخل المدى الصوتي المحدد.','EMPTY_TIMELINE')
 clips=[c.model_dump() for c in config.clips]
 transitions=[transition_seconds(c,duration/(max(1,len(clips))*3)) for c in clips[:-1]]
 if config.auto_fit:
  weights=sum(c['duration'] for c in clips)
  # Transition windows must fit the weighted scene, including very unequal weights.
  for _ in range(24):
   total=duration+sum(transitions);durations=[total*c['duration']/weights for c in clips]
   bounded=[min(d,durations[i]/3,durations[i+1]/3) for i,d in enumerate(transitions)]
   if all(abs(a-b)<1e-10 for a,b in zip(bounded,transitions)):break
   transitions=bounded
  total=duration+sum(transitions);durations=[total*c['duration']/weights for c in clips]
 else:
  durations=[c['duration'] for c in clips]
  transitions=[min(d,durations[i]/3,durations[i+1]/3) for i,d in enumerate(transitions)]
  if sum(durations)-sum(transitions)<duration-.03:raise EngineError('المشاهد أقصر من الصوت. فعّل «ملاءمة مدة المشاهد للتلاوة» أو زد مدتها.','SCENES_TOO_SHORT')
 pos=0
 for i,c in enumerate(clips):
  c['duration']=durations[i];c['start']=pos;c['end']=pos+durations[i]
  c['transition_seconds']=transitions[i] if i<len(transitions) else 0
  pos+=durations[i]-(transitions[i] if i<len(transitions) else 0)
 return {'audio_start':start,'audio_end':end,'duration':duration,'cues':cues,'clips':clips}

def rgb(hexcolor):return ImageColor.getrgb(hexcolor)

def quran_font(config):
 return 'KFGQPCWarsh.ttf' if getattr(config,'narration','hafs')=='warsh' else FONTS[config.text_style.font]

def load_font(name,size):return ImageFont.truetype(str(ROOT/'fonts'/name),max(12,int(size)),layout_engine=ImageFont.Layout.RAQM)

def draw_arabic(layer,text,font,x,y,fill,anchor='mm'):
 ImageDraw.Draw(layer).text((x,y),text,font=font,fill=fill,anchor=anchor,direction='rtl',language='ar')

def wrap_text(text,font,width):
 # Only line layout changes; every character comes from the selected immutable publisher source.
 words=text.split(' ');lines=[];line=''
 d=ImageDraw.Draw(Image.new('RGBA',(2,2)))
 for word in words:
  test=word if line=='' else line+' '+word
  if line and d.textlength(test,font=font,direction='rtl',language='ar')>width:
   lines.append(line);line=word
  else:line=test
 if line:lines.append(line)
 return lines

def layout_for_page(config,cue,lines,width,height):
 style=config.text_style;kind=config.effects.verse
 face=composition.fit_verse_font(style,quran_font(config),cue['text'] if cue else ' '.join(lines),width)
 size=cue.get('render_font_size',face.size) if cue else face.size
 motion=height*.015*kind.intensity if kind.enabled and kind.kind=='verse_switch' else 0
 glow=width/540*12*kind.intensity if kind.enabled and kind.kind=='glow' else 0
 bleed=max(glow,style.shadow_blur*width/1080 if style.shadow else 0)
 try:return composition.compose(style,quran_font(config),lines,width,height,'سورة '+SURAH_MAP[config.surah]['name'],RECITER_MAP[config.reciter]['name'],'نص ورش: مجمع الملك فهد' if config.narration=='warsh' else 'نص القرآن: Tanzil.net',cue['number'] if cue else None,config.narration,size,motion,bleed)
 except ValueError as exc:raise EngineError('تعذر توزيع النص داخل الهوامش الآمنة للفيديو. راجع الحجم والعرض. '+str(exc),'TEXT_LAYOUT')


def metadata_graphics(config,layout,width,height,component=None,opaque=False):
 """Full names, one shared column, measured vertical flow; no fixed screen-edge HUD."""
 style=config.text_style;scale=width/1080;layer=Image.new('RGBA',(width,height),(0,0,0,0))
 for key,alpha in [('surah',232),('reader',225),('source',180)]:
  if component and component!=key:continue
  item=layout[key];face=composition.font(item['font'],item['font_size'])
  for run in item['lines']:draw_arabic(layer,run['text'],face,run['x'],run['y'],(*rgb(style.color),255 if opaque else alpha))
 if not component:
  if style.shadow:
   shadow=Image.new('RGBA',(width,height),(*rgb(style.shadow_color),0));shadow.putalpha(layer.getchannel('A').filter(ImageFilter.GaussianBlur(max(.5,style.shadow_blur*scale*.6))).point(lambda a:round(a*.8)));layer=Image.alpha_composite(shadow,layer)
  line=layout['divider'];ImageDraw.Draw(layer).line((line['x1'],line['y'],line['x2'],line['y']),fill=(*rgb(style.color),100),width=line['thickness'])
 return layer


def text_graphics(config,cue,lines,width,height,layout=None):
 style=config.text_style;scale=width/1080
 box=Image.new('RGBA',(width,height),(0,0,0,0));glyph=box.copy();mask=Image.new('L',(width,height),0);words=[]
 if not cue or not lines:return box,glyph,mask,words
 layout=layout or cue.get('layout') or layout_for_page(config,cue,lines,width,height)
 face=composition.font(layout['verse']['font'],layout['verse']['font_size'])
 if style.box_opacity:ImageDraw.Draw(box).rounded_rectangle(layout['verse_box'],radius=24*scale,fill=(*rgb(style.box_color),round(255*style.box_opacity)))
 main=Image.new('RGBA',(width,height),(0,0,0,0));measure=ImageDraw.Draw(main)
 for run in layout['verse']['lines']:
  line=run['text'];xx,yy=run['x'],run['y'];draw_arabic(main,line,face,xx,yy,(*rgb(style.color),255))
  whole=composition.advance(line,face);tokens=line.split(' ');advances=[composition.advance(w,face) for w in tokens];space=composition.advance(' ',face);ratio=whole/max(.01,sum(advances)+max(0,len(tokens)-1)*space);cursor=xx+whole/2 # All measured runs use the same optical middle anchor, including right alignment.
  for word,length in zip(tokens,advances):
   length*=ratio
   if word:words.append((cursor-length,run['ink'][1],cursor,run['ink'][3]))
   cursor-=length+space*ratio
 mask=main.getchannel('A')
 if style.shadow:
  shadow=Image.new('RGBA',(width,height),(*rgb(style.shadow_color),0));shadow.putalpha(mask.filter(ImageFilter.GaussianBlur(style.shadow_blur*scale)));glyph=Image.alpha_composite(glyph,shadow)
 glyph=Image.alpha_composite(glyph,main)
 if layout['number']:
  item=layout['number'];number_face=composition.font(item['font'],item['font_size'])
  for run in item['lines']:draw_arabic(glyph,run['text'],number_face,run['x'],run['y'],(*rgb(style.color),215))
 return box,glyph,mask,words


def make_overlay(config,cue,lines,width,height,layout=None):
 layout=layout or (cue.get('layout') if cue else None) or layout_for_page(config,cue,lines,width,height)
 im=metadata_graphics(config,layout,width,height);box,glyph,mask,_=text_graphics(config,cue,lines,width,height,layout)
 return Image.alpha_composite(Image.alpha_composite(im,box),glyph),mask


def needs_visual_credit(scene):return bool(scene.get('requires_attribution') or scene.get('attribution_requested'))


def required_visual_sources(timeline,timepoint):
 sources=[];seen=set()
 for clip in timeline['clips']:
  scene=SCENE_MAP[clip['scene_id']]
  if clip['start']<=timepoint<clip['end'] and needs_visual_credit(scene) and scene.get('source_url') not in seen:
   sources.append(scene);seen.add(scene['source_url'])
 return sources

def draw_visual_credits(im,sources,width,height):
 """CC BY and requested NPS source credits stay outside Quran text, including transitions."""
 if not sources:return
 d=ImageDraw.Draw(im);scale=width/540
 lines=[]
 for scene in sources:
  lines.extend([
   f"{scene.get('source_credit_title',scene['name'])} | {scene.get('copyright_notice') or scene['author']} | {scene.get('license_label') or scene.get('license','CC-BY-3.0').replace('CC-BY-','CC BY ')} | crop/trim, muted",
   f"{scene.get('source_short_url',scene['source_url'])} | {scene.get('license_url','https://creativecommons.org/licenses/by/3.0/')}",
  ])
 line_h=min(14*scale,height*.063/len(lines));top=height*.987-len(lines)*line_h
 d.rounded_rectangle((width*.025,top-5*scale,width*.975,height*.991),radius=5*scale,fill=(0,0,0,195))
 for i,line in enumerate(lines):
  size=min(11*scale,line_h*.85);font=load_font('Tajawal-Regular.ttf',size)
  while d.textlength(line,font=font)>width*.92 and size>6*scale:
   size-=.5*scale;font=load_font('Tajawal-Regular.ttf',size)
  d.text((width/2,top+(i+.5)*line_h),line,font=font,fill=(250,250,240,245),anchor='mm',direction='ltr')

def glyph_mask_probe(mask):
 """Retain real antialiased stroke evidence at user-selected small sizes, not 50 hard pixels."""
 alpha=np.asarray(mask,dtype=np.uint8);nonzero=alpha[alpha>0]
 if not len(nonzero):return None
 threshold=245
 if np.count_nonzero(alpha>threshold)<50:threshold=max(160,min(245,int(np.quantile(nonzero,.8))-1))
 count=int(np.count_nonzero(alpha>threshold))
 if count<3:return None
 return {'alpha_threshold':threshold,'stroke_pixels':count}


def write_overlays(config,timeline,folder,width,height,fps,return_pages=False):
 pages=[]
 for cue in timeline['cues']:
  face=composition.fit_verse_font(config.text_style,quran_font(config),cue['text'],width)
  _,column_width=composition.column(config.text_style,width)
  lines=composition.wrap_exact(cue['text'],face,column_width)
  chunks=composition.paginate_lines(lines,face,config.text_style.line_height,height*composition.SPEC['verse_page_max_height'],composition.SPEC['verse_min_line_gap']*width/1080)
  weights=[sum(len(s) for s in c) for c in chunks];total=max(1,sum(weights));pos=cue['start']
  for i,chunk in enumerate(chunks):
   end=cue['end'] if i==len(chunks)-1 else pos+(cue['end']-cue['start'])*weights[i]/total
   page={**cue,'start':pos,'end':end,'lines':chunk,'page':i+1,'pages':len(chunks),'render_font_size':face.size}
   page['layout']=layout_for_page(config,page,chunk,width,height);pages.append(page);pos=end
 boundaries={0,round(timeline['duration']*fps)}
 for p in pages:boundaries.update([round(p['start']*fps),round(p['end']*fps)])
 for clip in timeline['clips']:
  if needs_visual_credit(SCENE_MAP[clip['scene_id']]):boundaries.update([round(clip['start']*fps),round(clip['end']*fps)])
 bounds=sorted(boundaries);items=['ffconcat version 1.0'];first_mask=None;audit=[];seen_pages=set()
 for i,(a,b) in enumerate(zip(bounds,bounds[1:])):
  if b<=a:continue
  timepoint=(a+b)/2/fps
  page=next((p for p in pages if p['start']<=timepoint<p['end']),None)
  im,mask=make_overlay(config,page,page['lines'] if page else [],width,height)
  draw_visual_credits(im,required_visual_sources(timeline,timepoint),width,height)
  p=folder/f'text_{i:03}.png';im.save(p,compress_level=1)
  items += [f"file '{p.as_posix()}'",f'option framerate {fps}',f'duration {(b-a)/fps:.9f}']
  if page:
   identity=(page['key'],page['page'],page['start'],page['end'])
   if identity not in seen_pages:audit.append({k:v for k,v in page.items() if k not in ['lines','layout']});seen_pages.add(identity)
   probe=glyph_mask_probe(mask)
   if first_mask is None and probe:
    mask.save(folder/'first_text_mask.png');first_mask={'time':timepoint,'mask':str(folder/'first_text_mask.png'),'color':config.text_style.color,**probe}
 items += [f"file '{p.as_posix()}'",f'option framerate {fps}']
 (folder/'text.ffconcat').write_text('\n'.join(items)+'\n')
 return (audit,first_mask,pages) if return_pages else (audit,first_mask)

def cleanup_orphaned_exports():
 """Called before the single export worker starts; never remove completed deliverables."""
 count=0
 for work in EXPORTS.glob('*/.cache/video-stages'):
  if work.is_dir():shutil.rmtree(work);count+=1
 for pattern in ['result.partial.mp4','clip_*.mp4','text_*.png','*.wav','*.ffconcat','first_text_mask.png','fx_*.png','fx_*.txt']:
  for file in EXPORTS.glob('*/'+pattern):
   if file.is_file():file.unlink(missing_ok=True);count+=1
 return count


def render(config,plan,jid,progress,canceled,on_process):
 # Serialize the expensive encoder even when a CLI/test process shares this runtime.
 # Never silently remove Full HD or transitions to make a render fit memory.
 announced=False
 while True:
  if canceled():raise Canceled()
  try:RENDER_SLOT.acquire(timeout=.25);break
  except FileLockTimeout:
   if not announced:progress(30,'بانتظار دور محرك التصدير — المشروع محفوظ');announced=True
 try:return _render(config,plan,jid,progress,canceled,on_process)
 finally:RENDER_SLOT.release()


def _render(config,plan,jid,progress,canceled,on_process):
 qtext=quran_source(getattr(config,'narration','hafs'))
 if plan.get('source_sha256')!=qtext['sha256'] or plan.get('narration','hafs')!=getattr(config,'narration','hafs') or plan.get('reciter',config.reciter)!=config.reciter:
  raise EngineError('مصدر النص أو رواية التلاوة لا يتطابقان؛ أُوقف التصدير لمنع خلط حفص وورش.','NARRATION_MISMATCH')
 audio_provider=plan['verses'][0].get('source_provider','EveryAyah') if plan.get('verses') else 'EveryAyah'
 timeline=timing_and_clips(config,plan);q=QUALITIES[config.quality]
 width,height,fps=q['width'],q['height'],q['fps']
 disk=free_space_check(timeline['duration'],config.quality)
 folder=EXPORTS/jid;folder.mkdir(parents=True,exist_ok=True)
 partial=folder/'result.partial.mp4';final=folder/'result.mp4'
 overlay_thread=None;overlay_stop=threading.Event();overlay_errors=[];proc=None
 try:
  source=AUDIO/plan['id']/'combined.wav'
  with sf.SoundFile(source) as inp:
   inp.seek(round(timeline['audio_start']*48000))
   data=inp.read(round(timeline['duration']*48000),dtype='float32')
  sf.write(folder/'trimmed.wav',data,48000,subtype='PCM_16')
  del data
  progress(31,'تجهيز المشاهد وترتيبها')
  for i,c in enumerate(timeline['clips']):
   if canceled():raise Canceled()
   try:src=ensure_scene_asset(c['scene_id'],canceled,lambda value,msg:progress(31+7*(i+value)/len(timeline['clips']),msg))
   except SceneAssetError as exc:
    if canceled():raise Canceled()
    raise EngineError(str(exc),'SCENE_DOWNLOAD')
   target=folder/f'clip_{i}.mp4'
   # Trim source content once; stream_loop then repeats this exact selected range.
   run_checked(['-ss',str(c['source_in']),'-i',str(src),'-t',str(c['source_out']-c['source_in']),'-an','-c:v','libx264','-preset','ultrafast','-crf','21','-threads','1','-pix_fmt','yuv420p',str(target)])
   progress(32+6*(i+1)/len(timeline['clips']),f"تجهيز المشهد {i+1} من {len(timeline['clips'])}")
  audit_cues,mask,pages=write_overlays(config,timeline,folder,width,height,fps,return_pages=True)
  dynamic_overlay=raw_overlay_required(config,timeline)
  if mask and config.effects.verse.enabled and config.effects.verse.intensity>0:
   first=pages[0];phase=.78 if config.effects.verse.kind=='reveal' else .5
   mask['time']=first['start']+(first['end']-first['start'])*phase
  if not mask:raise EngineError('لم ينتج محرك النص أي حروف مرئية؛ أوقف التصدير لحماية النص.','TEXT_RENDER')
  background,background_report=prepare_background(sys.modules[__name__],config,timeline,[folder/f'clip_{i}.mp4' for i in range(len(timeline['clips']))],folder,width,height,fps,canceled,on_process,progress)
  progress(68,'تركيب الفيديو والصوت والآيات على مسار خلفية واحد')
  cmd=[FFMPEG,'-hide_banner','-y','-loglevel','warning','-filter_complex_threads','1','-filter_threads','1','-threads','1','-thread_queue_size','2','-reinit_filter','0','-f','concat','-safe','0','-i',str(background)]
  n=1;cmd+=['-thread_queue_size','4','-i',str(folder/'trimmed.wav')]
  if dynamic_overlay:cmd+=['-thread_queue_size','2','-f','rawvideo','-pixel_format','rgba','-video_size',f'{width}x{height}','-framerate',str(fps),'-i','pipe:0']
  else:cmd+=['-threads','1','-thread_queue_size','2','-f','concat','-safe','0','-i',str(folder/'text.ffconcat')]
  filters=[f'[0:v]fps={fps},setsar=1,settb=1/{fps},format=yuv420p[background]',f'[2:v]format=rgba,setsar=1,fps={fps},settb=1/{fps}[text]','[background][text]overlay=eof_action=repeat:format=auto,format=yuv420p[out]']
  visual_sources=[{k:SCENE_MAP[c['scene_id']].get(k) for k in ['id','name','kind','license','license_url','author','source_url','source_title','source_short_url','source_credit_title','source_start','adaptation','requires_attribution','copyright_notice','sha256','availability','attribution_requested','license_label','family','lighting','camera_motion','source_sha256','source_width','source_height','source_fps','source_duration','remote_source','portrait_crop']} for c in timeline['clips']]
  visual_credit='\n\n'.join(str(v['name'])+' / '+str(v.get('source_title') or 'Original procedural animation')+'\nAuthor: '+str(v['author'])+'\nCopyright notice: '+str(v.get('copyright_notice') or '')+'\nLicense: '+str(v['license'])+' '+str({'CC-BY-3.0':'https://creativecommons.org/licenses/by/3.0/','CC0-1.0':'https://creativecommons.org/publicdomain/zero/1.0/'}.get(v['license'],v.get('license_url') or ''))+'\nSource: '+str(v.get('source_url') or 'Ayat project, original animation')+'\nChanges: '+str(v.get('adaptation') or 'Original motion; selected and composited into the reel.') for v in visual_sources)
  cmd+=['-filter_complex',';'.join(filters),'-map','[out]','-map',f'{n}:a:0','-frames:v',str(background_report['frame_plan']['frames']),'-r',str(fps),'-c:v','libx264','-preset',q['preset'],'-crf',str(q['crf']),'-pix_fmt','yuv420p','-threads','2','-x264-params','rc-lookahead=8:sync-lookahead=0','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-c:a','aac','-b:a','160k','-ar','48000','-ac','2','-movflags','+faststart','-metadata','title=Ayat — '+config.title,'-metadata','comment='+qtext['notice']+'\nRecitation: '+RECITER_MAP[config.reciter]['name']+' via '+audio_provider+'.\nNarration: '+getattr(config,'narration','hafs')+'\nVisual sources (per-source licenses):\n'+visual_credit,'-progress','pipe:1','-stats_period','0.5','-nostats',str(partial)]
  (folder/'command.json').write_text(json.dumps(cmd,ensure_ascii=False,indent=2))
  with (folder/'ffmpeg.log').open('w') as log:
   proc=subprocess.Popen(cmd,stdin=subprocess.PIPE if dynamic_overlay else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=log,text=True,start_new_session=True)
   on_process(proc)
   if dynamic_overlay:
    painter=OverlayPainter(sys.modules[__name__],config,timeline,pages,width,height,fps)
    def write_frames():
     try:painter.stream(proc.stdin.buffer,canceled,overlay_stop)
     except BrokenPipeError:pass # FFmpeg's real error is read from stderr below.
     except Exception as exc:
      overlay_errors.append(str(exc))
      try:proc.terminate()
      except Exception:pass
     finally:
      try:proc.stdin.close()
      except Exception:pass
    overlay_thread=threading.Thread(target=write_frames,name='ayat-visual-frames',daemon=True);overlay_thread.start()
   for line in proc.stdout:
    if canceled():
     proc.terminate();proc.wait(timeout=8);raise Canceled()
    if line.startswith('out_time_us='):
     try:position=int(line.split('=',1)[1])/1_000_000
     except ValueError:continue
     progress(min(93,68+25*position/timeline['duration']),'تصدير الفيديو · '+str(min(99,round(position/timeline['duration']*100)))+'٪')
   rc=proc.wait();overlay_stop.set()
   if overlay_thread:overlay_thread.join(timeout=10)
   on_process(None)
  if overlay_errors:raise EngineError('تعذر توليد طبقة المؤثرات: '+overlay_errors[0][:400],'EFFECTS_GRAPHICS')
  if canceled():raise Canceled()
  if rc:
   if rc in [-9,137]:raise EngineError('أوقف النظام محرك الفيديو بسبب ضغط الموارد أو إنهاء العملية. أعد المحاولة بعد انتهاء المهام الأخرى؛ جودة 1080p ما زالت متاحة.','RESOURCE_LIMIT')
   error=(folder/'ffmpeg.log').read_text()[-2000:]
   if 'No space left' in error:raise EngineError('نفدت المساحة أثناء التصدير. المشروع محفوظ؛ حرر مساحة ثم أعد المحاولة.','NO_SPACE')
   raise EngineError('توقف FFmpeg أثناء التصدير. يمكنك إعادة المحاولة. '+error[-450:],'FFMPEG_FAILED')
  if not partial.exists() or partial.stat().st_size<5000:raise EngineError('لم ينتج ملف فيديو صالح.','INVALID_OUTPUT')
  progress(95,'فحص ملف MP4 والصوت وظهور النص')
  run_checked(['-i',str(partial),'-f','null','-'],timeout=max(60,timeline['duration']*2))
  png=run_checked(['-ss',str(mask['time']),'-i',str(partial),'-frames:v','1','-f','image2pipe','-vcodec','png','pipe:1'])
  image=Image.open(BytesIO(png)).convert('RGB')
  if image.size!=(width,height):raise EngineError('أبعاد الفيديو الناتج غير صحيحة.','OUTPUT_DIMENSIONS')
  arr=np.array(image,dtype=np.float32);alpha=np.array(Image.open(mask['mask']));m=alpha>mask.get('alpha_threshold',245)
  foreground=np.array(rgb(mask['color']));worst_background_distance=float(np.linalg.norm(np.maximum(foreground,255-foreground)))
  # Alpha-aware tolerance accounts for actual antialiased edges; empty masks still fail.
  tolerance=65+np.maximum(0,245-alpha[m].astype(float))/255*worst_background_distance
  matches=np.linalg.norm(arr[m]-foreground,axis=1)<tolerance
  ratio=float(np.mean(matches)) if len(matches) else 0
  if ratio<.52:raise EngineError('تعذر التحقق من ظهور نص الآية داخل الفيديو؛ أُوقف حفظ الملف النهائي.','TEXT_NOT_VISIBLE')
  pcm=run_checked(['-i',str(partial),'-vn','-t',str(min(4,timeline['duration'])),'-f','f32le','-ac','1','-ar','16000','pipe:1'])
  sound=np.frombuffer(pcm,dtype=np.float32)
  if not len(sound) or not np.isfinite(sound).all() or np.max(np.abs(sound))<.001:raise EngineError('لم يُكتشف صوت صالح في الفيديو المُصدّر.','OUTPUT_SILENT')
  image.save(folder/'cover.jpg',quality=92)
  os.replace(partial,final)
  result={'job_id':jid,'duration':timeline['duration'],'width':width,'height':height,'fps':fps,'bytes':final.stat().st_size,'file_url':f'/api/jobs/{jid}/file','stream_url':f'/api/jobs/{jid}/stream','open_url':f'/api/jobs/{jid}/open','notice_url':f'/api/jobs/{jid}/notice','visual_attribution_burned':any(needs_visual_credit(v) for v in visual_sources),'cover_url':f'/api/jobs/{jid}/cover','audit_url':f'/api/jobs/{jid}/audit','source_sha256':qtext['sha256'],'narration':getattr(config,'narration','hafs'),'render_resource_policy':RENDER_RESOURCE_POLICY,'text_visible_ratio':ratio,'text_layout_version':composition.VERSION,'text_visibility_probe':{'alpha_threshold':mask.get('alpha_threshold',245),'stroke_pixels':mask.get('stroke_pixels',0)},'audio_peak':float(np.max(np.abs(sound))),'timeline':timeline,'disk_preflight':disk}
  audit={'result':result,'config':config.model_dump(),'quran_source':source_info(getattr(config,'narration','hafs')),'cues':audit_cues,'all_cues_match_source':all(c['text']==qtext['verses'][c['key']] for c in audit_cues),'audio_files':plan['verses'],'visual_sources':visual_sources,'visual_effects':config.effects.model_dump(),'animated_overlay_stream':dynamic_overlay,'render_backend':RENDER_RESOURCE_POLICY['backend'],'render_resources':{'policy':RENDER_RESOURCE_POLICY,'background_scene_count':len(background_report['frame_plan']['scenes']),'background_piece_count':len(background_report['frame_plan']['parts']),'planned_frames':background_report['frame_plan']['frames']},'word_effect_timing':'visual pacing within ayah; NOT recitation word alignment','depth_effect':'optical center/edge focus; NOT reconstructed 3D','audio_timing_method':plan.get('timing_method'),'text_composition':{'version':composition.VERSION,'coordinate_space':'output pixels','strategy':'Measured Arabic ink bounds; surah, verse, reader and source flow together around the selected verse anchor.','pages':[{'key':p['key'],'page':p['page'],'start':p['start'],'end':p['end'],'layout':p['layout']} for p in pages]},'note':'Verse-level timings from decoded recordings, publisher timestamps or registered acoustic boundaries as specified by audio_timing_method. Long verses are paginated proportionally within the verse, not word-aligned. Source text is immutable. Source scenes are original procedural motion or recorded mosque/nature footage. Licenses are per source, not all CC0. Required CC BY credits are burned into the picture (both sources during transitions), embedded in MP4 metadata, and written in NOTICE.txt. No animated photographs or AI mosque substitutions.'}
  (folder/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
  (folder/'NOTICE.txt').write_text('Visual effects: '+json.dumps(config.effects.model_dump(),ensure_ascii=False)+'\nWord animations are visual only, not recitation-word timing.\n'+qtext['notice']+'\nAudio sources:\n'+'\n'.join(v['source_url'] for v in plan['verses'])+'\nVisual assets, PER-SOURCE LICENSES; credits are also burned into the picture when required:\n'+visual_credit+'\n',encoding='utf-8')
  progress(100,'اكتمل التصدير وحُفظ ملف MP4')
  return result
 except Exception:
  partial.unlink(missing_ok=True)
  raise
 finally:
  overlay_stop.set()
  if overlay_thread and overlay_thread.is_alive():
   try:
    if proc and proc.poll() is None:proc.terminate()
   except Exception:pass
   overlay_thread.join(timeout=10)
  on_process(None)
  # Large temporary loop/caption files are not retained after a render.
  shutil.rmtree(folder/'.cache/video-stages',ignore_errors=True)
  for pattern in ['clip_*.mp4','text_*.png','*.wav','*.ffconcat','first_text_mask.png','fx_*.png','fx_*.txt']:
   for p in folder.glob(pattern):p.unlink(missing_ok=True)
