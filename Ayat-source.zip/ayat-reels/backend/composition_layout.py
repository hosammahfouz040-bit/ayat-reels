"""Measured portrait text composition; no Quran text generation or normalization.

The verse's visible ink is the anchor, not an unrelated top/bottom HUD or N*line-height.
Both PNG overlays and the animated RGBA stream consume the same pixel geometry.
Stored project coordinates/fonts are not rewritten. Legal footage credits remain separate.
"""
from functools import lru_cache
from pathlib import Path
import json,math
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent
SPEC=json.loads((ROOT/'data/composition-layout.json').read_text())
VERSION=SPEC['version']
MEASURE=ImageDraw.Draw(Image.new('L',(2,2)))

@lru_cache(maxsize=256)
def font(name,size):
 return ImageFont.truetype(str(ROOT/'fonts'/name),max(6,int(size)),layout_engine=ImageFont.Layout.RAQM)

def ink(text,face):
 return tuple(float(v) for v in MEASURE.textbbox((0,0),text,font=face,anchor='mm',direction='rtl',language='ar'))

def advance(text,face):return float(MEASURE.textlength(text,font=face,direction='rtl',language='ar'))

def measured_width(text,face):
 rect=ink(text,face);return max(advance(text,face),rect[2]-rect[0])

def union(rects):
 rows=[r for r in rects if r]
 return [min(r[0] for r in rows),min(r[1] for r in rows),max(r[2] for r in rows),max(r[3] for r in rows)] if rows else [0.,0.,0.,0.]

def move_rect(rect,dx=0,dy=0):return [rect[0]+dx,rect[1]+dy,rect[2]+dx,rect[3]+dy]

def wrap_exact(text,face,width):
 """Only choose line breaks at original spaces; never remove Quran glyphs/diacritics."""
 lines=[];line=''
 for word in text.split(' '):
  trial=word if line=='' else line+' '+word
  if line and measured_width(trial,face)>width:lines.append(line);line=word
  else:line=trial
 if line:lines.append(line)
 return lines

def column(style,width):
 scale=width/1080;pad=SPEC['verse_padding_x']*scale;safe=width*SPEC['safe_horizontal']
 available=max(1,width-2*(safe+pad));w=min(width*style.max_width,available)
 lo=safe+pad+w/2;hi=width-safe-pad-w/2
 x=max(lo,min(hi,width*style.x))
 return x,w

def fit_verse_font(style,font_name,text,width):
 """Respect the selected size unless a single unbreakable word would leave the column."""
 _,w=column(style,width);desired=max(12,int(style.size*width/1080));size=desired
 while size>12:
  face=font(font_name,size)
  if max([measured_width(word,face) for word in text.split(' ')] or [0])<=w+.01:return face
  size-=1
 return font(font_name,size)

def measured_lines(lines,face,line_height,min_gap=0):
 if not lines:return [],[0.,0.,0.,0.],0.
 boxes=[ink(text,face) for text in lines]
 # A low line-height must never let Arabic marks collide with the next line.
 step=max(float(face.size)*line_height,max([boxes[i][3]-boxes[i+1][1]+min_gap for i in range(len(boxes)-1)] or [0]))
 placed=[{'text':text,'x':0.,'y':i*step,'ink':move_rect(box,dy=i*step)} for i,(text,box) in enumerate(zip(lines,boxes))]
 return placed,union([p['ink'] for p in placed]),step

def paginate_lines(lines,face,line_height,max_height,min_gap=0):
 pages=[];chunk=[]
 for line in lines:
  candidate=chunk+[line];_,rect,_=measured_lines(candidate,face,line_height,min_gap)
  if chunk and rect[3]-rect[1]>max_height+.01:pages.append(chunk);chunk=[line]
  else:chunk=candidate
 if chunk:pages.append(chunk)
 return pages

def align_lines(lines,face,line_height,cx,column_width,alignment,top,min_gap=0):
 placed,relative,step=measured_lines(lines,face,line_height,min_gap)
 shift_y=top-relative[1]
 for item in placed:
  box=ink(item['text'],face)
  x=cx-(box[0]+box[2])/2 if alignment=='center' else cx+column_width/2-box[2]
  item['x']=x;item['y']+=shift_y;item['ink']=move_rect(box,x,item['y'])
 return placed,union([p['ink'] for p in placed]),step

def label(text,size,width,cx,column_width,alignment,top,font_name='Tajawal-Medium.ttf'):
 # Keep full reader/surah names. Shrink modestly, then wrap; never ellipsize.
 desired=max(6,int(size));minimum=max(6,math.floor(desired*.78));s=desired
 while s>minimum and measured_width(text,font(font_name,s))>column_width:s-=1
 face=font(font_name,s);lines=wrap_exact(text,face,column_width)
 runs,rect,step=align_lines(lines,face,SPEC['metadata_line_height'],cx,column_width,alignment,top)
 return {'text':text,'font':font_name,'font_size':face.size,'lines':runs,'ink_bbox':rect,'line_step':step}

def _shift_component(component,dy):
 component['ink_bbox']=move_rect(component['ink_bbox'],dy=dy)
 for run in component['lines']:run['y']+=dy;run['ink']=move_rect(run['ink'],dy=dy)


def compose(style,font_name,lines,width,height,surah,reader,source,number=None,narration='hafs',font_size=None,verse_motion=0,glow_bleed=0):
 """Return serializable output-pixel geometry used for the actual exported overlay."""
 scale=width/1080;cx,cw=column(style,width)
 face=font(font_name,font_size if font_size is not None else style.size*scale)
 runs,rect,step=align_lines(lines,face,style.line_height,cx,cw,style.alignment,0,SPEC['verse_min_line_gap']*scale)
 # Center visible Quran ink at y=0 first; retain conventional equal-baseline leading.
 mid=(rect[1]+rect[3])/2 if runs else 0
 for run in runs:run['y']-=mid;run['ink']=move_rect(run['ink'],dy=-mid)
 rect=move_rect(rect,dy=-mid)
 verse={'font':font_name,'font_size':face.size,'requested_font_size':style.size*scale,'lines':runs,'ink_bbox':rect,'line_step':step}
 content=rect.copy();marker=None
 if runs and narration!='warsh' and number is not None:
  marker_text='﴿ '+str(number).translate(str.maketrans('0123456789','٠١٢٣٤٥٦٧٨٩'))+' ﴾'
  marker=label(marker_text,min(face.size*SPEC['number_ratio'],SPEC['number_max_size']*scale),width,cx,cw,'center',rect[3]+SPEC['number_gap']*scale)
  content=union([rect,marker['ink_bbox']])
 px=SPEC['verse_padding_x']*scale;py=SPEC['verse_padding_y']*scale
 box=[cx-cw/2-px,content[1]-py,cx+cw/2+px,content[3]+py]
 # Reserve movement/shadow space so an enabled verse effect cannot run into labels.
 bleed=max(verse_motion,glow_bleed)
 title=label(surah,min(face.size*SPEC['surah_ratio'],SPEC['surah_max_size']*scale),width,cx,cw,style.alignment,0)
 title_h=title['ink_bbox'][3]-title['ink_bbox'][1]
 divider_y=box[1]-bleed-SPEC['divider_verse_gap']*scale-SPEC['divider_thickness']*scale/2
 title_top=divider_y-SPEC['divider_thickness']*scale/2-SPEC['surah_divider_gap']*scale-title_h
 _shift_component(title,title_top-title['ink_bbox'][1])
 reader_component=label(reader,min(face.size*SPEC['reader_ratio'],SPEC['reader_max_size']*scale),width,cx,cw,style.alignment,box[3]+bleed+SPEC['verse_reader_gap']*scale)
 source_component=label(source,min(face.size*SPEC['source_ratio'],SPEC['source_max_size']*scale),width,cx,cw,style.alignment,reader_component['ink_bbox'][3]+SPEC['reader_source_gap']*scale,'Tajawal-Regular.ttf')
 extent=union([title['ink_bbox'],box,reader_component['ink_bbox'],source_component['ink_bbox']])
 safe_top=height*SPEC['safe_top'];safe_bottom=height*SPEC['safe_bottom']
 low=safe_top-extent[1];high=safe_bottom-extent[3]
 if low>high+.1:raise ValueError('Text composition exceeds the safe portrait region; use pagination or a smaller font.')
 desired=height*style.y;cy=max(low,min(high,desired))
 for item in [verse,title,reader_component,source_component]+([marker] if marker else []):_shift_component(item,cy)
 box=move_rect(box,dy=cy);extent=move_rect(extent,dy=cy);divider_y+=cy
 dw=min(width*SPEC['divider_width'],cw*.35);dx2=cx+cw/2 if style.alignment=='right' else cx+dw/2;dx1=dx2-dw
 return {'version':VERSION,'width':width,'height':height,'column_center_x':cx,'column_width':cw,'requested_verse_center_y':desired,'verse_center_y':cy,'position_safety_clamped':abs(cy-desired)>.1,'alignment':style.alignment,'group_bbox':extent,'verse_box':box,'verse':verse,'number':marker,'surah':title,'reader':reader_component,'source':source_component,'divider':{'x1':dx1,'x2':dx2,'y':divider_y,'thickness':max(1,round(SPEC['divider_thickness']*scale))},'effect_bleed':bleed,'safe_region':[width*SPEC['safe_horizontal'],safe_top,width*(1-SPEC['safe_horizontal']),safe_bottom]}
