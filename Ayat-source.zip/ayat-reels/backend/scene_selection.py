"""Relevant-scene selection with fair non-repetition rounds and pending reservations.
Only successful rendered clips consume history; suggestions and previews do not.
"""
import random,threading
import storage
from catalog import SCENES
SELECTION_LOCK=threading.RLock()

class SceneSelectionError(ValueError):pass

def select_scenes(workspace,count=3,mood=None,category=None,subject=None,exclude=None,preferred=None,avoid_repeat=True,rng=None,include_remote=True,availability=None):
 excluded=set(exclude or []);preferred=list(preferred or []);rng=rng or random.SystemRandom()
 candidates=[s for s in SCENES if (not availability or s.get('availability','bundled')==availability) and (include_remote or s.get('availability')!='on-demand') and s['id'] not in excluded and (not mood or mood in s['moods']) and (not category or category=='all' or s['category']==category) and (not subject or subject=='all' or (subject=='original' and s['kind']=='original-motion-video') or s.get('subject')==subject)]
 if not candidates:raise SceneSelectionError('لا توجد بدائل مناسبة لهذه الفئة والمزاج. غيّر المرشح؛ لن نستبدلها بمشهد غير مناسب خفية.')
 history=storage.scene_usage(workspace);pending=storage.pending_scene_reservations(workspace)
 virtual={s['id']:history['scenes'].get(s['id'],{}).get('uses',0)+pending.get(s['id'],0) for s in candidates}
 selected=[];rounds=[]
 for _ in range(min(count,len(candidates))):
  remaining=[s for s in candidates if s['id'] not in selected]
  floor=min(virtual[s['id']] for s in remaining) if avoid_repeat else 0
  eligible=[s for s in remaining if not avoid_repeat or virtual[s['id']]==floor]
  # Preserve template preference only among equally unused/reused alternatives.
  preferred_eligible=[x for ident in preferred for x in eligible if x['id']==ident]
  choice=preferred_eligible[0] if preferred_eligible else rng.choice(eligible)
  selected.append(choice['id']);rounds.append(floor);virtual[choice['id']]+=1
 return {'scene_ids':selected,'candidate_count':len(candidates),'selected_count':len(selected),'avoid_repeat':avoid_repeat,'rounds':rounds,'epoch':history['epoch'],'history_recorded':False,'pending_reservations_considered':bool(pending),'scope':{'mood':mood,'category':category,'subject':subject},'note':'تُستهلك البدائل الأقل استخدامًا أولًا، ويعاد استخدامها بعد استنفاد المناسب. لا يتكرر مشهد داخل الاختيار نفسه.'}
