"""Real tiny MP4s exercise cache integrity, cancellation and provider cooldowns."""
from pathlib import Path
import sys,json,hashlib,time,threading
from concurrent.futures import ThreadPoolExecutor
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import scene_assets,catalog

@pytest.fixture
def tiny_scene(tmp_path,monkeypatch):
 original=Path(__file__).resolve().parents[1]/'media/beach.mp4';data=original.read_bytes();sha=hashlib.sha256(data).hexdigest();ident='unit_remote_real_motion'
 row={'id':ident,'name':'Unit fixture from existing real beach footage','availability':'on-demand','remote_source':{'sha256':sha,'bytes':len(data),'in':.5,'url':'https://www.nps.gov/nps-audiovideo/unit-fixture-not-downloaded.mp4'},'portrait_crop':{'x':.5,'y':.5},'width':180,'height':320,'fps':12,'duration':1,'video':'/api/media/'+ident+'.mp4'}
 monkeypatch.setattr(scene_assets,'CACHE',tmp_path);monkeypatch.setattr(scene_assets,'SCENE_MAP',{ident:row});monkeypatch.setattr(scene_assets,'VERIFIED',{});monkeypatch.setattr(scene_assets,'TASKS',{})
 folder=tmp_path/'sources';folder.mkdir();(folder/(sha+'.media')).write_bytes(data)
 return ident,row,tmp_path


def test_real_muted_portrait_output_has_checked_geometry_duration_and_hash_receipt(tiny_scene):
 ident,row,cache=tiny_scene;p=scene_assets.ensure_scene_asset(ident);receipt=json.loads(p.with_suffix('.json').read_text())
 assert scene_assets.asset_ready(ident) and scene_assets.asset_status(ident)['state']=='ready'
 assert (receipt['width'],receipt['height'],receipt['fps'])==(180,320,12)
 assert abs(receipt['duration']-1)<.085 and receipt['muted'] and receipt['full_decode_exit']==0 and receipt['sha256']==scene_assets.sha_file(p)
 assert receipt['source_sha256']==row['remote_source']['sha256'] and receipt['recipe']==scene_assets.recipe(row)


def test_corrupted_cached_clip_is_not_called_ready_and_can_be_rebuilt(tiny_scene):
 ident,row,cache=tiny_scene;p=scene_assets.ensure_scene_asset(ident);original=p.read_bytes();p.write_bytes(original+b'corrupt unit fixture')
 assert not scene_assets.asset_ready(ident) and scene_assets.asset_status(ident)['state']=='failed'
 scene_assets.ensure_scene_asset(ident);assert p.read_bytes()==original and scene_assets.asset_ready(ident)
 p.with_suffix('.json').unlink();assert not scene_assets.asset_ready(ident)


def test_changed_crop_recipe_requires_new_preparation_not_silent_old_video(tiny_scene):
 ident,row,cache=tiny_scene;p=scene_assets.ensure_scene_asset(ident);old=json.loads(p.with_suffix('.json').read_text())['recipe'];row['portrait_crop']['zoom']=1.2
 assert not scene_assets.asset_ready(ident);scene_assets.ensure_scene_asset(ident);new=json.loads(p.with_suffix('.json').read_text())
 assert new['recipe']!=old and new['crop']['zoom']==1.2 and scene_assets.asset_ready(ident)


def test_two_callers_encode_the_same_scene_once(tiny_scene,monkeypatch):
 ident,row,cache=tiny_scene;calls=[];original=scene_assets._run
 def checked(args,*a,**kw):
  if 'libx264' in args:calls.append(1)
  return original(args,*a,**kw)
 monkeypatch.setattr(scene_assets,'_run',checked)
 with ThreadPoolExecutor(max_workers=2) as pool:assert len(set(pool.map(lambda _:str(scene_assets.ensure_scene_asset(ident)),[1,2])))==1
 assert len(calls)==1


def test_cancellation_kills_active_encoding_instead_of_waiting_for_completion():
 started=time.monotonic()
 with pytest.raises(scene_assets.SceneAssetError,match='أُلغي'):
  scene_assets._run(['-f','lavfi','-i','testsrc=size=320x568:rate=24','-t','600','-f','null','-'],canceled=lambda:time.monotonic()-started>.05)
 assert time.monotonic()-started<1.5


def test_active_publisher_cooldown_refuses_network_without_alternate_host(tiny_scene,monkeypatch):
 ident,row,cache=tiny_scene;(cache/'sources'/(row['remote_source']['sha256']+'.media')).unlink()
 (cache/'download-cooldown-www.nps.gov.json').write_text(json.dumps({'resume_at':time.time()+60}))
 monkeypatch.setattr(scene_assets.httpx,'Client',lambda *a,**kw:pytest.fail('A live provider cooldown must not be bypassed.'))
 with pytest.raises(scene_assets.SceneAssetError,match='مهلة'):scene_assets.ensure_scene_asset(ident)
 assert not list(cache.glob('*.mp4'))


def test_twenty_four_registered_excerpts_are_distinct_real_reviewed_sources_not_stills():
 remote=[s for s in catalog.SCENES if s.get('availability')=='on-demand'];assert len(remote)==24 and len(catalog.SCENES)==72
 assert len({s['sha256'] for s in remote})==24 and len({s['poster_sha256'] for s in remote})==24
 assert len({s['family'] for s in remote})>=10
 for s in remote:
  assert s['kind']=='real-footage' and s['subject']=='nature' and s['reviewed_on']=='2026-10-25'
  assert s['motion_difference']>.5 and s['all_frames_fully_decoded'] and not s['native_portrait_4k']
  assert (s['width'],s['height'],s['fps'])==(720,1280,24)
  assert s['license']=='Public-domain-USGov' and s['remote_source']['url'].startswith('https://www.nps.gov/nps-audiovideo/')
  assert s['remote_source']['sha256']==s['source_sha256']
