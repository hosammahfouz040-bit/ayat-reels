"""Source separation, availability and real-recording safeguards for the two readers."""
from pathlib import Path
import sys,json,gzip,hashlib,uuid
import pytest
from fastapi.testclient import TestClient
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import quran,catalog,media_engine,curated_audio,app
from models import ProjectConfig,AudioRequest,ExportRequest

HAFS_SHA='203f0f1bf3158b1e5be4ab9f8f6870e570aab6d9a626fe6192a70b75d4afe0fd'
WARSH_SHA='1afd0c853e29ddfa0111731f45d46792d42d850f571b10931c31eeec9ebd8ce3'

def test_unchanged_hafs_and_independent_publisher_pinned_warsh():
 assert quran.QURAN['sha256']==HAFS_SHA and len(quran.SOURCE_VERSES)==6236
 raw=gzip.decompress((quran.ROOT/'data/quran-warsh-source.json.gz').read_bytes())
 assert hashlib.sha256(raw).hexdigest()==WARSH_SHA
 rows=json.loads(raw)
 assert len(rows)==6214 and len({r['sura_no'] for r in rows})==114
 assert {f"{r['sura_no']}:{r['aya_no']}":r['aya_text_unicode'] for r in rows}==quran.WARSH['verses']
 assert quran.WARSH_META['source_archive_sha256']=='d79b0e9d71696e6967a8f9051e62da87e3ad797e76c6b9d931d66fcf7739bbda'
 assert quran.WARSH_META['all_6214_text_fields_match_official_xml']
 assert hashlib.sha256((quran.ROOT/'fonts/KFGQPCWarsh.ttf').read_bytes()).hexdigest()==quran.WARSH_META['font_sha256']

def test_narration_has_its_own_numbering_and_never_uses_hafs_text_for_warsh():
 assert quran.get_verses(1,1,1,'warsh')[0]['text']!=quran.get_verses(1,1,1,'hafs')[0]['text']
 assert quran.get_verses(1,3,3,'warsh')[0]['text']==quran.WARSH_VERSES['1:3']
 assert quran.get_verses(2,286,286,'hafs')
 with pytest.raises(ValueError):quran.get_verses(2,286,286,'warsh')
 with pytest.raises(ValueError):quran.quran_source('unsupported')

def test_models_derive_the_recordings_narration_and_reject_mixed_sources():
 assert ProjectConfig(reciter='suhaim').narration=='warsh'
 assert ProjectConfig(reciter='mossad').narration=='hafs'
 assert ProjectConfig().narration=='hafs'
 with pytest.raises(ValueError):ProjectConfig(reciter='suhaim',narration='hafs')
 with pytest.raises(ValueError):ProjectConfig(reciter='alafasy',narration='warsh')


def test_original_forty_records_and_new_two_genuine_readers():
 compatibility=json.loads((quran.ROOT.parent/'tests/readers-compatibility-v13.json').read_text())
 assert compatibility['all_old_reader_records_unchanged'] and compatibility['old_reader_count']==40
 assert len(catalog.RECITERS)==54
 assert {r['id'] for r in catalog.RECITERS if r.get('provider')=='curated-surah'}=={'mossad','suhaim'}
 assert len([r for r in catalog.RECITERS if r.get('provider') not in ['curated-surah','publisher-timed']])==40
 for ident in ['mossad','suhaim']:
  r=catalog.RECITER_MAP[ident];assert r['available_ranges']
  assert all(v['full_decode_exit']==0 and v['peak']>.001 for v in r['verification_samples'])


def test_registered_intervals_are_pinned_nonoverlapping_and_individually_checked():
 baseline=json.loads((quran.ROOT.parent/'tests/reader-library-v13-baseline.json').read_text())
 stable=lambda value:hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
 assert baseline['recordings_count']==6 and baseline['intervals_count']==33
 for reciter,tracks in baseline['recordings'].items():
  for chapter,digest in tracks.items():assert stable(catalog.CURATED_RECORDINGS[reciter][chapter])==digest
 total=0
 for reciter,tracks in catalog.CURATED_RECORDINGS.items():
  for chapter,r in tracks.items():
   source=quran.quran_source(r['narration']);count=next(s['count'] for s in source['surahs'] if s['id']==int(chapter))
   intervals=r['verse_intervals'];total+=len(intervals);numbers=[v['number'] for v in intervals]
   assert numbers==sorted(set(numbers)) and all(1<=n<=count for n in numbers)
   assert len(r['sha256'])==64 and r['bytes']>1000
   assert all(0<=v['start']<v['end']<=r['duration']+.001 for v in intervals)
   assert all(a['end']<=b['start'] for a,b in zip(intervals,intervals[1:]))
   check=r['timing_validation'];assert check['automatic_validation_passed'] and check['minimum_isolated_clip_similarity']>=.75
   assert check['isolated_clip_check_count']==len(intervals)
   assert check['human_auditory_review_performed'] is False
   advertised=catalog.recording_ranges(int(chapter),r)
   advertised_set={n for part in advertised for n in range(part['from_ayah'],part['to_ayah']+1)}
   assert advertised_set==set(numbers) # No UI range may bridge an unverified gap.
 assert total>=33


def test_unavailable_ayah_ranges_are_rejected_without_reader_substitution():
 AudioRequest(surah=112,from_ayah=1,to_ayah=4,reciter='mossad')
 AudioRequest(surah=1,from_ayah=3,to_ayah=4,reciter='suhaim')
 AudioRequest(surah=2,from_ayah=286,to_ayah=286,reciter='alafasy')
 draft=ProjectConfig(surah=2,from_ayah=1,to_ayah=4,reciter='suhaim') # Draft may be saved for later editing.
 with pytest.raises(ValueError):ExportRequest(config=draft)
 with pytest.raises(ValueError):AudioRequest(surah=2,from_ayah=1,to_ayah=4,reciter='suhaim')
 client=TestClient(app.app)
 response=client.post('/api/audio/prepare',json={'surah':2,'from_ayah':1,'to_ayah':4,'reciter':'mossad'})
 assert response.status_code==422 and 'تلاوة هذا المدى' in response.json()['error']


def test_http_apis_publish_both_sources_with_correct_verse_counts():
 client=TestClient(app.app);c=client.get('/api/catalog').json()
 assert c['app_version']=='1.7.3' and len(c['reciters'])==54
 assert c['sources']['hafs']['sha256']==HAFS_SHA and c['sources']['warsh']['sha256']==WARSH_SHA
 w=client.get('/api/quran/1?narration=warsh').json();h=client.get('/api/quran/1').json()
 assert w['source']['narration']=='warsh' and w['verses'][2]['text']==quran.WARSH_VERSES['1:3']
 assert h['verses'][2]['text']==quran.SOURCE_VERSES['1:3']
 assert client.get('/api/quran/1?narration=unsupported').status_code==422


def test_changed_recording_is_refused_instead_of_using_wrong_timings(tmp_path,monkeypatch):
 class Response:
  content=b'not the pinned recording'
  def raise_for_status(self):pass
 class Client:
  def __init__(self,*a,**k):pass
  def __enter__(self):return self
  def __exit__(self,*a):pass
  def get(self,*a,**k):return Response()
 monkeypatch.setattr(curated_audio.httpx,'Client',Client)
 def no_decode(*a,**k):raise AssertionError('Unverified bytes must never be decoded or rendered.')
 with pytest.raises(curated_audio.CuratedAudioError,match='بصمته'):
  curated_audio.prepare_curated_verse('suhaim',112,1,tmp_path,no_decode)
 assert not list(tmp_path.rglob('*.mp3'))


def test_renderer_refuses_cross_narration_plan_before_opening_audio(tmp_path,monkeypatch):
 monkeypatch.setattr(media_engine,'EXPORTS',tmp_path)
 with pytest.raises(media_engine.EngineError) as exc:
  media_engine.render(ProjectConfig(reciter='suhaim'),{'source_sha256':HAFS_SHA,'narration':'hafs'},str(uuid.uuid4()),lambda *a:None,lambda:False,lambda p:None)
 assert exc.value.code=='NARRATION_MISMATCH' and not list(tmp_path.iterdir())


def test_older_shipped_clients_keep_original_forty_reader_catalog():
 client=TestClient(app.app);headers={'X-Workspace-Id':str(uuid.uuid4())}
 legacy=client.get('/api/catalog',headers=headers).json()
 assert len(legacy['reciters'])==40 and not any(r['id'] in ['suhaim','mossad'] for r in legacy['reciters'])
 modern=client.get('/api/catalog',headers={**headers,'X-Ayat-Capabilities':'reciters-v13,warsh'}).json()
 assert len(modern['reciters'])==42


def test_legacy_client_cannot_play_warsh_with_its_old_hafs_preview():
 client=TestClient(app.app);headers={'X-Workspace-Id':str(uuid.uuid4())}
 r=client.post('/api/audio/prepare',headers=headers,json={'surah':112,'from_ayah':1,'to_ayah':4,'reciter':'suhaim'})
 assert r.status_code==409 and 'حدّث التطبيق' in r.json()['detail']


def test_legacy_client_cannot_export_new_warsh_config_without_capability():
 client=TestClient(app.app);headers={'X-Workspace-Id':str(uuid.uuid4())}
 r=client.post('/api/jobs',headers=headers,json={'config':ProjectConfig(reciter='suhaim').model_dump()})
 assert r.status_code==409 and 'نصه الصحيح' in r.json()['detail']


def test_disjoint_curated_intervals_are_not_misadvertised_as_one_full_range(monkeypatch):
 intervals=[{'number':n} for n in [3,4,5,9,10]]
 assert catalog.recording_ranges(75,{'verse_intervals':intervals})==[
  {'surah':75,'from_ayah':3,'to_ayah':5},{'surah':75,'from_ayah':9,'to_ayah':10}]
 row={'narration':'warsh','verse_intervals':intervals}
 monkeypatch.setitem(catalog.CURATED_RECORDINGS['suhaim'],'75',row)
 catalog.ensure_recitation_range('suhaim',75,3,5)
 with pytest.raises(ValueError):catalog.ensure_recitation_range('suhaim',75,3,10)
 with pytest.raises(ValueError):catalog.ensure_recitation_range('suhaim',75,6,8)


def test_every_preexisting_reader_and_requested_sample_prefix_stays_unchanged():
 baseline=json.loads((quran.ROOT.parent/'tests/reader-library-v13-baseline.json').read_text())
 readers=json.loads((quran.ROOT/'data/reciters.json').read_text());by={r['id']:r for r in readers}
 stable=lambda value:hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
 for ident,digest in baseline['previous_40_reader_record_hashes'].items():assert stable(by[ident])==digest
 for ident,old in baseline['requested_reader_prefixes'].items():
  original={**by[ident],'verification_samples':by[ident]['verification_samples'][:old['samples_count']]}
  assert stable(original)==old['record_hash']


def test_v14_additive_expansion_report_matches_registered_files_and_ranges():
 report=json.loads((quran.ROOT.parent/'tests/reader-expansion-v14.json').read_text())
 assert report['strictly_additive'] and report['all_previous_6_recordings_unchanged'] and report['all_previous_33_intervals_unchanged']
 assert report['new_tracks']==7 and report['new_intervals']==91
 assert len(catalog.CURATED_RECORDINGS['mossad'])==8 and len(catalog.CURATED_RECORDINGS['suhaim'])==5
 assert sum(len(row['verse_intervals']) for tracks in catalog.CURATED_RECORDINGS.values() for row in tracks.values())==124
 for record in report['tracks']:
  if not record['enabled_count']:continue
  row=catalog.CURATED_RECORDINGS[record['reciter']][str(record['surah'])]
  ranges=catalog.recording_ranges(record['surah'],row)
  assert [{'from_ayah':r['from_ayah'],'to_ayah':r['to_ayah']} for r in ranges]==record['ranges']
  assert row['sha256']==record['source_sha256'] and row['bytes']==record['source_bytes']


def test_new_warsh_ranges_use_warsh_counts_and_never_bridge_withheld_verses():
 assert next(s['count'] for s in quran.WARSH_SURAHS if s['id']==75)==39
 assert next(s['count'] for s in quran.WARSH_SURAHS if s['id']==89)==32
 AudioRequest(surah=89,from_ayah=30,to_ayah=32,reciter='suhaim')
 AudioRequest(surah=75,from_ayah=10,to_ayah=13,reciter='suhaim')
 with pytest.raises(ValueError):AudioRequest(surah=75,from_ayah=6,to_ayah=10,reciter='suhaim')
 with pytest.raises(ValueError):AudioRequest(surah=93,from_ayah=3,to_ayah=11,reciter='mossad')
 with pytest.raises(ValueError):AudioRequest(surah=89,from_ayah=1,to_ayah=32,reciter='suhaim')
