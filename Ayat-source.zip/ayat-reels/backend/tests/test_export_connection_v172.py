"""Request-ack recovery/storage tests. Metadata fixtures are not claimed real MP4 exports."""
from pathlib import Path
import sys,json,uuid,threading,types
from concurrent.futures import ThreadPoolExecutor
import pytest
from fastapi.testclient import TestClient
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app,storage
from models import ProjectConfig

@pytest.fixture
def api_state(tmp_path,monkeypatch):
 monkeypatch.setattr(storage,'DB',tmp_path/'test.sqlite3');storage.init_db();monkeypatch.setattr(app,'EXPORTS',tmp_path/'exports');app.EXPORTS.mkdir();calls=[]
 def enqueue(ws,pid,config,request_id=None,request_fingerprint=None):
  calls.append((ws,pid,request_id));return storage.create_job(ws,pid,config,request_id,request_fingerprint)
 monkeypatch.setattr(app,'enqueue',enqueue)
 return TestClient(app.app),str(uuid.uuid4()),calls

def headers(ws,key=None):return {'X-Workspace-Id':ws,'X-Ayat-Capabilities':'warsh,reciters-v13,scene-library-v17,publisher-timing-v1',**({'X-Ayat-Request-Id':key} if key else {})}
def body():return {'config':ProjectConfig(title='Unit export request fixture').model_dump(),'one_click':False}


def test_lost_post_ack_reuses_same_real_request_record_not_new_project_or_job(api_state):
 client,ws,calls=api_state;key=str(uuid.uuid4());payload=body();first=client.post('/api/jobs',headers=headers(ws,key),json=payload);assert first.status_code==200
 repeated=client.post('/api/jobs',headers=headers(ws,key),json=payload);assert repeated.status_code==200 and repeated.json()['id']==first.json()['id']
 found=client.get('/api/jobs/by-request/'+key,headers=headers(ws));assert found.status_code==200 and found.json()['id']==first.json()['id']
 assert len(calls)==1 and len(storage.jobs(ws))==1 and len(storage.projects(ws))==1
 assert storage.scene_usage(ws)['completed_clips']==0


def test_concurrent_same_request_key_only_enqueues_once(api_state):
 client,ws,calls=api_state;key=str(uuid.uuid4());payload=body()
 with ThreadPoolExecutor(max_workers=2) as pool:responses=list(pool.map(lambda _:client.post('/api/jobs',headers=headers(ws,key),json=payload),[1,2]))
 assert all(r.status_code==200 for r in responses) and responses[0].json()['id']==responses[1].json()['id'] and len(calls)==1


def test_one_click_ack_retry_does_not_reselect_or_consume_more_scenes(api_state):
 client,ws,calls=api_state;key=str(uuid.uuid4());payload=body();payload['one_click']=True
 a=client.post('/api/jobs',headers=headers(ws,key),json=payload).json();b=client.post('/api/jobs',headers=headers(ws,key),json=payload).json()
 assert a['id']==b['id'] and a['config']['clips']==b['config']['clips'] and len(calls)==1


def test_request_key_cannot_silently_be_reused_for_changed_config(api_state):
 client,ws,calls=api_state;key=str(uuid.uuid4());payload=body();assert client.post('/api/jobs',headers=headers(ws,key),json=payload).status_code==200
 payload['config']['title']='Changed fixture';assert client.post('/api/jobs',headers=headers(ws,key),json=payload).status_code==409
 assert len(calls)==1


def test_request_lookup_is_scoped_to_workspace_and_404_is_explicit(api_state):
 client,ws,calls=api_state;key=str(uuid.uuid4());client.post('/api/jobs',headers=headers(ws,key),json=body())
 response=client.get('/api/jobs/by-request/'+key,headers=headers(str(uuid.uuid4())));assert response.status_code==404 and response.json()['code']=='EXPORT_REQUEST_NOT_FOUND'
 assert client.post('/api/jobs',headers=headers(ws,'not-a-uuid'),json=body()).status_code==400


def test_retry_ack_is_idempotent_and_original_job_unchanged(api_state):
 client,ws,calls=api_state;original=client.post('/api/jobs',headers=headers(ws),json=body()).json();storage.update_job(original['id'],state='interrupted',error_code='INTERRUPTED');key=str(uuid.uuid4())
 a=client.post('/api/jobs/'+original['id']+'/retry',headers=headers(ws,key));b=client.post('/api/jobs/'+original['id']+'/retry',headers=headers(ws,key))
 assert a.status_code==b.status_code==200 and a.json()['id']==b.json()['id']!=original['id']
 assert storage.get_job(ws,original['id'])['state']=='interrupted' and len(calls)==2


def test_status_responses_are_not_cached_and_completed_missing_file_is_not_advertised(api_state):
 client,ws,calls=api_state;j=client.post('/api/jobs',headers=headers(ws),json=body()).json();storage.update_job(j['id'],state='completed',result={'bytes':1234})
 response=client.get('/api/jobs/'+j['id'],headers=headers(ws));assert response.headers['cache-control']=='no-store' and response.json()['state']=='completed' and response.json()['file_available'] is False
 assert client.get('/api/jobs/'+j['id']+'/file',headers=headers(ws)).status_code==410
 folder=app.EXPORTS/j['id'];folder.mkdir();(folder/'result.mp4').write_bytes(b'unit availability fixture only, not a video')
 assert client.get('/api/jobs/'+j['id'],headers=headers(ws)).json()['file_available'] is True


def test_request_record_survives_database_reopen_without_guessing_job_ids(api_state):
 client,ws,calls=api_state;key=str(uuid.uuid4());j=client.post('/api/jobs',headers=headers(ws,key),json=body()).json();storage.init_db()
 assert storage.get_export_request(ws,key)['job_id']==j['id']
 storage.recover_interrupted();response=client.get('/api/jobs/by-request/'+key,headers=headers(ws));assert response.json()['state']=='interrupted' and response.json()['id']==j['id']


def test_failed_executor_submission_has_terminal_state_not_forever_queued(tmp_path,monkeypatch):
 monkeypatch.setattr(storage,'DB',tmp_path/'test.sqlite3');storage.init_db();ws=str(uuid.uuid4());p=storage.save_project(ws,ProjectConfig(title='Unit queue failure').model_dump());key=str(uuid.uuid4())
 class BrokenExecutor:
  def submit(self,*args,**kwargs):raise RuntimeError('Controlled executor failure fixture')
 monkeypatch.setattr(app,'EXECUTOR',BrokenExecutor())
 with pytest.raises(Exception):app.enqueue(ws,p['id'],p['config'],key,'test-fingerprint')
 record=storage.get_export_request(ws,key);j=storage.get_job(ws,record['job_id']);assert j['state']=='failed' and j['error_code']=='WORKER_UNAVAILABLE'
 assert record['job_id'] not in app.ACTIVE
