"""Publication metadata tests. These fixtures are NOT claims of rendered video.
The browser integration suite separately exports and inspects a genuine MP4.
"""
from pathlib import Path
import sys,json,uuid,hashlib
import pytest
from fastapi.testclient import TestClient
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app,storage,quran
from models import ProjectConfig

@pytest.fixture
def metadata_job(tmp_path,monkeypatch):
 monkeypatch.setattr(storage,'DB',tmp_path/'metadata.sqlite3');storage.init_db()
 ws=str(uuid.uuid4());config=ProjectConfig(reciter='mossad').model_dump();p=storage.save_project(ws,config);j=storage.create_job(ws,p['id'],config)
 storage.update_job(j['id'],state='completed',result={'duration':8,'source_sha256':quran.QURAN['sha256'],'timeline':{'cues':[{'key':'112:2','number':2,'start':0,'end':8}],'clips':[]}})
 return ws,j['id'],config

def payload(**changes):
 return {'title':'وقفة مع سورة الإخلاص 🤍','description':'تلاوة للتدبّر.\n\nبصوت عبدالرحمن مسعد.','hashtags':'#القرآن_الكريم #سورة_الاخلاص','platform':'all','suggestion':0,'edited':False,'revision':0,**changes}

def endpoint(jid):return '/api/jobs/'+jid+'/publication'
def headers(ws):return {'X-Workspace-Id':ws}


def test_publication_migration_is_idempotent_and_keeps_project_and_job(metadata_job):
 ws,jid,cfg=metadata_job;storage.init_db();storage.init_db()
 assert storage.get_job(ws,jid)['config']==cfg and len(storage.projects(ws))==1
 with storage.connect() as db:assert db.execute("select name from sqlite_master where name='publications'").fetchone()


def test_completed_job_can_start_without_a_post_then_save_exact_arabic(metadata_job):
 ws,jid,_=metadata_job;c=TestClient(app.app)
 response=c.get(endpoint(jid),headers=headers(ws));assert response.status_code==200 and response.json()['publication'] is None
 result=c.put(endpoint(jid),headers=headers(ws),json=payload()).json();p=result['publication']
 assert p['title']==payload()['title'] and p['description']==payload()['description'] and p['hashtags']==payload()['hashtags']
 assert p['revision']==1 and p['job_id']==jid and len(result['context_sha256'])==64
 assert c.get(endpoint(jid),headers=headers(ws)).json()['publication']==p


@pytest.mark.parametrize('state',['queued','preparing','rendering','validating','failed','canceled','interrupted'])
def test_post_is_not_presented_as_ready_before_successful_export(metadata_job,state):
 ws,jid,_=metadata_job;storage.update_job(jid,state=state);c=TestClient(app.app)
 assert c.get(endpoint(jid),headers=headers(ws)).status_code==409
 assert c.put(endpoint(jid),headers=headers(ws),json=payload()).status_code==409
 assert storage.get_publication(ws,jid) is None


def test_workspace_isolation_does_not_expose_another_clips_post(metadata_job):
 ws,jid,_=metadata_job;c=TestClient(app.app);c.put(endpoint(jid),headers=headers(ws),json=payload())
 other=str(uuid.uuid4());assert c.get(endpoint(jid),headers=headers(other)).status_code==404
 assert c.put(endpoint(jid),headers=headers(other),json=payload(title='لا يستبدل النص')).status_code==404
 assert c.get(endpoint(jid)).status_code==400


def test_idempotent_retry_does_not_increment_revision_or_lose_manual_edits(metadata_job):
 ws,jid,_=metadata_job;c=TestClient(app.app);body=payload(edited=True)
 a=c.put(endpoint(jid),headers=headers(ws),json=body).json()['publication'];b=c.put(endpoint(jid),headers=headers(ws),json=body).json()['publication']
 assert a==b and a['revision']==1


def test_optimistic_revision_conflict_preserves_saved_version(metadata_job):
 ws,jid,_=metadata_job;c=TestClient(app.app)
 c.put(endpoint(jid),headers=headers(ws),json=payload())
 newest=c.put(endpoint(jid),headers=headers(ws),json=payload(title='عنوان يدوي جديد',revision=1,edited=True)).json()['publication']
 conflict=c.put(endpoint(jid),headers=headers(ws),json=payload(title='نسخة قديمة',revision=1))
 assert conflict.status_code==409 and conflict.json()['code']=='PUBLICATION_CONFLICT'
 assert conflict.json()['publication']['title']==newest['title'] and storage.get_publication(ws,jid)['title']==newest['title']
 chosen=c.put(endpoint(jid),headers=headers(ws),json=payload(title='اختيار صريح بعد التعارض',revision=2,edited=True)).json()['publication']
 assert chosen['revision']==3 and chosen['title']=='اختيار صريح بعد التعارض'


@pytest.mark.parametrize('change',[{'title':'س'*141},{'description':'س'*4001},{'hashtags':'س'*1501},{'platform':'unknown'},{'suggestion':-1},{'revision':-1},{'audio_url':'not-allowed'}])
def test_publication_limits_and_schema_are_enforced(metadata_job,change):
 ws,jid,_=metadata_job;r=TestClient(app.app).put(endpoint(jid),headers=headers(ws),json=payload(**change));assert r.status_code==422


def test_editable_caption_never_modifies_the_rendered_quran_or_project(metadata_job):
 ws,jid,cfg=metadata_job;before=storage.get_job(ws,jid);xml=quran.ROOT/'data/quran-uthmani.xml';digest=hashlib.sha256(xml.read_bytes()).hexdigest()
 p=payload(title='<script>هذا نص يدوي لا ينفذ</script>',description='وصف يكتبه المستخدم بحرية.',hashtags='#وسم_يدوي',edited=True)
 c=TestClient(app.app);assert c.put(endpoint(jid),headers=headers(ws),json=p).status_code==200
 after=storage.get_job(ws,jid);assert before==after and after['config']==cfg
 assert hashlib.sha256(xml.read_bytes()).hexdigest()==digest
 assert c.get(endpoint(jid),headers=headers(ws)).json()['publication']['title']==p['title']


def test_separate_clips_keep_separate_publications(metadata_job):
 ws,jid,cfg=metadata_job;p=storage.save_project(ws,cfg);other=storage.create_job(ws,p['id'],cfg);storage.update_job(other['id'],state='completed',result={'duration':3})
 c=TestClient(app.app);c.put(endpoint(jid),headers=headers(ws),json=payload(title='المنشور الأول'))
 c.put(endpoint(other['id']),headers=headers(ws),json=payload(title='المنشور الثاني'))
 assert storage.get_publication(ws,jid)['title']=='المنشور الأول' and storage.get_publication(ws,other['id'])['title']=='المنشور الثاني'


def test_empty_fields_are_allowed_during_manual_editing(metadata_job):
 ws,jid,_=metadata_job;r=TestClient(app.app).put(endpoint(jid),headers=headers(ws),json=payload(title='',description='',hashtags='',edited=True));assert r.status_code==200 and r.json()['publication']['title']==''
