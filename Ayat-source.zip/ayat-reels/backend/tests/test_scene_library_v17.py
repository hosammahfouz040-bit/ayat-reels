"""Metadata/DB/algorithm safeguards; synthetic DB jobs here are NOT video-render proof.
Actual on-demand footage and genuine MP4 exports are exercised separately.
"""
from pathlib import Path
import sys,json,uuid,random,hashlib
from concurrent.futures import ThreadPoolExecutor
import pytest
from fastapi.testclient import TestClient
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import storage,catalog,scene_selection,scene_assets,app
from models import ProjectConfig,SceneClip
ROOT=Path(__file__).resolve().parents[2]

@pytest.fixture
def database(tmp_path,monkeypatch):
 monkeypatch.setattr(storage,'DB',tmp_path/'history.sqlite3');storage.init_db();return str(uuid.uuid4())

def job(ws,ids=('mihrab','orbit'),result=None):
 config=ProjectConfig(clips=[SceneClip(scene_id=ident) for ident in ids]).model_dump();p=storage.save_project(ws,config);j=storage.create_job(ws,p['id'],config)
 if result is not None:storage.complete_job_with_scene_usage(j['id'],result)
 return p,j

def result(ids=('mihrab','orbit')):return {'duration':8,'timeline':{'clips':[{'scene_id':ident,'start':i*3,'end':i*3+5} for i,ident in enumerate(ids)]}}

def test_original_48_scenes_42_readers_and_templates_are_byte_field_compatible():
 before=json.loads((ROOT/'tests/library-before-v17.json').read_text())
 assert json.loads((ROOT/'backend/media/catalog.json').read_text())==before['scene_records']
 assert json.loads((ROOT/'backend/data/reciters.json').read_text())[:42]==before['reader_records']
 assert json.loads((ROOT/'backend/data/templates-extra.json').read_text())==before['template_extra_records']
 assert len(catalog.SCENE_MAP)==len(catalog.SCENES) and len(catalog.RECITER_MAP)==54
 assert [s['id'] for s in catalog.SCENES[:48]]==[s['id'] for s in before['scene_records']]


def test_history_migration_is_additive_idempotent_and_imports_legacy_success_once(database):
 ws=database;p,j=job(ws);storage.update_job(j['id'],state='completed',result=result())
 project_before=storage.get_project(ws,p['id']);job_before=storage.get_job(ws,j['id'])
 storage.init_db();storage.backfill_scene_usage();storage.init_db();storage.backfill_scene_usage()
 usage=storage.scene_usage(ws);assert usage['completed_clips']==1 and usage['unique_scenes']==2
 assert {s:v['uses'] for s,v in usage['scenes'].items()}=={'mihrab':1,'orbit':1}
 assert project_before==storage.get_project(ws,p['id']) and job_before==storage.get_job(ws,j['id'])


def test_only_successful_visible_scenes_are_consumed_and_completion_is_idempotent(database):
 ws=database;_,j=job(ws,('mihrab','orbit','garden'))
 output={'duration':8,'timeline':{'clips':[{'scene_id':'mihrab','start':0,'end':5},{'scene_id':'mihrab','start':3,'end':7},{'scene_id':'orbit','start':4,'end':9},{'scene_id':'garden','start':9,'end':15}]}}
 assert storage.scene_usage(ws)['unique_scenes']==0
 storage.complete_job_with_scene_usage(j['id'],output);storage.complete_job_with_scene_usage(j['id'],output);storage.backfill_scene_usage()
 assert set(storage.scene_usage(ws)['scenes'])=={'mihrab','orbit'}
 assert all(v['uses']==1 for v in storage.scene_usage(ws)['scenes'].values())


@pytest.mark.parametrize('state',['queued','preparing','rendering','validating','failed','canceled','interrupted'])
def test_previews_and_unsuccessful_jobs_do_not_consume_history(database,state):
 ws=database;_,j=job(ws);storage.update_job(j['id'],state=state);storage.backfill_scene_usage()
 scene_selection.select_scenes(ws,3,mood='سكينة');assert storage.scene_usage(ws)['unique_scenes']==0


def test_missing_authoritative_visible_timeline_is_not_guessed_from_selected_config(database):
 ws=database;_,j=job(ws);storage.complete_job_with_scene_usage(j['id'],{'duration':8})
 assert storage.scene_usage(ws)['unique_scenes']==0


def test_reset_preserves_projects_jobs_publications_and_does_not_reimport_old_success(database,tmp_path):
 ws=database;p,j=job(ws,result=result());values={'title':'بيانات منشور اختبار','description':'Metadata fixture, not Quran or a rendered video.','hashtags':'#test','platform':'all','suggestion':0,'edited':True,'revision':0};storage.save_publication(ws,j['id'],values)
 project_before=storage.get_project(ws,p['id']);job_before=storage.get_job(ws,j['id']);pub_before=storage.get_publication(ws,j['id']);file=tmp_path/'protected.mp4';file.write_bytes((ROOT/'backend/media/orbit.mp4').read_bytes());digest=hashlib.sha256(file.read_bytes()).hexdigest()
 assert storage.reset_scene_usage(ws)['unique_scenes']==0
 storage.backfill_scene_usage();storage.init_db();storage.backfill_scene_usage();assert storage.scene_usage(ws)['unique_scenes']==0
 assert project_before==storage.get_project(ws,p['id']) and job_before==storage.get_job(ws,j['id']) and pub_before==storage.get_publication(ws,j['id'])
 assert file.exists() and hashlib.sha256(file.read_bytes()).hexdigest()==digest


def test_completion_after_reset_counts_in_the_new_round(database):
 ws=database;_,j=job(ws);storage.reset_scene_usage(ws);storage.complete_job_with_scene_usage(j['id'],result())
 assert storage.scene_usage(ws)['epoch']==1 and storage.scene_usage(ws)['unique_scenes']==2


def test_history_and_resets_are_workspace_isolated(database):
 ws=database;other=str(uuid.uuid4());job(ws,result=result());job(other,result=result(('garden',)))
 storage.reset_scene_usage(ws);assert storage.scene_usage(ws)['unique_scenes']==0 and set(storage.scene_usage(other)['scenes'])=={'garden'}

@pytest.fixture
def pool(monkeypatch):
 ids=['mihrab','orbit','garden','dunes','ocean','stars'];scenes=[{**catalog.SCENE_MAP[ident],'moods':['سكينة'],'category':'test-category','subject':'nature'} for ident in ids]
 monkeypatch.setattr(scene_selection,'SCENES',scenes);return ids


def test_selector_exhausts_suitable_unused_scenes_before_any_reuse(database,pool):
 ws=database;a=scene_selection.select_scenes(ws,3,mood='سكينة',rng=random.Random(1));job(ws,a['scene_ids'],result(a['scene_ids']))
 b=scene_selection.select_scenes(ws,3,mood='سكينة',rng=random.Random(2));assert not set(a['scene_ids'])&set(b['scene_ids'])
 job(ws,b['scene_ids'],result(b['scene_ids']));c=scene_selection.select_scenes(ws,3,mood='سكينة',rng=random.Random(3));assert set(c['rounds'])=={1}
 assert len(set(c['scene_ids']))==3 and c['candidate_count']==6


def test_template_preference_never_overrides_unused_alternatives(database,pool):
 ws=database;job(ws,('mihrab','orbit','garden'),result(('mihrab','orbit','garden')))
 choice=scene_selection.select_scenes(ws,3,mood='سكينة',preferred=['mihrab','orbit','garden']);assert not set(choice['scene_ids'])&{'mihrab','orbit','garden'}


def test_pending_reservations_avoid_duplicate_queued_picks_but_cancel_releases_them(database,pool):
 ws=database;a=scene_selection.select_scenes(ws,3,mood='سكينة');_,j=job(ws,a['scene_ids']);b=scene_selection.select_scenes(ws,3,mood='سكينة');assert not set(a['scene_ids'])&set(b['scene_ids'])
 assert b['pending_reservations_considered'] and storage.scene_usage(ws)['unique_scenes']==0
 storage.update_job(j['id'],state='canceled');assert not storage.pending_scene_reservations(ws)


def test_empty_filter_is_not_silently_replaced_with_irrelevant_scenes(database,pool):
 with pytest.raises(scene_selection.SceneSelectionError):scene_selection.select_scenes(database,3,mood='ليل')
 one=scene_selection.select_scenes(database,12,mood='سكينة',exclude=pool[:-1]);assert one['scene_ids']==[pool[-1]] and one['selected_count']==1


def test_two_simultaneous_one_click_requests_reserve_disjoint_scenes(database,pool,monkeypatch):
 def metadata_enqueue(ws,pid,config):return storage.create_job(ws,pid,config)
 monkeypatch.setattr(app,'enqueue',metadata_enqueue);config=ProjectConfig().model_dump();headers={'X-Workspace-Id':database,'X-Ayat-Capabilities':'warsh,scene-library-v17,publisher-timing-v1'}
 def request(_):
  with TestClient(app.app) as client: # no active exports, mocked metadata queue only
   return client.post('/api/jobs',headers=headers,json={'config':config,'one_click':True})
 # Do not run lifespan recovery for overlapping clients in this test; one shared client
 # mirrors one running ASGI app instead of starting two independent servers.
 client=TestClient(app.app)
 with ThreadPoolExecutor(max_workers=2) as executor:responses=list(executor.map(lambda _:client.post('/api/jobs',headers=headers,json={'config':config,'one_click':True}),range(2)))
 assert all(r.status_code==200 for r in responses)
 sets=[{c['scene_id'] for c in r.json()['config']['clips']} for r in responses];assert not sets[0]&sets[1]


def test_history_api_requires_valid_workspace_and_reset_is_scoped(database):
 client=TestClient(app.app);headers={'X-Workspace-Id':database};job(database,result=result())
 assert client.get('/api/scenes/history',headers=headers).json()['unique_scenes']==2
 assert client.post('/api/scenes/history/reset',headers=headers).json()['unique_scenes']==0
 assert client.get('/api/scenes/history',headers={'X-Workspace-Id':'not-a-uuid'}).status_code==400
 assert client.post('/api/scenes/suggest',headers=headers,json={'count':13}).status_code==422
 assert client.post('/api/scenes/unknown/prepare').status_code==404


def test_bundled_assets_remain_immediately_ready_without_network():
 state=scene_assets.asset_status('orbit');assert state['state']=='ready' and state['bundled']
 assert scene_assets.ensure_scene_asset('orbit').read_bytes()[4:8]==b'ftyp'


def test_cancellation_before_remote_asset_work_does_not_start_network_or_encoding(tmp_path,monkeypatch):
 ident='test_remote_metadata_only';monkeypatch.setattr(scene_assets,'SCENE_MAP',{ident:{'id':ident,'name':'Test fixture','availability':'on-demand'}});monkeypatch.setattr(scene_assets,'CACHE',tmp_path)
 with pytest.raises(scene_assets.SceneAssetError):scene_assets.ensure_scene_asset(ident,canceled=lambda:True)
 assert not list(tmp_path.glob('*.mp4'))
