"""Download-route regression tests, isolated DB/outputs. Uses an actual previously decoded MP4."""
from pathlib import Path
import sys,uuid,shutil,hashlib
import pytest
from fastapi.testclient import TestClient
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app,storage
from models import ProjectConfig

@pytest.fixture
def completed_video(tmp_path,monkeypatch):
 monkeypatch.setattr(storage,'DB',tmp_path/'routes.sqlite3');storage.init_db()
 outputs=tmp_path/'exports';outputs.mkdir();monkeypatch.setattr(app,'EXPORTS',outputs)
 ws=str(uuid.uuid4());cfg=ProjectConfig().model_dump();cfg['title']='<script>not executable</script>'
 project=storage.save_project(ws,cfg);job=storage.create_job(ws,project['id'],cfg)
 storage.update_job(job['id'],state='completed',progress=100)
 folder=outputs/job['id'];folder.mkdir();original=Path(__file__).resolve().parents[2]/'backend/media/orbit.mp4'
 # A real bundled MP4, not an invented successful Quran export. This fixture isolates HTTP streaming/header behavior; exported Quran clips are tested separately.
 shutil.copyfile(original,folder/'result.mp4')
 return TestClient(app.app),ws,job['id'],folder,cfg

def test_direct_attachment_inline_range_and_independent_html(completed_video):
 client,ws,jid,folder,cfg=completed_video;stem='/api/jobs/'+jid;query='?workspace='+ws
 original=(folder/'result.mp4').read_bytes();response=client.get(stem+'/file'+query)
 assert response.status_code==200 and response.headers['content-type']=='video/mp4'
 assert 'attachment' in response.headers['content-disposition']
 assert 'Ayat_112_' in response.headers['content-disposition']
 assert int(response.headers['content-length'])==len(original)
 assert hashlib.sha256(response.content).digest()==hashlib.sha256(original).digest()
 assert response.headers['x-content-type-options']=='nosniff'
 assert response.headers['cache-control']=='private, no-store'
 stream=client.get(stem+'/stream'+query,headers={'Range':'bytes=0-31'})
 assert stream.status_code==206 and stream.content==original[:32]
 assert 'inline' in stream.headers['content-disposition']
 assert stream.headers['content-range']==f'bytes 0-31/{len(original)}'
 page=client.get(stem+'/open'+query)
 assert page.status_code==200 and 'text/html' in page.headers['content-type']
 assert 'direct-mp4-download' in page.text and '/stream?workspace=' in page.text
 assert '<script>' not in page.text and '&lt;script&gt;' in page.text
 assert 'blob:' not in page.text and page.headers['referrer-policy']=='no-referrer'

def test_download_never_claims_partial_missing_or_another_workspaces_file(completed_video):
 client,ws,jid,folder,_=completed_video;stem='/api/jobs/'+jid;query='?workspace='+ws
 other='?workspace='+str(uuid.uuid4())
 for route in ['file','stream','open']:
  assert client.get(stem+'/'+route+other).status_code==404
 storage.update_job(jid,state='rendering')
 for route in ['file','stream','open']:assert client.get(stem+'/'+route+query).status_code==409
 storage.update_job(jid,state='completed');(folder/'result.mp4').unlink()
 for route in ['file','stream','open']:assert client.get(stem+'/'+route+query).status_code==410

def test_auto_download_handoff_is_explicit_top_level_only_and_escapes_title(completed_video):
 client,ws,jid,folder,_=completed_video;url='/api/jobs/'+jid+'/open?workspace='+ws
 manual=client.get(url)
 assert 'ayat-standalone-download' not in manual.text
 page=client.get(url+'&start=1')
 assert page.status_code==200 and page.headers['cache-control']=='private, no-store'
 assert 'id="ayat-standalone-download"' in page.text
 assert 'if(window.self!==window.top)return;' in page.text
 assert 'window.location.assign(link.href)' in page.text
 assert 'preload="none"' in page.text
 assert '<script>not executable</script>' not in page.text
 assert '&lt;script&gt;not executable&lt;/script&gt;' in page.text
 # The one fixed script reads the already-escaped link, never injects a user string into JS.
 assert page.text.count('<script')==1 and page.text.count('</script>')==1
 assert 'ayat-standalone-download' not in client.get(url+'&start=0').text
 assert len(storage.jobs(ws))==1 # Opening a download page never starts a new export.
 assert client.get('/api/jobs/'+jid+'/open?workspace='+str(uuid.uuid4())+'&start=1').status_code==404
