"""Bounded scene scheduling + real genuine-audio MP4 transition regression tests."""
from pathlib import Path
import sys,json,math,subprocess
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import media_engine as e
from bounded_video import plan_parts,POLICY
from models import ProjectConfig,SceneClip


def plan(config,seconds=13.124333333):
 verse=e.get_verses(112,2,2)[0];return e.timing_and_clips(config,{'duration':seconds,'verses':[{**verse,'start':0,'end':seconds}]})


@pytest.mark.parametrize('kind',['cut','fade','wipeleft','slideup','light','mist'])
@pytest.mark.parametrize('count',[1,2,6,12])
def test_frame_plan_preserves_duration_order_and_every_transition_with_at_most_two_inputs(kind,count):
 c=ProjectConfig(from_ayah=2,to_ayah=2,clips=[SceneClip(scene_id='orbit',transition=kind) for _ in range(count)]);tl=plan(c);result=plan_parts(tl,30)
 assert result['frames']==math.ceil(tl['duration']*30) and sum(p['frames'] for p in result['parts'])==result['frames']
 assert [s['index'] for s in result['scenes']]==list(range(count))
 assert all(p['frames']>0 for p in result['parts'])
 if kind=='cut':assert all(p['kind']=='body' for p in result['parts'])
 else:assert len([p for p in result['parts'] if p['kind']=='transition'])==count-1
 assert POLICY['resolution_downgrade'] is False and POLICY['max_parallel_scene_decoders']==2


def test_scenes_outside_audio_are_not_decoded_but_are_not_removed_from_saved_config():
 c=ProjectConfig(from_ayah=2,to_ayah=2,auto_fit=False,clips=[SceneClip(scene_id='orbit',transition='cut') for _ in range(12)]);before=c.model_dump();result=plan_parts(plan(c,2.3),24)
 assert len(result['scenes'])==1 and c.model_dump()==before and result['frames']==math.ceil(2.3*24)


def test_unequal_scene_weights_get_valid_nonoverlapping_transition_windows():
 c=ProjectConfig(from_ayah=2,to_ayah=2,clips=[SceneClip(scene_id='orbit',duration=.5,transition_duration=2),SceneClip(scene_id='garden',duration=20,transition_duration=2),SceneClip(scene_id='mihrab',duration=.5)])
 tl=plan(c,12);p=plan_parts(tl,24);assert sum(v['frames'] for v in p['parts'])==p['frames']
 for scene in p['scenes']:assert scene['incoming_frames']+scene['outgoing_frames']<=scene['frames']


@pytest.mark.parametrize('kind',['cut','fade','wipeleft','slideup','light','mist'])
def test_actual_mp4_keeps_quran_audio_rights_and_transition_without_multi_scene_graph(kind,tmp_path,monkeypatch):
 monkeypatch.setattr(e,'EXPORTS',tmp_path);p=e.prepare_audio(112,2,2,'mossad');c=ProjectConfig(surah=112,from_ayah=2,to_ayah=2,reciter='mossad',quality='draft',clips=[SceneClip(scene_id='haram_night',transition=kind),SceneClip(scene_id='garden')])
 result=e.render(c,p,'real-bounded-'+kind,lambda *a:None,lambda:False,lambda proc:None);folder=tmp_path/('real-bounded-'+kind);audit=json.loads((folder/'audit.json').read_text());background=json.loads((folder/'background-plan.json').read_text());command=json.loads((folder/'command.json').read_text())
 assert result['width']==540 and result['height']==960 and result['text_visible_ratio']>.52
 assert audit['all_cues_match_source'] and audit['result']['visual_attribution_burned'] and audit['render_backend']=='bounded-background-v1'
 assert audit['result']['timeline']['clips'][0]['transition']==kind
 assert command.count('-i')==3 and 'xfade=' not in command[command.index('-filter_complex')+1]
 assert background['frame_plan']['frames']==math.ceil(p['duration']*24)
 assert not (folder/'.cache/video-stages').exists() and not (folder/'result.partial.mp4').exists()
 output=subprocess.run([e.FFMPEG,'-v','error','-i',str(folder/'result.mp4'),'-map','0:v:0','-f','null','-','-progress','pipe:1','-nostats'],capture_output=True,text=True);assert output.returncode==0
 frames=[int(line.split('=')[1]) for line in output.stdout.splitlines() if line.startswith('frame=')];assert frames and frames[-1]==math.ceil(p['duration']*24)


def test_static_quran_pages_survive_switching_background_color_metadata(tmp_path,monkeypatch):
 from PIL import Image
 from io import BytesIO
 import numpy as np
 monkeypatch.setattr(e,'EXPORTS',tmp_path)
 p=e.prepare_audio(112,1,4,'alafasy');c=ProjectConfig(surah=112,from_ayah=1,to_ayah=4,reciter='alafasy',quality='draft',clips=[SceneClip(scene_id='haram_night'),SceneClip(scene_id='waterfall')])
 result=e.render(c,p,'all-pages-retained',lambda*a:None,lambda:False,lambda proc:None);folder=tmp_path/'all-pages-retained';audit=json.loads((folder/'audit.json').read_text());assert len(audit['text_composition']['pages'])==4
 for page in audit['text_composition']['pages']:
  lay=page['layout'];v={'text':' '.join(run['text'] for run in lay['verse']['lines']),'number':int(page['key'].split(':')[1]),'layout':lay};mask=e.text_graphics(c,v,[run['text'] for run in lay['verse']['lines']],result['width'],result['height'],lay)[2];selected=np.asarray(mask)>245;timepoint=page['start']+(page['end']-page['start'])*.65
  png=e.run_checked(['-ss',str(timepoint),'-i',str(folder/'result.mp4'),'-frames:v','1','-f','image2pipe','-vcodec','png','pipe:1']);rgb=np.asarray(Image.open(BytesIO(png)).convert('RGB'),dtype=float);score=float(np.mean(np.linalg.norm(rgb[selected]-np.array(e.rgb(c.text_style.color)),axis=1)<65));assert score>.8,(page['key'],score)
