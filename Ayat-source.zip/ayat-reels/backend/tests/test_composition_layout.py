"""Real Arabic font measurements test exported text flow, not CSS-only coordinates."""
from pathlib import Path
import sys,copy
import numpy as np,pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import media_engine as e
import composition_layout as layout
from catalog import TEMPLATES,RECITERS
from models import ProjectConfig,SceneClip
from visual_effects import OverlayPainter


def page_for(config,text=None,width=720,height=1280):
 verse=e.get_verses(config.surah,config.from_ayah,config.from_ayah,config.narration)[0]
 assert text is None # No supplied/generated replacement for Quran in these tests.
 face=layout.fit_verse_font(config.text_style,e.quran_font(config),verse['text'],width)
 _,cw=layout.column(config.text_style,width);lines=layout.wrap_exact(verse['text'],face,cw)
 chunks=layout.paginate_lines(lines,face,config.text_style.line_height,height*layout.SPEC['verse_page_max_height'],layout.SPEC['verse_min_line_gap']*width/1080)
 pages=[]
 for i,chunk in enumerate(chunks):
  page={**verse,'start':float(i),'end':float(i+1),'page':i+1,'pages':len(chunks),'lines':chunk,'render_font_size':face.size};page['layout']=e.layout_for_page(config,page,chunk,width,height);pages.append(page)
 assert ' '.join(line for page in pages for line in page['lines'])==verse['text']
 return pages


def check_geometry(data):
 safe=data['safe_region'];group=data['group_bbox'];w=data['width'];h=data['height']
 assert safe[0]-.01<=group[0]<group[2]<=safe[2]+.01
 assert safe[1]-.01<=group[1]<group[3]<=safe[3]+.01
 assert data['surah']['ink_bbox'][3]<data['verse_box'][1]
 assert data['verse_box'][3]<data['reader']['ink_bbox'][1]
 assert data['reader']['ink_bbox'][3]<data['source']['ink_bbox'][1]
 # Gaps are local font-sized spaces, not the old ~70% screen spread.
 assert data['verse_box'][1]-data['surah']['ink_bbox'][3]<h*.07
 assert data['reader']['ink_bbox'][1]-data['verse_box'][3]<h*.07
 assert data['source']['ink_bbox'][1]-data['reader']['ink_bbox'][3]<h*.03
 for key in ['surah','reader','source']:
  assert data[key]['font_size']<=data['verse']['font_size']*.45+1
  assert ' '.join(r['text'] for r in data[key]['lines'])==data[key]['text']
  for r in data[key]['lines']:
   x1,y1,x2,y2=r['ink'];assert 0<=x1<x2<=w and 0<=y1<y2<=h
   if data['alignment']=='center':assert abs((x1+x2)/2-data['column_center_x'])<.01
   else:assert abs(x2-(data['column_center_x']+data['column_width']/2))<.01
 for r in data['verse']['lines']:
  x1,y1,x2,y2=r['ink'];assert 0<=x1<x2<=w and 0<=y1<y2<=h
  if data['alignment']=='center':assert abs((x1+x2)/2-data['column_center_x'])<.01
  else:assert abs(x2-(data['column_center_x']+data['column_width']/2))<.01


def test_default_short_ayah_is_a_compact_measured_block_not_separate_fixed_hud():
 c=ProjectConfig(from_ayah=2,to_ayah=2);page=page_for(c)[0];data=page['layout'];check_geometry(data)
 assert data['version']=='compact-ink-v1' and data['group_bbox'][3]-data['group_bbox'][1]<1280*.25
 assert abs(data['verse_center_y']-1280*c.text_style.y)<.1 and not data['position_safety_clamped']
 assert data['surah']['ink_bbox'][1]>1280*.3 and data['reader']['ink_bbox'][3]<1280*.7
 assert data['verse']['font_size']>2*data['surah']['font_size']


@pytest.mark.parametrize('index',range(80),ids=[t['id'] for t in TEMPLATES])
def test_every_existing_template_flows_around_real_text_without_losing_names_or_glyphs(index):
 t=TEMPLATES[index];r=RECITERS[(index*7)%len(RECITERS)];style={k:t[k] for k in ['font','size','color','box_color','box_opacity','y','x','max_width','alignment'] if k in t}
 c=ProjectConfig(surah=2,from_ayah=255,to_ayah=255,reciter=r['id'],template_id=t['id'],text_style=style)
 before=c.model_dump()
 for page in page_for(c):
  check_geometry(page['layout']);assert page['layout']['reader']['text']==r['name']
 assert c.model_dump()==before # Never rewrite saved positions, styles, project IDs or Quran.


@pytest.mark.parametrize('name',[r['id'] for r in RECITERS])
def test_every_genuine_reader_name_fits_in_full_without_ellipsis(name):
 c=ProjectConfig(from_ayah=2,to_ayah=2,reciter=name,text_style={'max_width':.45,'alignment':'right','x':.3})
 for page in page_for(c):check_geometry(page['layout'])


@pytest.mark.parametrize('size',[28,80,130])
@pytest.mark.parametrize('y',[.15,.49,.82])
@pytest.mark.parametrize('align',['center','right'])
def test_extreme_user_font_positions_and_alignment_remain_inside_safe_portrait_area(size,y,align):
 c=ProjectConfig(surah=2,from_ayah=282,to_ayah=282,text_style={'size':size,'y':y,'alignment':align,'x':.12 if align=='right' else .88,'max_width':.9,'line_height':1.45})
 for page in page_for(c):check_geometry(page['layout'])


@pytest.mark.parametrize('reciter',['alafasy','suhaim'])
def test_hafs_and_warsh_keep_exact_source_with_correct_verse_marker_behavior(reciter):
 c=ProjectConfig(from_ayah=2,to_ayah=2,reciter=reciter);page=page_for(c)[0];before=e.quran_source(c.narration)['sha256'];data=page['layout'];check_geometry(data)
 assert bool(data['number'])==(c.narration=='hafs')
 assert data['verse']['font']==('KFGQPCWarsh.ttf' if reciter=='suhaim' else 'AmiriQuran-Regular.ttf')
 assert e.quran_source(c.narration)['sha256']==before
 _,glyph,mask,_=e.text_graphics(c,page,page['lines'],720,1280)
 assert glyph.getbbox() and mask.getbbox()
 assert abs((mask.getbbox()[1]+mask.getbbox()[3])/2-data['verse_center_y'])<2


def test_static_and_rgba_effect_pipeline_use_the_exact_same_geometry_and_pixels():
 c=ProjectConfig(from_ayah=2,to_ayah=2,clips=[SceneClip(scene_id='haram_night')]);page=page_for(c)[0]
 timeline={'duration':1,'cues':[page],'clips':[{'scene_id':'haram_night','start':0,'end':1,'duration':1,'transition':'cut','transition_seconds':0}]}
 still,_=e.make_overlay(c,page,page['lines'],720,1280);e.draw_visual_credits(still,e.required_visual_sources(timeline,.5),720,1280)
 painter=OverlayPainter(e,c,timeline,[page],720,1280,24);moving=painter.frame(.5)
 assert np.array_equal(np.asarray(still),np.asarray(moving))


def test_animated_labels_reflow_for_each_page_instead_of_caching_an_empty_verse_base():
 c=ProjectConfig(surah=2,from_ayah=255,to_ayah=255,text_style={'max_width':.45,'size':130});pages=page_for(c)
 assert len(pages)>1
 tl={'duration':float(len(pages)),'clips':[]};painter=OverlayPainter(e,c,tl,pages,720,1280,24)
 for p in pages:
  data=p['layout'];im=painter.frame(p['start']+.5);assert im.getbbox()
  title=painter.graphics(p)[0];assert title.getbbox()[1]>=data['group_bbox'][1]-8
  assert abs(data['reader']['ink_bbox'][1]-data['verse_box'][3]-data['effect_bleed']-layout.SPEC['verse_reader_gap']*720/1080)<.01


def test_verse_switch_motion_and_glow_reserve_space_without_overlapping_metadata():
 for kind in ['verse_switch','glow']:
  c=ProjectConfig(from_ayah=2,to_ayah=2,effects={'verse':{'enabled':True,'kind':kind,'intensity':1}});data=page_for(c)[0]['layout'];check_geometry(data)
  assert data['effect_bleed']>0
  assert data['reader']['ink_bbox'][1]-data['verse_box'][3]>=data['effect_bleed']


def test_source_footer_is_near_reader_but_footage_rights_bar_stays_separate():
 c=ProjectConfig(from_ayah=2,to_ayah=2);data=page_for(c)[0]['layout'];im=e.metadata_graphics(c,data,720,1280)
 assert im.getbbox()[3]<1280*.875
 assert np.asarray(im)[int(1280*.92):].max()==0 # The independent footage credit is not moved or dropped.


def test_small_legitimate_verse_uses_real_antialiased_strokes_while_empty_text_is_rejected():
 from PIL import Image
 assert e.glyph_mask_probe(Image.new('L',(540,960),0)) is None
 for surah,ayah in [(112,2),(20,1),(40,1)]:
  c=ProjectConfig(surah=surah,from_ayah=ayah,to_ayah=ayah,text_style={'size':28});p=page_for(c,width=540,height=960)[0]
  mask=e.text_graphics(c,p,p['lines'],540,960)[2];probe=e.glyph_mask_probe(mask)
  assert probe and probe['stroke_pixels']>=3 and probe['alpha_threshold']>=160


@pytest.mark.parametrize('size',[28,80])
def test_validation_still_refuses_an_mp4_without_the_expected_quran_pixels(tmp_path,monkeypatch,size):
 # Deliberately omit only the Quran layer in this negative test, while retaining its
 # true expected glyph mask. This must never produce a claimed successful export.
 original=e.make_overlay
 def omit_verse(config,cue,lines,width,height,layout=None):
  _,mask=original(config,cue,lines,width,height,layout)
  data=layout or (cue.get('layout') if cue else None) or e.layout_for_page(config,cue,lines,width,height)
  return e.metadata_graphics(config,data,width,height),mask
 monkeypatch.setattr(e,'EXPORTS',tmp_path);monkeypatch.setattr(e,'make_overlay',omit_verse)
 c=ProjectConfig(from_ayah=2,to_ayah=2,reciter='mossad',quality='draft',text_style={'size':size},clips=[SceneClip(scene_id='orbit')]);p=e.prepare_audio(112,2,2,'mossad')
 with pytest.raises(e.EngineError) as error:e.render(c,p,'must-refuse-missing-quran',lambda *a:None,lambda:False,lambda p:None)
 assert error.value.code=='TEXT_NOT_VISIBLE'
 assert not (tmp_path/'must-refuse-missing-quran/result.mp4').exists()
