"""Publisher timestamps are source-bound; no generated recitation or Quran text."""
from pathlib import Path
import sys,json,hashlib,uuid
import numpy as np,soundfile as sf,pytest,httpx
from fastapi.testclient import TestClient
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import catalog,media_engine,publisher_audio,quran,app
from models import AudioRequest
NEW=['idrees_abkar','khalid_jalil','abdulaziz_zahrani','bandar_baleela','wadee_yamani','raad_kurdi','abdulrahman_oosi','abdullah_mousa','mansour_salimi','ahmad_nufais','haitham_dukhain','hassan_saleh']

def rows():return [{'ayah':1,'start_time':0,'end_time':1000},{'ayah':2,'start_time':1000,'end_time':2000}]


def test_twelve_distinct_authoritative_read_ids_and_sources_not_bitrate_duplicates():
 added=[r for r in catalog.RECITERS if r.get('provider')=='publisher-timed'];assert [r['id'] for r in added]==NEW
 assert len({r['publisher_timing_read'] for r in added})==12 and len({r['name'] for r in added})==12
 for reader in added:
  assert reader['narration']=='hafs' and reader['publisher_available_surahs']==list(range(1,115))
  assert reader['publisher_audio_base'].startswith('https://cdn.mp3quran.net/audio/')
  assert {s['surah'] for s in reader['verification_samples']}=={1,112}
  assert all(s['full_decode_exit']==0 and s['peak']>.001 and len(s['publisher_timing_sha256'])==64 and s['publisher_timing_bound_to_reader']==reader['publisher_timing_read'] for s in reader['verification_samples'])


def test_final_endpoint_can_only_be_bounded_to_actual_eof_not_retimed_proportionally():
 data=rows();data[-1]['end_time']=2400;intervals,changes=publisher_audio.validate_intervals(data,2,2)
 assert intervals==[{'number':1,'start':0,'end':1},{'number':2,'start':1,'end':2}]
 assert changes==[{'ayah':2,'publisher_end':2.4,'decoded_end':2}]


@pytest.mark.parametrize('change',[
 lambda r:r.pop(),
 lambda r:r[0].update(start_time=-1),
 lambda r:r[0].update(end_time=0),
 lambda r:r[0].update(end_time=2100),
 lambda r:r[1].update(end_time=3100),
 lambda r:r[1].update(start_time=999),
 lambda r:r.append({'ayah':1,'start_time':20,'end_time':1000}),
 lambda r:r.append({'ayah':3,'start_time':2000,'end_time':2300}),
])
def test_invalid_missing_overlapping_or_mismatched_timing_is_rejected(change):
 data=rows();change(data)
 with pytest.raises((publisher_audio.PublisherAudioError,ValueError)):publisher_audio.validate_intervals(data,2,2)


def test_identical_publisher_polygon_duplicates_do_not_duplicate_verses():
 data=rows();data.append(dict(data[0]));intervals,_=publisher_audio.validate_intervals(data,2,2);assert len(intervals)==2


def test_changed_verified_sample_is_refused_instead_of_using_old_timing(tmp_path,monkeypatch):
 reader=catalog.RECITER_MAP['idrees_abkar'];sample=next(s for s in reader['verification_samples'] if s['surah']==112)
 def response(request):
  return httpx.Response(200,json=rows()) if 'ayat_timing?' in str(request.url) else httpx.Response(200,content=b'changed recording fixture '*100)
 real_client=httpx.Client;monkeypatch.setattr(publisher_audio.httpx,'Client',lambda **kwargs:real_client(transport=httpx.MockTransport(response)))
 with pytest.raises(publisher_audio.PublisherAudioError,match='تغيّر التسجيل'):publisher_audio.get_publisher_recording('idrees_abkar',112,tmp_path,lambda *args,**kwargs:None)
 assert not list(tmp_path.rglob('*.wav')) and not list(tmp_path.rglob('*.mp3'))


@pytest.mark.parametrize('reciter',NEW)
def test_real_new_reader_excerpt_uses_exact_canonical_text_and_original_recording_pcm(reciter):
 plan=media_engine.prepare_audio(112,2,2,reciter);verse=plan['verses'][0]
 assert verse['text']==quran.QURAN['verses']['112:2'] and plan['narration']=='hafs' and plan['reciter']==reciter
 assert verse['source_provider']=='MP3Quran' and verse['timing_validation']['publisher_timings'] is True
 source=media_engine.AUDIO/'recordings'/reciter/('112-'+verse['source_recording_sha256'][:16]+'.wav')
 original,sr=sf.read(source,start=round(verse['source_start']*48000),stop=round(verse['source_end']*48000),dtype='int16')
 excerpt,rate=sf.read(media_engine.AUDIO/'verses'/reciter/'112002.wav',dtype='int16')
 assert sr==rate==48000 and np.array_equal(original,excerpt) and np.max(np.abs(excerpt.astype(float)))>100
 assert plan['source_sha256']==quran.QURAN['sha256'] and 'publisher' in plan['timing_method'].lower()
 assert 'minimum_isolated_clip_similarity' not in verse['timing_validation'] # Never fabricate ASR metrics.


def test_old_ui_catalog_does_not_offer_remote_scene_urls_or_unsupported_readers():
 client=TestClient(app.app);ws=str(uuid.uuid4())
 old=client.get('/api/catalog',headers={'X-Workspace-Id':ws,'X-Ayat-Capabilities':'reciters-v13,warsh,publication-v1,visual-fx-v1'}).json()
 assert len(old['reciters'])==42 and len(old['scenes'])==48
 new=client.get('/api/catalog',headers={'X-Workspace-Id':ws,'X-Ayat-Capabilities':'reciters-v13,warsh,publication-v1,visual-fx-v1,publisher-timing-v1,scene-library-v17'}).json()
 assert len(new['reciters'])==54
 assert AudioRequest(surah=112,from_ayah=1,to_ayah=4,reciter='raad_kurdi').reciter=='raad_kurdi'
