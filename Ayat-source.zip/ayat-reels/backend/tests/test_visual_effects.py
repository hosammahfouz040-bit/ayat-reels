"""Effects schema/clock/immutability tests. Actual MP4 pixel/audio matrix is separate."""
from pathlib import Path
from io import BytesIO
import sys,json,hashlib
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import media_engine as e
from models import ProjectConfig,SceneClip,VisualEffects
from visual_effects import EFFECTS_CATALOG,camera_values,effect_envelope,transition_seconds,raw_overlay_required,scene_filter_graph,OverlayPainter
from quran import get_verses


def test_old_projects_default_to_no_effects_and_keep_all_existing_transition_ids():
 c=ProjectConfig();assert not c.effects.verse.enabled and not c.effects.scene.enabled and not c.effects.camera.enabled
 assert all(x.transition_enabled and x.transition_intensity==1 for x in c.clips)
 choices={x['id']:x for x in EFFECTS_CATALOG['transitions']}
 assert all(choices[k]['existing'] for k in ['cut','fade','wipeleft','slideup'])
 assert {k for k,v in choices.items() if not v['existing']}=={'light','mist'}


@pytest.mark.parametrize('group,key,value',[
 ('verse','kind','unknown'),('verse','intensity',1.01),('verse','intensity',-.1),('verse','duration',0),('verse','duration',9),
 ('scene','kind','unknown'),('scene','intensity',2),('scene','duration',-1),('scene','duration',121),
 ('camera','kind','unknown'),('camera','intensity',-.1),('camera','duration',-1),('camera','duration',121)])
def test_effects_reject_out_of_bounds_values(group,key,value):
 with pytest.raises(ValueError):VisualEffects.model_validate({group:{key:value}})


def test_one_effect_per_group_cannot_be_replaced_by_a_stack_of_extra_layers():
 with pytest.raises(ValueError):VisualEffects.model_validate({'scene':{'kind':'rain','fog':True,'dust':True}})
 with pytest.raises(ValueError):VisualEffects.model_validate({'scene':[{'kind':'rain'},{'kind':'stars'}]})
 for group in ['verse','scene','camera']:
  for item in EFFECTS_CATALOG[group]:assert VisualEffects.model_validate({group:{'kind':item['id']}})


def test_duration_and_camera_curves_are_bounded_and_move_then_hold():
 assert effect_envelope(0,2,5)==0 and effect_envelope(2.1,2,5)==0 and effect_envelope(1,2,5)==1
 for kind in ['zoom_in','zoom_out','pan','depth']:
  fx={'enabled':True,'kind':kind,'intensity':1,'duration':2}
  for t in [0,.5,1,2,8]:
   z,x,y=camera_values(fx,t,10);assert 1<=z<=1.081 and 0<=x<=1 and 0<=y<=1
  assert camera_values(fx,2,10)==camera_values(fx,8,10)
  assert camera_values({**fx,'enabled':False},1,10)==(1,.5,.5)


def test_transition_off_and_zero_strength_are_real_cuts():
 clip={'transition':'mist','transition_duration':1,'transition_enabled':True,'transition_intensity':.4}
 assert transition_seconds(clip,2)==.4
 assert transition_seconds({**clip,'transition_enabled':False},2)==0
 assert transition_seconds({**clip,'transition_intensity':0},2)==0
 assert transition_seconds({'transition':'fade','transition_duration':.5},2)==.5


def timeline(config):
 verses=get_verses(112,2,2,config.narration)
 return e.timing_and_clips(config,{'duration':3,'verses':[{**verses[0],'start':0,'end':3}]})


def test_turning_all_groups_off_uses_the_existing_static_overlay_path():
 c=ProjectConfig(surah=112,from_ayah=2,to_ayah=2,effects={'verse':{'enabled':False,'kind':'reveal'},'scene':{'enabled':False,'kind':'rain'},'camera':{'enabled':False,'kind':'depth'}})
 assert not raw_overlay_required(c,timeline(c))
 c.effects.scene.enabled=True;assert raw_overlay_required(c,timeline(c))
 c.effects.scene.kind='bloom';assert not raw_overlay_required(c,timeline(c)) # Native FFmpeg background treatment, still real.


@pytest.mark.parametrize('reciter,narration',[('mossad','hafs'),('suhaim','warsh')])
def test_text_graphics_and_word_boxes_never_rewrite_source(reciter,narration):
 c=ProjectConfig(surah=112,from_ayah=2,to_ayah=2,reciter=reciter);verse=get_verses(112,2,2,narration)[0];before=verse['text'];source=(e.ROOT/'data/quran-uthmani.xml').read_bytes()
 lines=e.wrap_text(before,e.load_font(e.quran_font(c),40),460);box,glyph,mask,words=e.text_graphics(c,verse,lines,540,960)
 assert verse['text']==before and ' '.join(lines)==before and words and mask.getbbox() and glyph.getbbox()
 assert (e.ROOT/'data/quran-uthmani.xml').read_bytes()==source


def test_background_blend_is_native_with_precomputed_masks_not_slow_per_pixel_formulas(tmp_path):
 c=ProjectConfig(effects={'camera':{'enabled':True,'kind':'depth'},'scene':{'enabled':True,'kind':'bloom'}});tl=timeline(c)
 graph=';'.join(scene_filter_graph(0,tl['clips'][0],tl,c,540,960,24,tmp_path))
 assert 'maskedmerge=planes=1' in graph and 'sendcmd=' in graph and 'all_mode=normal' in graph and 'all_expr=' not in graph
 assert list(tmp_path.glob('fx_depth_mask_*.png')) and list(tmp_path.glob('fx_blo_*.txt'))


def test_overlay_stream_stops_before_emitting_frames_when_canceled():
 c=ProjectConfig(surah=112,from_ayah=2,to_ayah=2,effects={'verse':{'enabled':True,'kind':'reveal'}});tl=timeline(c);page={**tl['cues'][0],'lines':[tl['cues'][0]['text']],'page':1,'pages':1}
 painter=OverlayPainter(e,c,tl,[page],270,480,24)
 import threading
 out=BytesIO();painter.stream(out,lambda:True,threading.Event());assert out.getvalue()==b''


def test_quran_and_source_credits_are_above_atmosphere_in_the_graphic_stream():
 c=ProjectConfig(surah=112,from_ayah=2,to_ayah=2,clips=[SceneClip(scene_id='haram_night')],effects={'scene':{'enabled':True,'kind':'rain','intensity':1}});tl=timeline(c);page={**tl['cues'][0],'lines':[tl['cues'][0]['text']],'page':1,'pages':1};painter=OverlayPainter(e,c,tl,[page],540,960,24)
 im=painter.frame(1);assert im.crop((0,900,540,960)).getbbox() and im.crop((100,300,440,650)).getbbox()
 assert 'ليسا مزامنة لفظية' in EFFECTS_CATALOG['word_timing_notice']



def test_cancel_dynamic_render_and_retry_do_not_leave_a_live_graphics_writer(tmp_path,monkeypatch):
 import threading
 monkeypatch.setattr(e,'EXPORTS',tmp_path)
 p=e.prepare_audio(112,2,2,'mossad');c=ProjectConfig(surah=112,from_ayah=2,to_ayah=2,reciter='mossad',quality='draft',clips=[SceneClip(scene_id='orbit')],effects={'verse':{'enabled':True,'kind':'glow'},'scene':{'enabled':True,'kind':'rain'}})
 event=threading.Event()
 def progress(value,message):
  if 45<=value<95:event.set()
 with pytest.raises(e.Canceled):e.render(c,p,'cancel-fx',progress,event.is_set,lambda proc:None)
 assert not (tmp_path/'cancel-fx/result.mp4').exists() and not (tmp_path/'cancel-fx/result.partial.mp4').exists()
 assert not any(t.name=='ayat-visual-frames' and t.is_alive() for t in threading.enumerate())
 result=e.render(c,p,'retry-fx',lambda *args:None,lambda:False,lambda proc:None)
 assert result['text_visible_ratio']>.52 and result['audio_peak']>.001
