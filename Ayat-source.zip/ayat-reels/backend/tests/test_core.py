from pathlib import Path
import sys,json,hashlib,xml.etree.ElementTree as ET,uuid,subprocess
import numpy as np
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import quran,media_engine,storage
from models import ProjectConfig,SceneClip,TextStyle
from catalog import SCENES
from pydantic import ValidationError


def test_all_6236_verses_exact_source_bytes_and_xml():
 raw=(quran.ROOT/'data/quran-uthmani.xml').read_bytes()
 assert hashlib.sha256(raw).hexdigest()==quran.QURAN['sha256']
 xml=ET.fromstring(raw)
 expected={f"{int(s.attrib['index'])}:{int(v.attrib['index'])}":v.attrib['text'] for s in xml.findall('sura') for v in s.findall('aya')}
 assert len(expected)==6236 and len(quran.SURAHS)==114
 assert expected==quran.QURAN['verses']
 assert 'بِسْمِ' not in expected['112:1'] # Separate bismillah attribute, never manually stripped.
 assert xml.find("./sura[@index='112']/aya").attrib['bismillah']==quran.QURAN['basmalas']['112']


def test_cannot_inject_ai_quran_text():
 with pytest.raises(ValidationError):ProjectConfig.model_validate({**ProjectConfig().model_dump(),'quran_text':'غير المصدر'})
 with pytest.raises(ValidationError):ProjectConfig(surah=112,from_ayah=1,to_ayah=5)
 with pytest.raises(ValidationError):TextStyle(color='red;rm -rf')
 with pytest.raises(ValidationError):SceneClip(scene_id='../../etc/passwd')
 with pytest.raises(ValidationError):SceneClip(source_in=5,source_out=3)


def test_all_bundled_mp4_scenes_have_measurable_frame_motion_and_known_license():
 for s in SCENES:
  if s.get('availability')=='on-demand':continue # On-demand sources have separate real-media checks.
  p=quran.ROOT/'media'/f"{s['id']}.mp4"
  assert p.read_bytes()[4:8]==b'ftyp'
  frames=[]
  for t in [1,3]:
   data=media_engine.run_checked(['-ss',str(t),'-i',str(p),'-frames:v','1','-vf','scale=90:160','-f','rawvideo','-pix_fmt','rgb24','pipe:1'])
   frames.append(np.frombuffer(data,dtype=np.uint8).astype(float))
  assert np.abs(frames[0]-frames[1]).mean()>.5,s['id']
  assert s['license'] in ['CC0-1.0','CC-BY-3.0']


def test_no_space_error_path_with_fault_injection(monkeypatch):
 # Fault injection, not a claim that the machine's disk was filled.
 class Disk:free=1024
 monkeypatch.setattr(media_engine.shutil,'disk_usage',lambda path:Disk())
 with pytest.raises(media_engine.EngineError) as error:media_engine.free_space_check(10,'hd')
 assert error.value.code=='NO_SPACE'


def test_project_roundtrip_and_interruption_recovery(tmp_path,monkeypatch):
 monkeypatch.setattr(storage,'DB',tmp_path/'test.sqlite');storage.init_db()
 ws=str(uuid.uuid4());cfg=ProjectConfig().model_dump();p=storage.save_project(ws,cfg)
 assert storage.get_project(ws,p['id'])['config']==cfg
 assert storage.get_project(str(uuid.uuid4()),p['id']) is None
 cfg['text_style']['size']=90
 assert storage.save_project(ws,cfg,p['id'])['config']['text_style']['size']==90
 j=storage.create_job(ws,p['id'],cfg);storage.update_job(j['id'],state='rendering',progress=44)
 assert storage.recover_interrupted()==1
 assert storage.get_job(ws,j['id'])['state']=='interrupted'
 assert storage.get_project(ws,p['id']) is not None


@pytest.mark.parametrize('reciter',['alafasy','husary','minshawi'])
def test_real_reciter_audio_fetch_decode_and_waveform(reciter):
 p=media_engine.prepare_audio(112,1,1,reciter)
 assert p['duration']>1
 assert p['verses'][0]['text']==quran.SOURCE_VERSES['112:1']
 data,sr=media_engine.sf.read(media_engine.AUDIO/p['id']/'combined.wav')
 assert sr==48000 and np.max(np.abs(data))>.001
 assert p['verses'][0]['source_url'].startswith('https://everyayah.com/')


@pytest.mark.parametrize('quality,transition',[('draft','cut'),('hd','wipeleft'),('fullhd','slideup')])
def test_real_mp4_all_qualities_transitions_text_and_trim(quality,transition,tmp_path,monkeypatch):
 monkeypatch.setattr(media_engine,'EXPORTS',tmp_path)
 p=media_engine.prepare_audio(112,1,2,'alafasy')
 cfg=ProjectConfig(to_ayah=2,quality=quality,audio_trim_start=.1,clips=[SceneClip(scene_id='ocean',source_in=.4,source_out=4.8,transition=transition),SceneClip(scene_id='stars')])
 jid='test-'+quality+'-'+str(uuid.uuid4())[:8]
 result=media_engine.render(cfg,p,jid,lambda *a:None,lambda:False,lambda p:None)
 assert result['text_visible_ratio']>.52 and result['audio_peak']>.001
 assert result['width']=={'draft':540,'hd':720,'fullhd':1080}[quality]
 assert abs(result['duration']-(p['duration']-.1))<.001
 audit=json.loads((media_engine.EXPORTS/jid/'audit.json').read_text())
 assert audit['all_cues_match_source']
 assert audit['result']['timeline']['clips'][0]['source_in']==.4
 assert audit['result']['timeline']['clips'][0]['transition']==transition
 assert (media_engine.EXPORTS/jid/'result.mp4').stat().st_size>10000


def test_invalid_manual_timing_and_audio_range():
 p=media_engine.prepare_audio(112,1,1,'alafasy')
 with pytest.raises(media_engine.EngineError) as e:media_engine.timing_and_clips(ProjectConfig(to_ayah=1,audio_trim_start=999),p)
 assert e.value.code=='INVALID_AUDIO_TRIM'
 p=media_engine.prepare_audio(112,1,2,'alafasy')
 cfg=ProjectConfig(to_ayah=2,timings=[{'key':'112:1','start':0,'end':3},{'key':'112:2','start':1,'end':4}])
 with pytest.raises(media_engine.EngineError) as e:media_engine.timing_and_clips(cfg,p)
 assert e.value.code=='INVALID_TIMINGS'


def test_startup_cleans_interrupted_temporary_files_not_finished_outputs(tmp_path,monkeypatch):
 monkeypatch.setattr(media_engine,'EXPORTS',tmp_path)
 folder=tmp_path/'interrupted-test';folder.mkdir()
 temporary=['result.partial.mp4','clip_0.mp4','text_000.png','trimmed.wav','text.ffconcat','first_text_mask.png']
 preserved=['result.mp4','audit.json','NOTICE.txt']
 for name in temporary+preserved:(folder/name).write_bytes(b'cleanup test marker, not a rendered video')
 assert media_engine.cleanup_orphaned_exports()==len(temporary)
 assert sorted(p.name for p in folder.iterdir())==sorted(preserved)



def test_expanded_templates_readers_and_footage_integrity():
 from catalog import RECITERS,TEMPLATES,SCENE_MAP,CURATED_RECORDINGS
 assert len(RECITERS)==54 and len(TEMPLATES)==80 and len(SCENE_MAP)>=40
 assert len({t['id'] for t in TEMPLATES})==80
 assert sum(s['kind']=='real-footage' for s in SCENE_MAP.values())>=32
 assert sum(s.get('subject')=='mosque' for s in SCENE_MAP.values())>=12
 assert all(s['kind'] in ['real-footage','original-motion-video'] for s in SCENE_MAP.values())
 assert not any('nabawi' in s['id'] for s in SCENE_MAP.values()) # No unlicensed or photo-based substitute for the requested site.
 for reader in RECITERS:
  assert len(reader['verification_samples'])==(len(CURATED_RECORDINGS[reader['id']]) if reader.get('provider')=='curated-surah' else 2)
  assert all(p['full_decode_exit']==0 and p['peak']>.001 and p['bytes']>1000 for p in reader['verification_samples'])
 for template in TEMPLATES:
  assert len(template['scene_ids'])>=3
  assert all(s in SCENE_MAP for s in template['scene_ids'])
 for scene in SCENE_MAP.values():
  if scene['kind']=='real-footage':
   assert scene['license'] in ['CC0-1.0','CC-BY-2.0','CC-BY-3.0','CC-BY-4.0','Public-domain-USGov'] and scene['source_url'].startswith(('https://commons.wikimedia.org/wiki/','https://www.nps.gov/'))
   if scene.get('availability')!='on-demand':assert hashlib.sha256((quran.ROOT/'media'/(scene['id']+'.mp4')).read_bytes()).hexdigest()==scene['sha256']


def test_real_nature_render_with_added_reader(tmp_path,monkeypatch):
 monkeypatch.setattr(media_engine,'EXPORTS',tmp_path)
 p=media_engine.prepare_audio(112,1,1,'maher')
 config=ProjectConfig(to_ayah=1,reciter='maher',quality='draft',template_id='falling_light',clips=[SceneClip(scene_id='waterfall'),SceneClip(scene_id='river_gorge')])
 jid='test-nature-'+str(uuid.uuid4())[:8]
 result=media_engine.render(config,p,jid,lambda *a:None,lambda:False,lambda p:None)
 assert result['text_visible_ratio']>.52 and result['audio_peak']>.001
 audit=json.loads((media_engine.EXPORTS/jid/'audit.json').read_text())
 assert audit['all_cues_match_source'] and len(audit['visual_sources'])==2
 assert all(s['kind']=='real-footage' and s['source_url'] for s in audit['visual_sources'])



def test_cancel_while_waiting_for_encoder_does_not_start_a_render(monkeypatch):
 class BusySlot:
  def acquire(self,timeout):raise media_engine.FileLockTimeout('occupied-by-another-export')
  def release(self):raise AssertionError('Unacquired slot must not be released')
 monkeypatch.setattr(media_engine,'RENDER_SLOT',BusySlot())
 calls=[]
 def canceled():
  calls.append(True)
  return len(calls)>1
 progress=[]
 with pytest.raises(media_engine.Canceled):media_engine.render(ProjectConfig(),{},'test-waiting',lambda *args:progress.append(args),canceled,lambda p:None)
 assert len(progress)==1 and progress[0][0]==30


def test_cc_by_transition_credits_are_visible_without_changing_quran(tmp_path):
 from PIL import Image
 cfg=ProjectConfig(to_ayah=1,clips=[SceneClip(scene_id='haram_night'),SceneClip(scene_id='haram_day')])
 verse=quran.get_verses(112,1,1)[0]
 plan={'duration':10,'verses':[{**verse,'start':0,'end':10}]}
 timeline=media_engine.timing_and_clips(cfg,plan)
 overlap=timeline['clips'][1]['start']+timeline['clips'][0]['transition_seconds']/2
 credits=media_engine.required_visual_sources(timeline,overlap)
 assert len(credits)==2 and {c['author'] for c in credits}=={'Hamza Khan','SHeGaRDeQ8i'}
 im=Image.new('RGBA',(540,960),(0,0,0,0));media_engine.draw_visual_credits(im,credits,540,960)
 pixels=np.array(im)
 assert pixels[:880,:,3].sum()==0 and pixels[880:,:,3].sum()>10000
 audit,_=media_engine.write_overlays(cfg,timeline,tmp_path,540,960,24)
 assert len(audit)==1 and audit[0]['text']==verse['text']
 assert audit[0]['start']==0 and audit[0]['end']==10


def test_real_mosque_render_new_reader_and_embedded_credits(tmp_path,monkeypatch):
 monkeypatch.setattr(media_engine,'EXPORTS',tmp_path)
 plan=media_engine.prepare_audio(112,1,1,'qasim')
 config=ProjectConfig(to_ayah=1,reciter='qasim',quality='draft',template_id='haram_sakinah',clips=[SceneClip(scene_id='haram_night'),SceneClip(scene_id='haram_day')])
 jid='test-licensed-mosque'
 result=media_engine.render(config,plan,jid,lambda *a:None,lambda:False,lambda p:None)
 assert result['visual_attribution_burned'] and result['text_visible_ratio']>.52
 audit=json.loads((tmp_path/jid/'audit.json').read_text())
 assert audit['all_cues_match_source'] and len(audit['cues'])==1
 assert all(s['requires_attribution'] and s['license']=='CC-BY-3.0' for s in audit['visual_sources'])
 notice=(tmp_path/jid/'NOTICE.txt').read_text()
 assert 'Hamza Khan' in notice and 'SHeGaRDeQ8i' in notice and 'https://creativecommons.org/licenses/by/3.0/' in notice
 assert (tmp_path/jid/'result.mp4').stat().st_size>10000
