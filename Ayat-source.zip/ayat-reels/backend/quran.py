from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
QURAN=json.loads((ROOT/'data/quran.json').read_text())
raw=(ROOT/'data/quran-uthmani.xml').read_bytes()
if hashlib.sha256(raw).hexdigest()!=QURAN['sha256']:
 raise RuntimeError('Quran source checksum mismatch: refusing to start.')
SOURCE_VERSES={f"{int(s.attrib['index'])}:{int(a.attrib['index'])}":a.attrib['text'] for s in ET.fromstring(raw).findall('sura') for a in s.findall('aya')}
if SOURCE_VERSES!=QURAN['verses'] or len(SOURCE_VERSES)!=6236:
 raise RuntimeError('Quran text differs from the official XML source: refusing to start.')
SURAHS=QURAN['surahs'];SURAH_MAP={s['id']:s for s in SURAHS}

# Warsh is a separate, publisher-pinned source. NEVER rewrite/normalize either text.
import gzip
WARSH_META=json.loads((ROOT/'data/warsh-source-info.json').read_text())
WARSH_RAW=gzip.decompress((ROOT/'data/quran-warsh-source.json.gz').read_bytes())
if hashlib.sha256(WARSH_RAW).hexdigest()!=WARSH_META['sha256']:
 raise RuntimeError('Official Warsh JSON checksum mismatch: refusing to start.')
if hashlib.sha256((ROOT/'fonts/KFGQPCWarsh.ttf').read_bytes()).hexdigest()!=WARSH_META['font_sha256']:
 raise RuntimeError('Official Warsh font checksum mismatch: refusing to start.')
WARSH_ROWS=json.loads(WARSH_RAW)
WARSH_VERSES={f"{r['sura_no']}:{r['aya_no']}":r['aya_text_unicode'] for r in WARSH_ROWS}
if len(WARSH_ROWS)!=6214 or len(WARSH_VERSES)!=6214:
 raise RuntimeError('Official Warsh verse count differs from verified distribution.')
WARSH_SURAHS=[]
for original in SURAHS:
 numbers=[r['aya_no'] for r in WARSH_ROWS if r['sura_no']==original['id']]
 if numbers!=list(range(1,len(numbers)+1)):
  raise RuntimeError('Official Warsh verse numbering is not contiguous.')
 WARSH_SURAHS.append({**original,'count':len(numbers)})
WARSH={**WARSH_META,'verses':WARSH_VERSES,'surahs':WARSH_SURAHS,'basmalas':{}}
SOURCES={'hafs':QURAN,'warsh':WARSH}

def quran_source(narration='hafs'):
 if narration not in SOURCES:raise ValueError('الرواية غير متاحة.')
 return SOURCES[narration]

def get_verses(surah,start,end,narration='hafs'):
 source=quran_source(narration);suras={s['id']:s for s in source['surahs']}
 if surah not in suras or not 1<=start<=end<=suras[surah]['count']:
  raise ValueError('مدى الآيات غير صحيح لهذه السورة والرواية.')
 return [{'key':f'{surah}:{a}','number':a,'surah':surah,'text':source['verses'][f'{surah}:{a}']} for a in range(start,end+1)]

def source_info(narration='hafs'):
 source=quran_source(narration)
 return {k:source[k] for k in ['publisher','edition','sha256','verse_count','surah_count','source_url','text_source','license_url','notice']}|{'narration':narration,'narration_name':'ورش عن نافع' if narration=='warsh' else 'حفص عن عاصم',**({k:source[k] for k in ['font_family','font_file','font_sha256','embedded_ayah_markers']} if narration=='warsh' else {})}
